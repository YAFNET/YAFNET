// Copyright (c) 2003, Eric Daugherty (http://www.ericdaugherty.com)
// All rights reserved.
// Modified by Carlos Mendible 

namespace netDumbster.smtp
{
    using System;
    using System.Collections;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Stores a single part of a multipart message.
    /// </summary>
    public class SmtpMessagePart
    {
        #region Constants

        private static readonly string DOUBLE_NEWLINE = Environment.NewLine + Environment.NewLine;

        #endregion

        #region Variables

        private Hashtable headerFields;

        private readonly string headerData = string.Empty;

        private readonly string bodyData = string.Empty;

        private readonly string bodyView = string.Empty;

        #endregion

        #region Constructors

        /// <summary>
        /// Creates a new message part.  The input string should be the body of 
        /// the attachment, without the "------=_NextPart" separator strings.
        /// The last 4 characters of the data will be "\r\n\r\n".
        /// </summary>
        public SmtpMessagePart(string data)
        {
            string[] parts = Regex.Split(data, DOUBLE_NEWLINE);

            this.headerData = parts[0];
            this.bodyData = parts[1];
            this.bodyView = DecodeBytes(new MemoryStream(Convert.FromBase64String(parts[1]), false).ToArray());
        }

        #endregion

        /// <summary>
        /// Decodes the bytes.
        /// </summary>
        /// <param name="buffer">The buffer.</param>
        private static string DecodeBytes(byte[] buffer)
        {
            return buffer == null ? null : Encoding.UTF8.GetString(buffer);
        }

        #region Properies

        /// <summary>
        /// A hash table of all the Headers in the email message.  They keys
        /// are the header names, and the values are the assoicated values, including
        /// any sub key/value pairs is the header.
        /// </summary>
        public Hashtable Headers
        {
            get
            {
                if (headerFields == null)
                {
                    headerFields = SmtpMessage.ParseHeaders(headerData);
                }
                return headerFields;
            }
        }

        /// <summary>
        /// The raw text that represents the header of the mime part.
        /// </summary>
        public string HeaderData
        {
            get
            {
                return headerData;
            }
        }

        /// <summary>
        /// The raw text that represents the actual mime part.
        /// </summary>
        public string BodyData
        {
            get
            {
                return this.bodyData;
            }
        }

        /// <summary>
        /// Gets the body view.
        /// </summary>
        public string BodyView
        {
            get
            {
                return this.bodyView;
            }
        }

        #endregion
    }
}
