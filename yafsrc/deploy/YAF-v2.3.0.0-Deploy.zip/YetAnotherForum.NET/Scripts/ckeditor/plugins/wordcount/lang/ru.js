﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'ru', {
    WordCount: 'Слов:',
    CharCount: 'Символов:',
    CharCountWithHTML: ' (включая HTML разметку):',
    Paragraphs: 'Параграфов:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: 'Контент не может быть вставлен, т.к. привышает допустимый лимит',
    Selected: 'Выделено: ',
    title: 'Статистика'
});
