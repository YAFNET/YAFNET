﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('autosave', 'ca', {
    dateFormat: 'LLL',
    autoSaveMessage: 'Auto desat',
    loadSavedContent: 'S\'ha trobat una versió auto-desada d\'aquest contingut de "{0}". Voleu comparar les versions del contingut i escollir quina carregar?',
    title: 'Compareu el contingut auto-desat amb el contingut carregat del lloc web',
    loadedContent: 'Contingut carregat',
    localStorageFull: 'Browser localStorage is full, clear your storage or Increase database size',
    autoSavedContent: 'Contingut auto-desat de: \'',
  ok: 'Sí, carrega el contingut auto-desat',
  no: 'No',
  diffType: 'Esculliu el tipus de visualització:',
  sideBySide: 'Visualització un al costat de l\'altre',
  inline: 'Visualització en línia'
});
