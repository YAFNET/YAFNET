/*
  YAF SQL Stored Procedures File Created 03/01/06
	

  Remove Comments RegEx: \/\*(.*)\*\/
  Remove Extra Stuff: SET ANSI_NULLS ON\nGO\nSET QUOTED_IDENTIFIER ON\nGO\n\n\n 
*/

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}accessmask_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}accessmask_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}accessmask_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}accessmask_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}accessmask_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}accessmask_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}active_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}active_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}active_listforum]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}active_listforum]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}active_listtopic]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}active_listtopic]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}active_stats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}active_stats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}active_updatemaxstats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}active_updatemaxstats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}attachment_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}attachment_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}attachment_download]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}attachment_download]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}attachment_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}attachment_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}attachment_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}attachment_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}bannedip_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}bannedip_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}bannedip_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}bannedip_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}bannedip_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}bannedip_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}board_create]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}board_create]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}board_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}board_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}board_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}board_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}board_poststats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}board_poststats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}board_userstats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}board_userstats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}board_resync]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}board_resync]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}board_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}board_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}board_stats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}board_stats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}category_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}category_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}category_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}category_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}category_listread]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}category_listread]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}category_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}category_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}checkemail_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}checkemail_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}checkemail_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}checkemail_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}checkemail_update]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}checkemail_update]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}choice_add]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}choice_add]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}choice_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}choice_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}choice_update]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}choice_update]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}choice_vote]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}choice_vote]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}eventlog_create]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}eventlog_create]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}eventlog_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}eventlog_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}eventlog_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}eventlog_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}extension_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}extension_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}extension_edit]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}extension_edit]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}extension_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}extension_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}extension_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}extension_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_listall]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_listall]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_listall_fromcat]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_listall_fromcat]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_listallmymoderated]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_listallmymoderated]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_listpath]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_listpath]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_listread]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_listread]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_listSubForums]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_listSubForums]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_listtopics]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_listtopics]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_moderatelist]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_moderatelist]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_moderators]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_moderators]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_resync]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_resync]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_updatelastpost]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_updatelastpost]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forum_updatestats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_updatestats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forumaccess_group]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forumaccess_group]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forumaccess_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forumaccess_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}forumaccess_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forumaccess_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}group_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}group_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}group_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}group_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}group_medal_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}group_medal_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}group_medal_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}group_medal_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}group_medal_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}group_medal_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}group_member]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}group_member]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}group_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}group_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}group_rank_style]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}group_rank_style]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}mail_create]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}mail_create]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}mail_createwatch]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}mail_createwatch]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}mail_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}mail_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}mail_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}mail_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}medal_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}medal_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}medal_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}medal_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}medal_listusers]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}medal_listusers]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}medal_resort]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}medal_resort]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}medal_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}medal_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_approve]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_approve]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_findunread]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_findunread]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_getReplies]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_getReplies]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_listreported]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_listreported]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_listreporters]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_listreporters]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_report]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_report]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_reportcopyover]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_reportcopyover]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_reportresolve]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_reportresolve]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_secdata]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_secdata]
GO



IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_unapproved]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_unapproved]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_update]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_update]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntpforum_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntpforum_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntpforum_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntpforum_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntpforum_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntpforum_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntpforum_update]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntpforum_update]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntpserver_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntpserver_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntpserver_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntpserver_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntpserver_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntpserver_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntptopic_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntptopic_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}nntptopic_savemessage]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}nntptopic_savemessage]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pageload]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pageload]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pmessage_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pmessage_info]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_info]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pmessage_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pmessage_markread]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_markread]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pmessage_prune]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_prune]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pmessage_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pmessage_archive]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_archive]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}poll_remove]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}poll_remove]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pollgroup_attach]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pollgroup_attach]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pollgroup_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pollgroup_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pollgroup_remove]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pollgroup_remove]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}poll_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}poll_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}poll_stats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}poll_stats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pollgroup_stats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pollgroup_stats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}poll_update]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}poll_update]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}pollvote_check]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}pollvote_check]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{objectQualifier}pollgroup_votecheck]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{objectQualifier}pollgroup_votecheck]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}post_last10user]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}post_last10user]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}post_alluser]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}post_alluser]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}post_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}post_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}post_list_reverse10]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}post_list_reverse10]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}rank_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}rank_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}rank_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}rank_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}rank_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}rank_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}registry_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}registry_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}registry_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}registry_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}replace_words_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}replace_words_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}replace_words_edit]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}replace_words_edit]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}replace_words_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}replace_words_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}replace_words_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}replace_words_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}smiley_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}smiley_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}smiley_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}smiley_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}smiley_listunique]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}smiley_listunique]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}smiley_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}smiley_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}smiley_resort]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}smiley_resort]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}system_initialize]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}system_initialize]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}system_updateversion]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}system_updateversion]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_active]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_active]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_findnext]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_findnext]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_findprev]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_findprev]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_info]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_info]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_announcements]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_announcements]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_latest]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_latest]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_listmessages]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_listmessages]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_lock]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_lock]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_move]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_move]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_poll_update]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_poll_update]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_prune]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_prune]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_updatelastpost]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_updatelastpost]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_updatetopic]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_updatetopic]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_accessmasks]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_accessmasks]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_activity_rank]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_activity_rank]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_addpoints]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_addpoints]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_adminsave]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_adminsave]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_approve]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_approve]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_approveall]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_approveall]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_aspnet]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_aspnet]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_migrate]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_migrate]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_avatarimage]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_avatarimage]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_changepassword]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_changepassword]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_pmcount]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_pmcount]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_deleteavatar]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_deleteavatar]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_deleteold]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_deleteold]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_emails]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_emails]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_find]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_find]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_getpoints]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_getpoints]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_getsignature]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_getsignature]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_guest]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_guest]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_listmedals]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_listmedals]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_login]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_login]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_medal_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_medal_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_medal_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_medal_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_medal_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_medal_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_nntp]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_nntp]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_recoverpassword]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_recoverpassword]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_removepoints]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_removepoints]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_removepointsbytopicid]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_removepointsbytopicid]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_resetpoints]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_resetpoints]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_savenotification]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_savenotification]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_saveavatar]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_saveavatar]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_savepassword]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_savepassword]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_savesignature]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_savesignature]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_setpoints]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_setpoints]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_setrole]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_setrole]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_suspend]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_suspend]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_upgrade]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_upgrade]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}userforum_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}userforum_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}userforum_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}userforum_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}userforum_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}userforum_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}usergroup_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}usergroup_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}usergroup_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}usergroup_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}userpmessage_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}userpmessage_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}userpmessage_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}userpmessage_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}watchforum_add]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}watchforum_add]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}watchforum_check]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}watchforum_check]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}watchforum_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}watchforum_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}watchforum_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}watchforum_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}watchtopic_add]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}watchtopic_add]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}watchtopic_check]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}watchtopic_check]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}watchtopic_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}watchtopic_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}watchtopic_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}watchtopic_list]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_reply_list]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_reply_list]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[{databaseOwner}].[{objectQualifier}message_deleteundelete]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_deleteundelete]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[{databaseOwner}].[{objectQualifier}topic_create_by_message]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_create_by_message]
GO

IF EXISTS (SELECT 1 FROM sysobjects where id = object_id(N'[{databaseOwner}].[{objectQualifier}message_move]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_move]
GO

IF EXISTS (SELECT * FROM   dbo.sysobjects
		   WHERE  id = Object_id(N'[{databaseOwner}].[{objectQualifier}category_simplelist]')
		   AND Objectproperty(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}category_simplelist] 
GO

IF EXISTS (SELECT *
		   FROM   dbo.sysobjects
		   WHERE  id = Object_id(N'[{databaseOwner}].[{objectQualifier}forum_simplelist]')
		   AND Objectproperty(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}forum_simplelist] 
GO

IF EXISTS (SELECT *
		   FROM   dbo.sysobjects
		   WHERE  id = Object_id(N'[{databaseOwner}].[{objectQualifier}message_simplelist]')
		   AND Objectproperty(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_simplelist] 
GO

IF EXISTS (SELECT *
		   FROM   dbo.sysobjects
		   WHERE  id = Object_id(N'[{databaseOwner}].[{objectQualifier}topic_simplelist]')
		   AND Objectproperty(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_simplelist] 
GO

IF EXISTS (SELECT *
		   FROM   dbo.sysobjects
		   WHERE  id = Object_id(N'[{databaseOwner}].[{objectQualifier}user_simplelist]')
		   AND Objectproperty(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_simplelist] 
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}bbcode_delete]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}bbcode_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}bbcode_list]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}bbcode_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}bbcode_save]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}bbcode_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_addignoreduser]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_addignoreduser]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_removeignoreduser]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_removeignoreduser]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_isuserignored]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_isuserignored]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_ignoredlist]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_ignoredlist]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}shoutbox_getmessages]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}shoutbox_getmessages]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}shoutbox_savemessage]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}shoutbox_savemessage]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}shoutbox_clearmessages]') AND Objectproperty(id,N'IsProcedure') = 1)
	DROP PROCEDURE [{databaseOwner}].[{objectQualifier}shoutbox_clearmessages]
GO

/* These stored procedures are for the Thanks Table. For safety, first check to see if they exist. If so, drop them. */
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_addthanks]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_addthanks]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_getthanks]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_getthanks]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_getallthanks]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_getallthanks]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_removethanks]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_removethanks]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_thanksnumber]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_thanksnumber]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_getthanks_from]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_getthanks_from]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_getthanks_to]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_getthanks_to]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}active_list_user]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}active_list_user]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_viewallthanks]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_viewallthanks]
GO

/* End of Thanks table stored procedures */
 
/* Buddy feature stored procedures */
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}buddy_addrequest]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_addrequest]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}buddy_approverequest]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_approverequest]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}buddy_denyrequest]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_denyrequest]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}buddy_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}buddy_remove]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_remove]
GO
/* End of Buddy feature stored procedures */

/****** Object:  StoredProcedure [{databaseOwner}].[{objectQualifier}topic_favorite_add]    Script Date: 12/08/2009 18:13:19 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_favorite_add]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_favorite_add]
GO

/****** Object:  StoredProcedure [{databaseOwner}].[{objectQualifier}topic_favorite_details]    Script Date: 12/08/2009 18:13:20 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_favorite_details]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_favorite_details]
GO

/****** Object:  StoredProcedure [{databaseOwner}].[{objectQualifier}topic_favorite_list]    Script Date: 12/08/2009 18:13:20 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_favorite_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_favorite_list]
GO

/****** Object:  StoredProcedure [{databaseOwner}].[{objectQualifier}topic_favorite_remove]    Script Date: 12/08/2009 18:13:20 ******/
IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}topic_favorite_remove]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}topic_favorite_remove]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_save]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_gettitle]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_gettitle]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_getstats]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_getstats]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_image_save]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_image_save]
Go

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_image_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_image_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_image_delete]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_image_delete]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}album_image_download]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}album_image_download]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_getsignaturedata]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_getsignaturedata]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_getalbumsdata]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_getalbumsdata]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}messagehistory_list]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}messagehistory_list]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}user_lazydata]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}user_lazydata]
GO

IF  EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[{databaseOwner}].[{objectQualifier}message_gettextbyids]') AND OBJECTPROPERTY(id,N'IsProcedure') = 1)
DROP PROCEDURE [{databaseOwner}].[{objectQualifier}message_gettextbyids]
GO

/*****************************************************************************************************************************/
/***** BEGIN CREATE PROCEDURES ******/

/* Procedures for "Thanks" Mod */
CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_addthanks] 
	@FromUserID int,
	@MessageID int,
	@paramOutput nvarchar(50) = null out
AS
BEGIN
IF not exists (SELECT ThanksID FROM [{databaseOwner}].[{objectQualifier}Thanks] WHERE (MessageID = @MessageID AND ThanksFromUserID=@FromUserID))
BEGIN
DECLARE @ToUserID int
	SET @ToUserID = (SELECT UserID FROM [{databaseOwner}].[{objectQualifier}Message] WHERE (MessageID = @MessageID))
	INSERT INTO [{databaseOwner}].[{objectQualifier}Thanks] (ThanksFromUserID, ThanksToUserID, MessageID, ThanksDate) Values 
								(@FromUserID, @ToUserId, @MessageID, GETUTCDATE() )
	SET @paramOutput = (SELECT [Name] FROM [{databaseOwner}].[{objectQualifier}User] WHERE (UserID=@ToUserID))
END
ELSE
	SET @paramOutput = ''
END
Go

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_getthanks] 
	@MessageID int
AS
BEGIN
	SELECT a.ThanksFromUserID as UserID, a.ThanksDate, b.Name, b.DisplayName
	FROM [{databaseOwner}].[{objectQualifier}Thanks] a 
	Inner Join [{databaseOwner}].[{objectQualifier}User] b
	ON (a.ThanksFromUserID = b.UserID) WHERE (MessageID=@MessageID)
	ORDER BY a.ThanksDate DESC
END
GO

#IFSRVVER>8#CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_getallthanks] 
	@MessageIDs varchar(max)
AS
BEGIN
-- vzrus says: the server version > 2000 ntext works too slowly with substring in the 2005 
DECLARE @ParsedMessageIDs TABLE
	  (
			MessageID int
	  )
	  
DECLARE @MessageID varchar(11), @Pos INT      

SET @Pos = CHARINDEX(',', @MessageIDs, 1)
-- check here if the value is not empty
IF REPLACE(@MessageIDs, ',', '') <> ''
BEGIN
 WHILE @Pos > 0
				  BEGIN
						SET @MessageID = LTRIM(RTRIM(LEFT(@MessageIDs, @Pos - 1)))
						IF @MessageID <> ''
						BEGIN
							  INSERT INTO @ParsedMessageIDs (MessageID) VALUES (CAST(@MessageID AS int)) --Use Appropriate conversion
						END
						SET @MessageIDs = RIGHT(@MessageIDs, LEN(@MessageIDs) - @Pos)
						SET @Pos = CHARINDEX(',', @MessageIDs, 1)
				  END
					 -- to be sure that last value is inserted
					IF (LEN(@MessageIDs) > 0)
						   INSERT INTO @ParsedMessageIDs (MessageID) VALUES (CAST(@MessageIDs AS int)) 
END 
	SELECT a.MessageID, b.ThanksFromUserID AS FromUserID, b.ThanksDate,
	(SELECT COUNT(ThanksID) FROM [{databaseOwner}].[{objectQualifier}Thanks] b WHERE b.ThanksFromUserID=d.UserID) AS ThanksFromUserNumber,
	(SELECT COUNT(ThanksID) FROM [{databaseOwner}].[{objectQualifier}Thanks] b WHERE b.ThanksToUserID=d.UserID) AS ThanksToUserNumber,
	(SELECT COUNT(DISTINCT(MessageID)) FROM [{databaseOwner}].[{objectQualifier}Thanks] b WHERE b.ThanksToUserID=d.userID) AS ThanksToUserPostsNumber
	FROM @ParsedMessageIDs a
	INNER JOIN [{databaseOwner}].[{objectQualifier}Message] d ON (d.MessageID=a.MessageID)
	LEFT JOIN [{databaseOwner}].[{objectQualifier}Thanks] b ON (b.MessageID = a.MessageID)
END
GO

#IFSRVVER=8#CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_getallthanks] 
	@MessageIDs ntext
AS
BEGIN
DECLARE @ParsedMessageIDs TABLE
	  (
			MessageID int
	  )
	DECLARE @MessageIDsChunk NVARCHAR(4000), @MessageID varchar(11), @Pos INT, @Itr INT, @trimindex int
	SET @Itr = 0
	SET @MessageIDSChunk  = SUBSTRING( @MessageIDs, @Itr, @Itr + 4000 )
	WHILE LEN(@MessageIDsChunk) > 0
	BEGIN
			SET @trimindex = CHARINDEX(',',REVERSE( @MessageIDsChunk ), 1 );
			SET @MessageIDsChunk = SUBSTRING(@MessageIDsChunk,0, 4000-@trimindex)
			SET @Itr = @Itr - @trimindex
			SET @MessageIDsChunk = LTRIM(RTRIM(@MessageIDsChunk))+ ','
			SET @Pos = CHARINDEX(',', @MessageIDsChunk, 1)
			IF REPLACE(@MessageIDsChunk, ',', '') <> ''
			BEGIN
				  WHILE @Pos > 0
				  BEGIN
						SET @MessageID = LTRIM(RTRIM(LEFT(@MessageIDsChunk, @Pos - 1)))
						IF @MessageID <> ''
						BEGIN
							  INSERT INTO @ParsedMessageIDs (MessageID) VALUES (CAST(@MessageID AS int)) --Use Appropriate conversion
						END
						SET @MessageIDsChunk = RIGHT(@MessageIDsChunk, LEN(@MessageIDsChunk) - @Pos)
						SET @Pos = CHARINDEX(',', @MessageIDsChunk, 1)
				  END
			END      
			SET @Itr = @Itr + 4000;
			SET @MessageIDSChunk  = SUBSTRING( @MessageIDs, @Itr, @Itr + 4000 )
	  END
	  
	SELECT a.MessageID, b.ThanksFromUserID AS FromUserID, b.ThanksDate,
	(SELECT COUNT(ThanksID) FROM [{databaseOwner}].[{objectQualifier}Thanks] b WHERE b.ThanksFromUserID=d.UserID) AS ThanksFromUserNumber,
	(SELECT COUNT(ThanksID) FROM [{databaseOwner}].[{objectQualifier}Thanks] b WHERE b.ThanksToUserID=d.UserID) AS ThanksToUserNumber,
	(SELECT COUNT(DISTINCT(MessageID)) FROM [{databaseOwner}].[{objectQualifier}Thanks] b WHERE b.ThanksToUserID=d.userID) AS ThanksToUserPostsNumber
	FROM @ParsedMessageIDs a
	INNER JOIN [{databaseOwner}].[{objectQualifier}Message] d ON (d.MessageID=a.MessageID)
	LEFT JOIN [{databaseOwner}].[{objectQualifier}thanks] b ON (b.MessageID = a.MessageID)
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_removethanks] 
	@FromUserID int,
	@MessageID int,
	@paramOutput nvarchar(50) = null out
AS
BEGIN
	DELETE FROM [{databaseOwner}].[{objectQualifier}Thanks] WHERE (ThanksFromUserID=@FromUserID AND MessageID=@MessageID)
	DECLARE @ToUserID int
	SET @ToUserID = (SELECT UserID FROM [{databaseOwner}].[{objectQualifier}Message] WHERE (MessageID = @MessageID))
	SET @paramOutput = (SELECT [Name] FROM [{databaseOwner}].[{objectQualifier}User] WHERE (UserID=@ToUserID))
END
Go

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_thanksnumber] 
	@MessageID int
AS
BEGIN
RETURN (SELECT Count(*) from [{databaseOwner}].[{objectQualifier}Thanks] WHERE (MessageID=@MessageID))
END
Go

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_getthanks_from] 
	@UserID int, @PageUserID  int
AS
BEGIN
SELECT Count(*) FROM [{databaseOwner}].[{objectQualifier}Thanks] WHERE ThanksFromUserID=@UserID
END
Go

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_getthanks_to] 
	@UserID			int,
	@PageUserID     int,
	@ThanksToNumber int output,
	@ThanksToPostsNumber int output
AS
BEGIN
SELECT @ThanksToNumber=(SELECT Count(*) FROM [{databaseOwner}].[{objectQualifier}Thanks] WHERE ThanksToUserID=@UserID)	
SELECT @ThanksToPostsNumber=(SELECT Count(DISTINCT MessageID) FROM [{databaseOwner}].[{objectQualifier}Thanks] WHERE ThanksToUserID=@UserID)	
END
Go

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_viewallthanks] @UserID int, @PageUserID int
AS 
	BEGIN
		select  t.ThanksFromUserID,
				t.ThanksToUserID,
				c.MessageID,
				a.ForumID,
				a.TopicID,
				a.Topic,
				b.UserID,
				c.MessageID,
				c.Posted,
				c.[Message],
				c.Flags
		        from   [{databaseOwner}].[{objectQualifier}Thanks] t
		        join [{databaseOwner}].[{objectQualifier}message] c  on c.MessageID = t.MessageID		 
				join [{databaseOwner}].[{objectQualifier}topic] a on a.TopicID = c.TopicID
			    join [{databaseOwner}].[{objectQualifier}user] b on c.UserID = b.UserID
				join [{databaseOwner}].[{objectQualifier}vaccess] x on x.ForumID = a.ForumID
		where   x.ReadAccess <> 0
			    AND x.UserID = @PageUserID			
				AND c.IsApproved = 1
				AND a.TopicMovedID IS NULL
				AND a.IsDeleted = 0
				AND c.IsDeleted = 0
			 AND
			( t.ThanksFromUserID = @UserID 
			OR t.thankstouserID = @UserID )

		ORDER BY c.Posted DESC
	END
Go
/* End of procedures for "Thanks" Mod */

create procedure [{databaseOwner}].[{objectQualifier}accessmask_delete](@AccessMaskID int) as
begin
		declare @flag int
	
	set @flag=1
	if exists(select 1 from [{databaseOwner}].[{objectQualifier}ForumAccess] where AccessMaskID=@AccessMaskID) or exists(select 1 from [{databaseOwner}].[{objectQualifier}UserForum] where AccessMaskID=@AccessMaskID)
		set @flag=0
	else
		delete from [{databaseOwner}].[{objectQualifier}AccessMask] where AccessMaskID=@AccessMaskID
	
	select @flag
end
GO

create procedure [{databaseOwner}].[{objectQualifier}accessmask_list](@BoardID int,@AccessMaskID int=null,@ExcludeFlags int = 0) as
begin
		if @AccessMaskID is null
		select 
			a.* 
		from 
			[{databaseOwner}].[{objectQualifier}AccessMask] a 
		where
			a.BoardID = @BoardID and
			(a.Flags & @ExcludeFlags) = 0
		order by 
			a.SortOrder
	else
		select 
			a.* 
		from 
			[{databaseOwner}].[{objectQualifier}AccessMask] a 
		where
			a.BoardID = @BoardID and
			a.AccessMaskID = @AccessMaskID
		order by 
			a.SortOrder
end
GO

create procedure [{databaseOwner}].[{objectQualifier}accessmask_save](
	@AccessMaskID		int=null,
	@BoardID			int,
	@Name				nvarchar(50),
	@ReadAccess			bit,
	@PostAccess			bit,
	@ReplyAccess		bit,
	@PriorityAccess		bit,
	@PollAccess			bit,
	@VoteAccess			bit,
	@ModeratorAccess	bit,
	@EditAccess			bit,
	@DeleteAccess		bit,
	@UploadAccess		bit,
	@DownloadAccess		bit,
	@SortOrder          smallint
) as
begin
		declare @Flags	int
	
	set @Flags = 0
	if @ReadAccess<>0 set @Flags = @Flags | 1
	if @PostAccess<>0 set @Flags = @Flags | 2
	if @ReplyAccess<>0 set @Flags = @Flags | 4
	if @PriorityAccess<>0 set @Flags = @Flags | 8
	if @PollAccess<>0 set @Flags = @Flags | 16
	if @VoteAccess<>0 set @Flags = @Flags | 32
	if @ModeratorAccess<>0 set @Flags = @Flags | 64
	if @EditAccess<>0 set @Flags = @Flags | 128
	if @DeleteAccess<>0 set @Flags = @Flags | 256
	if @UploadAccess<>0 set @Flags = @Flags | 512
	if @DownloadAccess<>0 set @Flags = @Flags | 1024

	if @AccessMaskID is null
		insert into [{databaseOwner}].[{objectQualifier}AccessMask](Name,BoardID,Flags,SortOrder)
		values(@Name,@BoardID,@Flags,@SortOrder)
	else
		update [{databaseOwner}].[{objectQualifier}AccessMask] set
			Name			= @Name,
			Flags			= @Flags,
			SortOrder       = @SortOrder
		where AccessMaskID=@AccessMaskID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}active_list](@BoardID int,@Guests bit=0,@ShowCrawlers bit=0,@ActiveTime int,@StyledNicks bit=0) as
begin
	-- delete non-active
	delete from [{databaseOwner}].[{objectQualifier}Active] where DATEDIFF(minute,LastActive,GETUTCDATE() )>@ActiveTime
	-- select active	
	if @Guests<>0 
		select
			a.UserID,
			UserName = a.Name,
			c.IP,
			c.SessionID,
			c.ForumID,
			c.TopicID,
			ForumName = (select Name from [{databaseOwner}].[{objectQualifier}Forum] x where x.ForumID=c.ForumID),
			TopicName = (select Topic from [{databaseOwner}].[{objectQualifier}Topic] x where x.TopicID=c.TopicID),
			IsGuest = (select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] x inner join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 2)<>0),
			IsCrawler = CONVERT(int, SIGN((c.Flags & 8))),
			IsHidden = ( a.IsActiveExcluded ),
				Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID)  
			else ''	 end,				
			UserCount = 1,
			c.[Login],
			c.LastActive,
			c.Location,
			Active = DATEDIFF(minute,c.Login,c.LastActive),
			c.Browser,
			c.[Platform],
			c.ForumPage
		from
			[{databaseOwner}].[{objectQualifier}User] a		
			INNER JOIN [{databaseOwner}].[{objectQualifier}Active] c ON c.UserID = a.UserID	
				  
		where
			c.BoardID = @BoardID 	
				
		order by 
			c.LastActive desc
	else if @ShowCrawlers = 1 and @Guests = 0 
		select
			a.UserID,
			UserName = a.Name,
			c.IP,
			c.SessionID,
			c.ForumID,
			c.TopicID,
			ForumName = (select Name from [{databaseOwner}].[{objectQualifier}Forum] x where x.ForumID=c.ForumID),
			TopicName = (select Topic from [{databaseOwner}].[{objectQualifier}Topic] x where x.TopicID=c.TopicID),
			IsGuest = (select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] x inner join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 2)<>0),
			IsCrawler = CONVERT(int, SIGN((c.Flags & 8))),
			IsHidden = ( a.IsActiveExcluded ),
				Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID)  
			else ''	 end,				
			UserCount = 1,
			c.[Login],
			c.LastActive,
			c.Location,
			Active = DATEDIFF(minute,c.Login,c.LastActive),
			c.Browser,
			c.[Platform],
			c.ForumPage
		from
			[{databaseOwner}].[{objectQualifier}User] a		
			INNER JOIN [{databaseOwner}].[{objectQualifier}Active] c ON c.UserID = a.UserID	
				  
		where
			c.BoardID = @BoardID 	
			   and ((c.Flags & 4) = 4 OR (c.Flags & 2) <> 2 OR  (c.Flags & 8) = 8)					  
		order by 
			c.LastActive desc
	else
		select
			a.UserID,
			UserName = a.Name,
			c.IP,
			c.SessionID,
			c.ForumID,
			c.TopicID,
			ForumName = (select Name from [{databaseOwner}].[{objectQualifier}Forum] x where x.ForumID=c.ForumID),
			TopicName = (select Topic from [{databaseOwner}].[{objectQualifier}Topic] x where x.TopicID=c.TopicID),
			IsGuest = (select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] x inner join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 2)<>0),
			IsCrawler = CONVERT(int, SIGN((c.Flags & 8))),
			IsHidden = ( a.IsActiveExcluded ),
				Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID)  
			else ''	 end,				
			UserCount = 1,
			c.[Login],
			c.LastActive,
			c.Location,
			Active = DATEDIFF(minute,c.Login,c.LastActive),
			c.Browser,
			c.[Platform],
			c.ForumPage
		from
			[{databaseOwner}].[{objectQualifier}User] a		
			INNER JOIN [{databaseOwner}].[{objectQualifier}Active] c ON c.UserID = a.UserID	
				  
		where
			c.BoardID = @BoardID and
			-- no guests
			not exists(				
				select 1 
					from [{databaseOwner}].[{objectQualifier}UserGroup] x
						inner join [{databaseOwner}].[{objectQualifier}Group] y ON y.GroupID=x.GroupID 
					where x.UserID=a.UserID and (y.Flags & 2)<>0
				)
		order by
			c.LastActive desc
end
GO

create procedure [{databaseOwner}].[{objectQualifier}active_list_user](@BoardID int, @UserID int, @Guests bit=0, @ShowCrawlers bit = 0, @ActiveTime int,@StyledNicks bit=0) as
begin
		-- delete non-active
	delete from [{databaseOwner}].[{objectQualifier}Active] where DATEDIFF(minute,LastActive,GETUTCDATE() )>@ActiveTime
	-- select active
	if @Guests<>0
		select
			a.UserID,
			UserName = a.Name,
			c.IP,
			c.SessionID,
			c.ForumID,
			HasForumAccess = x.ReadAccess,			
			c.TopicID,
			ForumName = (select Name from [{databaseOwner}].[{objectQualifier}Forum] x where x.ForumID=c.ForumID),
			TopicName = (select Topic from [{databaseOwner}].[{objectQualifier}Topic] x where x.TopicID=c.TopicID),
			IsGuest = ISNULL((select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] x inner join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 2)<>0),0),
			IsCrawler = CONVERT(int, SIGN((c.Flags & 8))),
			IsHidden = ( a.IsActiveExcluded ),
			Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID)  
			else ''	 end,			
			UserCount = 1,
			c.[Login],
			c.LastActive,
			c.Location,		
			Active = DATEDIFF(minute,c.Login,c.LastActive),
			c.Browser,
			c.[Platform],
			c.ForumPage
		from
			[{databaseOwner}].[{objectQualifier}User] a
			inner join [{databaseOwner}].[{objectQualifier}Active] c 
			ON c.UserID = a.UserID
			inner join [{databaseOwner}].[{objectQualifier}vaccess] x
			ON (x.ForumID = ISNULL(c.ForumID,0))						
		where		
			c.BoardID = @BoardID AND x.UserID = @UserID		
		order by
			c.LastActive desc
		else if @ShowCrawlers = 1 and @Guests = 0 
			select
			a.UserID,
			UserName = a.Name,
			c.IP,
			c.SessionID,
			c.ForumID,
			HasForumAccess = x.ReadAccess,			
			c.TopicID,
			ForumName = (select Name from [{databaseOwner}].[{objectQualifier}Forum] x where x.ForumID=c.ForumID),
			TopicName = (select Topic from [{databaseOwner}].[{objectQualifier}Topic] x where x.TopicID=c.TopicID),
			IsGuest = ISNULL((select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] x inner join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 2)<>0),0),
			IsCrawler = CONVERT(int, SIGN((c.Flags & 8))),
			IsHidden = ( a.IsActiveExcluded ),
			Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID)  
			else ''	 end,			
			UserCount = 1,
			c.[Login],
			c.LastActive,
			c.Location,
			Active = DATEDIFF(minute,c.Login,c.LastActive),
			c.Browser,
			c.[Platform],
			c.ForumPage
		from
			[{databaseOwner}].[{objectQualifier}User] a
			inner join [{databaseOwner}].[{objectQualifier}Active] c 
			ON c.UserID = a.UserID
			inner join [{databaseOwner}].[{objectQualifier}vaccess] x
			ON (x.ForumID = ISNULL(c.ForumID,0))						
		where		
			c.BoardID = @BoardID AND x.UserID = @UserID	  and ((c.Flags & 4) = 4 OR (c.Flags & 2) <> 2 OR  (c.Flags & 8) = 8)		
		order by
			c.LastActive desc
	else
		select
			a.UserID,
			UserName = a.Name,
			c.IP,
			c.SessionID,
			c.ForumID,
			HasForumAccess = x.ReadAccess,			
			c.TopicID,
			ForumName = (select Name from [{databaseOwner}].[{objectQualifier}Forum] x where x.ForumID=c.ForumID),
			TopicName = (select Topic from [{databaseOwner}].[{objectQualifier}Topic] x where x.TopicID=c.TopicID),
			IsGuest = (select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] x inner join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 2)<>0),
			IsCrawler = CONVERT(int, SIGN((c.Flags & 8))),
			IsHidden = ( a.IsActiveExcluded ),
				Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID)  
			else ''	 end,				
			UserCount = 1,
			c.[Login],
			c.LastActive,
			c.Location,
			Active = DATEDIFF(minute,c.Login,c.LastActive),
			c.Browser,
			c.[Platform],
			c.ForumPage
		from
			[{databaseOwner}].[{objectQualifier}User] a		
			INNER JOIN [{databaseOwner}].[{objectQualifier}Active] c 
			ON c.UserID = a.UserID
			inner join [{databaseOwner}].[{objectQualifier}vaccess] x
			ON (x.ForumID = ISNULL(c.ForumID,0))
			where		
			c.BoardID = @BoardID  AND x.UserID = @UserID				      
		 and
			not exists(
				select 1 
					from [{databaseOwner}].[{objectQualifier}UserGroup] x
						inner join [{databaseOwner}].[{objectQualifier}Group] y ON y.GroupID=x.GroupID 
					where x.UserID=a.UserID and (y.Flags & 2)<>0
				)
		order by
			c.LastActive desc
end
GO

create procedure [{databaseOwner}].[{objectQualifier}active_listforum](@ForumID int, @StyledNicks bit = 0) as
begin
		select
		UserID		= a.UserID,
		UserName	= b.Name,
		IsHidden	= ( b.IsActiveExcluded ),
		IsCrawler	= Convert(int,a.Flags & 8),		
		Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID)  
			else ''	 end,		
		UserCount   = (SELECT COUNT(ac.UserID) from
		[{databaseOwner}].[{objectQualifier}Active] ac with(nolock) where ac.UserID = a.UserID and ac.ForumID = @ForumID),
		Browser = a.Browser
	from
		[{databaseOwner}].[{objectQualifier}Active] a 
		join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=a.UserID
	where
		a.ForumID = @ForumID
	group by
		a.UserID,
		b.Name,
		b.IsActiveExcluded,
		a.Flags,
		a.Browser
	order by
		b.Name
end
GO


create procedure [{databaseOwner}].[{objectQualifier}active_listtopic](@TopicID int,@StyledNicks bit = 0) as
begin   
		select
		UserID		= a.UserID,
		UserName	= b.Name,
		IsHidden = ( b.IsActiveExcluded ),		
		IsCrawler	= Convert(int,a.Flags & 8),
		Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID)  
			else ''	 end,		
		UserCount   = (SELECT COUNT(ac.UserID) from
		[{databaseOwner}].[{objectQualifier}Active] ac with(nolock) where ac.UserID = a.UserID and ac.TopicID = @TopicID),
		Browser = a.Browser
	from
		[{databaseOwner}].[{objectQualifier}Active] a with(nolock)
		join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=a.UserID
	where
		a.TopicID = @TopicID
	group by
		a.UserID,
		b.Name,
		b.IsActiveExcluded,
		a.Flags,
		a.Browser		
	order by
		b.Name
end
GO


create procedure [{databaseOwner}].[{objectQualifier}active_stats](@BoardID int) as
begin
		select
		ActiveUsers = (select count(1) from [{databaseOwner}].[{objectQualifier}Active] x JOIN [{databaseOwner}].[{objectQualifier}User] usr ON x.UserID = usr.UserID where x.BoardID = @BoardID AND usr.IsActiveExcluded = 0),
		ActiveMembers = (select count(1) from [{databaseOwner}].[{objectQualifier}Active] x JOIN [{databaseOwner}].[{objectQualifier}User] usr ON x.UserID = usr.UserID where x.BoardID = @BoardID and exists(select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] y inner join [{databaseOwner}].[{objectQualifier}Group] z on y.GroupID=z.GroupID where y.UserID=x.UserID and (z.Flags & 2)=0  AND usr.IsActiveExcluded = 0)),
		ActiveGuests = (select count(1) from [{databaseOwner}].[{objectQualifier}Active] x where x.BoardID = @BoardID and exists(select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] y inner join [{databaseOwner}].[{objectQualifier}Group] z on y.GroupID=z.GroupID where y.UserID=x.UserID and (z.Flags & 2)<>0)),
		ActiveHidden = (select count(1) from [{databaseOwner}].[{objectQualifier}Active] x JOIN [{databaseOwner}].[{objectQualifier}User] usr ON x.UserID = usr.UserID where x.BoardID = @BoardID and exists(select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] y inner join [{databaseOwner}].[{objectQualifier}Group] z on y.GroupID=z.GroupID where y.UserID=x.UserID and (z.Flags & 2)=0  AND usr.IsActiveExcluded = 1))
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}active_updatemaxstats]
(
	@BoardID int
)
AS
BEGIN
		DECLARE @count int, @max int, @maxStr nvarchar(255), @countStr nvarchar(255), @dtStr nvarchar(255)
	
	SET @count = ISNULL((SELECT COUNT(DISTINCT IP + '.' + CAST(UserID as varchar(10))) FROM [{databaseOwner}].[{objectQualifier}Active] WITH (NOLOCK) WHERE BoardID = @BoardID),0)
	SET @maxStr = ISNULL((SELECT CAST([Value] AS nvarchar) FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE BoardID = @BoardID AND [Name] = N'maxusers'),'1')
	SET @max = CAST(@maxStr AS int)
	SET @countStr = CAST(@count AS nvarchar)
	SET @dtStr = CONVERT(nvarchar,GETUTCDATE() ,126)

	IF NOT EXISTS ( SELECT 1 FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE BoardID = @BoardID and [Name] = N'maxusers' )
	BEGIN 
		INSERT INTO [{databaseOwner}].[{objectQualifier}Registry](BoardID,[Name],[Value]) VALUES (@BoardID,N'maxusers',CAST(@countStr AS ntext))
		INSERT INTO [{databaseOwner}].[{objectQualifier}Registry](BoardID,[Name],[Value]) VALUES (@BoardID,N'maxuserswhen',CAST(@dtStr AS ntext))
	END
	ELSE IF (@count > @max)	
	BEGIN
		UPDATE [{databaseOwner}].[{objectQualifier}Registry] SET [Value] = CAST(@countStr AS ntext) WHERE BoardID = @BoardID AND [Name] = N'maxusers'
		UPDATE [{databaseOwner}].[{objectQualifier}Registry] SET [Value] = CAST(@dtStr AS ntext) WHERE BoardID = @BoardID AND [Name] = N'maxuserswhen'
	END
END
GO

create procedure [{databaseOwner}].[{objectQualifier}attachment_delete](@AttachmentID int) as begin
		delete from [{databaseOwner}].[{objectQualifier}Attachment] where AttachmentID=@AttachmentID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}attachment_download](@AttachmentID int) as
begin
		update [{databaseOwner}].[{objectQualifier}Attachment] set Downloads=Downloads+1 where AttachmentID=@AttachmentID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}attachment_list](@MessageID int=null,@AttachmentID int=null,@BoardID int=null) as begin
		if @MessageID is not null
		select 
			a.*,
			e.BoardID
		from
			[{databaseOwner}].[{objectQualifier}Attachment] a
			inner join [{databaseOwner}].[{objectQualifier}Message] b on b.MessageID = a.MessageID
			inner join [{databaseOwner}].[{objectQualifier}Topic] c on c.TopicID = b.TopicID
			inner join [{databaseOwner}].[{objectQualifier}Forum] d on d.ForumID = c.ForumID
			inner join [{databaseOwner}].[{objectQualifier}Category] e on e.CategoryID = d.CategoryID
		where
			a.MessageID=@MessageID
	else if @AttachmentID is not null
		select 
			a.*,
			e.BoardID
		from
			[{databaseOwner}].[{objectQualifier}Attachment] a
			inner join [{databaseOwner}].[{objectQualifier}Message] b on b.MessageID = a.MessageID
			inner join [{databaseOwner}].[{objectQualifier}Topic] c on c.TopicID = b.TopicID
			inner join [{databaseOwner}].[{objectQualifier}Forum] d on d.ForumID = c.ForumID
			inner join [{databaseOwner}].[{objectQualifier}Category] e on e.CategoryID = d.CategoryID
		where 
			a.AttachmentID=@AttachmentID
	else
		select 
			a.*,
			BoardID		= @BoardID,
			Posted		= b.Posted,
			ForumID		= d.ForumID,
			ForumName	= d.Name,
			TopicID		= c.TopicID,
			TopicName	= c.Topic
		from 
			[{databaseOwner}].[{objectQualifier}Attachment] a
			inner join [{databaseOwner}].[{objectQualifier}Message] b on b.MessageID = a.MessageID
			inner join [{databaseOwner}].[{objectQualifier}Topic] c on c.TopicID = b.TopicID
			inner join [{databaseOwner}].[{objectQualifier}Forum] d on d.ForumID = c.ForumID
			inner join [{databaseOwner}].[{objectQualifier}Category] e on e.CategoryID = d.CategoryID
		where
			e.BoardID = @BoardID
		order by
			d.Name,
			c.Topic,
			b.Posted
end
GO

create procedure [{databaseOwner}].[{objectQualifier}attachment_save](@MessageID int,@FileName nvarchar(255),@Bytes int,@ContentType nvarchar(50)=null,@FileData image=null) as begin
		insert into [{databaseOwner}].[{objectQualifier}Attachment](MessageID,FileName,Bytes,ContentType,Downloads,FileData) values(@MessageID,@FileName,@Bytes,@ContentType,0,@FileData)
end
GO

create procedure [{databaseOwner}].[{objectQualifier}bannedip_delete](@ID int) as
begin
		delete from [{databaseOwner}].[{objectQualifier}BannedIP] where ID = @ID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}bannedip_list](@BoardID int,@ID int=null) as
begin
		if @ID is null
		select * from [{databaseOwner}].[{objectQualifier}BannedIP] where BoardID=@BoardID
	else
		select * from [{databaseOwner}].[{objectQualifier}BannedIP] where BoardID=@BoardID and ID=@ID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}bannedip_save](@ID int=null,@BoardID int,@Mask varchar(57), @Reason nvarchar(128), @UserID int) as
begin
		if @ID is null or @ID = 0 begin
		insert into [{databaseOwner}].[{objectQualifier}BannedIP](BoardID,Mask,Since,Reason,UserID) values(@BoardID,@Mask,GETUTCDATE() ,@Reason,@UserID)
	end
	else begin
		update [{databaseOwner}].[{objectQualifier}BannedIP] set Mask = @Mask,Reason = @Reason, UserID = @UserID where ID = @ID
	end
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}board_create](
	@BoardName 		nvarchar(50),
	@Culture char(5),
	@LanguageFile 	nvarchar(50),
	@MembershipAppName nvarchar(50),
	@RolesAppName nvarchar(50),
	@UserName		nvarchar(255),
	@UserEmail		nvarchar(255),
	@UserKey		nvarchar(64),
	@IsHostAdmin	bit
) as 
begin
	declare @BoardID				int
	declare @TimeZone				int
	declare @ForumEmail				nvarchar(50)
	declare	@GroupIDAdmin			int
	declare	@GroupIDGuest			int
	declare @GroupIDMember			int
	declare	@AccessMaskIDAdmin		int
	declare @AccessMaskIDModerator	int
	declare @AccessMaskIDMember		int
	declare	@AccessMaskIDReadOnly	int
	declare @UserIDAdmin			int
	declare @UserIDGuest			int
	declare @RankIDAdmin			int
	declare @RankIDGuest			int
	declare @RankIDNewbie			int
	declare @RankIDMember			int
	declare @RankIDAdvanced			int
	declare	@CategoryID				int
	declare	@ForumID				int
	declare @UserFlags				int

	SET @TimeZone = (SELECT CAST(CAST([Value] as nvarchar(50)) as int) FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE LOWER([Name]) = LOWER('TimeZone'))
	SET @ForumEmail = (SELECT CAST([Value] as nvarchar(50)) FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE LOWER([Name]) = LOWER('ForumEmail'))

	-- Board
	INSERT INTO [{databaseOwner}].[{objectQualifier}Board](Name, AllowThreaded, MembershipAppName, RolesAppName ) values(@BoardName,0, @MembershipAppName, @RolesAppName)
	SET @BoardID = SCOPE_IDENTITY()
	
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'culture',@Culture,@BoardID
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'language',@LanguageFile,@BoardID
	
	-- Rank
	INSERT INTO [{databaseOwner}].[{objectQualifier}Rank](BoardID,Name,Flags,MinPosts,PMLimit,SortOrder) VALUES (@BoardID,'Administration',0,null,2147483647,0)
	SET @RankIDAdmin = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}Rank](BoardID,Name,Flags,MinPosts,PMLimit,SortOrder) VALUES(@BoardID,'Guest',0,null,0,100)
	SET @RankIDGuest = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}Rank](BoardID,Name,Flags,MinPosts,PMLimit,SortOrder) VALUES(@BoardID,'Newbie',3,0,10,3)
	SET @RankIDNewbie = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}Rank](BoardID,Name,Flags,MinPosts,PMLimit,SortOrder) VALUES(@BoardID,'Member',2,10,30,2)
	SET @RankIDMember = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}Rank](BoardID,Name,Flags,MinPosts,PMLimit,SortOrder) VALUES(@BoardID,'Advanced Member',2,30,100,1)
	SET @RankIDAdvanced = SCOPE_IDENTITY()

	-- AccessMask
	INSERT INTO [{databaseOwner}].[{objectQualifier}AccessMask](BoardID,Name,Flags,SortOrder)
	VALUES(@BoardID,'Admin Access',1023 + 1024,4)
	SET @AccessMaskIDAdmin = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}AccessMask](BoardID,Name,Flags,SortOrder)
	VALUES(@BoardID,'Moderator Access',487 + 1024,3)
	SET @AccessMaskIDModerator = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}AccessMask](BoardID,Name,Flags,SortOrder)
	VALUES(@BoardID,'Member Access',423 + 1024,2)
	SET @AccessMaskIDMember = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}AccessMask](BoardID,Name,Flags,SortOrder)
	VALUES(@BoardID,'Read Only Access',1,1)
	SET @AccessMaskIDReadOnly = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}AccessMask](BoardID,Name,Flags,SortOrder)
	VALUES(@BoardID,'No Access',0,0)

	-- Group
	INSERT INTO [{databaseOwner}].[{objectQualifier}Group](BoardID,Name,Flags,PMLimit,Style,SortOrder,UsrSigChars,UsrSigBBCodes,UsrAlbums,UsrAlbumImages) values(@BoardID,'Administrators',1,2147483647,'default!font-size: 8pt; color: red/flatearth!font-size: 8pt; color:blue',0,256,'URL,IMG,SPOILER,QUOTE',10,120)
	set @GroupIDAdmin = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}Group](BoardID,Name,Flags,PMLimit,SortOrder,UsrSigChars,UsrSigBBCodes,UsrAlbums,UsrAlbumImages) values(@BoardID,'Guests',2,0,1,0,null,0,0)
	SET @GroupIDGuest = SCOPE_IDENTITY()
	INSERT INTO [{databaseOwner}].[{objectQualifier}Group](BoardID,Name,Flags,PMLimit,SortOrder,UsrSigChars,UsrSigBBCodes,UsrAlbums,UsrAlbumImages) values(@BoardID,'Registered',4,100,1,128,'URL,IMG,SPOILER,QUOTE',5,30)
	SET @GroupIDMember = SCOPE_IDENTITY()	
	
	-- User (GUEST)
	INSERT INTO [{databaseOwner}].[{objectQualifier}User](BoardID,RankID,[Name],DisplayName,[Password],Joined,LastVisit,NumPosts,TimeZone,Email,Flags)
	VALUES(@BoardID,@RankIDGuest,'Guest','Guest','na',GETUTCDATE() ,GETUTCDATE() ,0,@TimeZone,@ForumEmail,6)
	SET @UserIDGuest = SCOPE_IDENTITY()	
	
	SET @UserFlags = 2
	if @IsHostAdmin<>0 SET @UserFlags = 3
	
	-- User (ADMIN)
	INSERT INTO [{databaseOwner}].[{objectQualifier}User](BoardID,RankID,[Name],DisplayName, [Password], Email,ProviderUserKey, Joined,LastVisit,NumPosts,TimeZone,Flags)
	VALUES(@BoardID,@RankIDAdmin,@UserName,@UserName,'na',@UserEmail,@UserKey,GETUTCDATE() ,GETUTCDATE() ,0,@TimeZone,@UserFlags)
	SET @UserIDAdmin = SCOPE_IDENTITY()

	-- UserGroup
	INSERT INTO [{databaseOwner}].[{objectQualifier}UserGroup](UserID,GroupID) VALUES(@UserIDAdmin,@GroupIDAdmin)
	INSERT INTO [{databaseOwner}].[{objectQualifier}UserGroup](UserID,GroupID) VALUES(@UserIDGuest,@GroupIDGuest)

	-- Category
	INSERT INTO [{databaseOwner}].[{objectQualifier}Category](BoardID,Name,SortOrder) VALUES(@BoardID,'Test Category',1)
	set @CategoryID = SCOPE_IDENTITY()
	
	-- Forum
	INSERT INTO [{databaseOwner}].[{objectQualifier}Forum](CategoryID,Name,Description,SortOrder,NumTopics,NumPosts,Flags)
	VALUES(@CategoryID,'Test Forum','A test forum',1,0,0,4)
	set @ForumID = SCOPE_IDENTITY()

	-- ForumAccess
	INSERT INTO [{databaseOwner}].[{objectQualifier}ForumAccess](GroupID,ForumID,AccessMaskID) VALUES(@GroupIDAdmin,@ForumID,@AccessMaskIDAdmin)
	INSERT INTO [{databaseOwner}].[{objectQualifier}ForumAccess](GroupID,ForumID,AccessMaskID) VALUES(@GroupIDGuest,@ForumID,@AccessMaskIDReadOnly)
	INSERT INTO [{databaseOwner}].[{objectQualifier}ForumAccess](GroupID,ForumID,AccessMaskID) VALUES(@GroupIDMember,@ForumID,@AccessMaskIDMember)

	SELECT @BoardID;
end
GO

create procedure [{databaseOwner}].[{objectQualifier}board_delete](@BoardID int) as
begin
		declare @tmpForumID int;
	declare forum_cursor cursor for
		select ForumID 
		from [{databaseOwner}].[{objectQualifier}Forum] a join [{databaseOwner}].[{objectQualifier}Category] b on a.CategoryID=b.CategoryID
		where b.BoardID=@BoardID
		order by ForumID desc
	
	open forum_cursor
	fetch next from forum_cursor into @tmpForumID
	while @@FETCH_STATUS = 0
	begin
		exec [{databaseOwner}].[{objectQualifier}forum_delete] @tmpForumID;
		fetch next from forum_cursor into @tmpForumID
	end
	close forum_cursor
	deallocate forum_cursor

	delete from [{databaseOwner}].[{objectQualifier}ForumAccess] where exists(select 1 from [{databaseOwner}].[{objectQualifier}Group] x where x.GroupID=[{databaseOwner}].[{objectQualifier}ForumAccess].GroupID and x.BoardID=@BoardID)
	delete from [{databaseOwner}].[{objectQualifier}Forum] where exists(select 1 from [{databaseOwner}].[{objectQualifier}Category] x where x.CategoryID=[{databaseOwner}].[{objectQualifier}Forum].CategoryID and x.BoardID=@BoardID)
	delete from [{databaseOwner}].[{objectQualifier}UserGroup] where exists(select 1 from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=[{databaseOwner}].[{objectQualifier}UserGroup].UserID and x.BoardID=@BoardID)
	delete from [{databaseOwner}].[{objectQualifier}Category] where BoardID=@BoardID
	delete from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID
	delete from [{databaseOwner}].[{objectQualifier}Rank] where BoardID=@BoardID
	delete from [{databaseOwner}].[{objectQualifier}Group] where BoardID=@BoardID
	delete from [{databaseOwner}].[{objectQualifier}AccessMask] where BoardID=@BoardID
	delete from [{databaseOwner}].[{objectQualifier}Active] where BoardID=@BoardID
	delete from [{databaseOwner}].[{objectQualifier}Board] where BoardID=@BoardID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}board_list](@BoardID int=null) as
begin
		select
		a.*,
		SQLVersion = @@VERSION
	from 
		[{databaseOwner}].[{objectQualifier}Board] a
	where
		(@BoardID is null or a.BoardID = @BoardID)
end
GO

create procedure [{databaseOwner}].[{objectQualifier}board_poststats](@BoardID int, @StyledNicks bit = 0, @ShowNoCountPosts bit = 0, @GetDefaults bit = 0 ) as
BEGIN

-- vzrus: while  a new installation or like this we don't have the row and should return a dummy data
IF @GetDefaults <= 0
BEGIN
		SELECT TOP 1 
		Posts = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] a join [{databaseOwner}].[{objectQualifier}Topic] b on b.TopicID=a.TopicID join [{databaseOwner}].[{objectQualifier}Forum] c on c.ForumID=b.ForumID join [{databaseOwner}].[{objectQualifier}Category] d on d.CategoryID=c.CategoryID where d.BoardID=@BoardID AND (a.Flags & 24)=16),
		Topics = (select count(1) from [{databaseOwner}].[{objectQualifier}Topic] a join [{databaseOwner}].[{objectQualifier}Forum] b on b.ForumID=a.ForumID join [{databaseOwner}].[{objectQualifier}Category] c on c.CategoryID=b.CategoryID where c.BoardID=@BoardID AND (a.Flags & 8) <> 8),
		Forums = (select count(1) from [{databaseOwner}].[{objectQualifier}Forum] a join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID=a.CategoryID where b.BoardID=@BoardID),	
		LastPostInfoID	= 1,
		LastPost	= a.Posted,
		LastUserID	= a.UserID,
		LastUser	= e.Name,
		LastUserStyle = (CASE WHEN @StyledNicks > 0 THEN [{databaseOwner}].[{objectQualifier}get_userstyle](a.UserID) ELSE '' END)
			FROM 
				[{databaseOwner}].[{objectQualifier}Message] a 
				join [{databaseOwner}].[{objectQualifier}Topic] b on b.TopicID=a.TopicID 
				join [{databaseOwner}].[{objectQualifier}Forum] c on c.ForumID=b.ForumID 
				join [{databaseOwner}].[{objectQualifier}Category] d on d.CategoryID=c.CategoryID 
				join [{databaseOwner}].[{objectQualifier}User] e on e.UserID=a.UserID				
			WHERE 
				(a.Flags & 24) = 16
				AND (b.Flags & 8) <> 8 
				AND d.BoardID = @BoardID AND (c.Flags & 8) <> (CASE WHEN @ShowNoCountPosts > 0 THEN -1 ELSE 8 END)
			ORDER BY
				a.Posted DESC
		END
		ELSE
		BEGIN
		SELECT
		Posts = 0,
		Topics = 0,
		Forums = 1,	
		LastPostInfoID	= 1,
		LastPost	= null,
		LastUserID	= null,
		LastUser	= null,
		LastUserStyle = ''
		END
		
END
GO

create procedure [{databaseOwner}].[{objectQualifier}board_userstats](@BoardID int) as
BEGIN
		SELECT		
		Members = (select count(1) from [{databaseOwner}].[{objectQualifier}User] a where a.BoardID=@BoardID AND (Flags & 2) = 2 AND (a.Flags & 4) = 0),
		MaxUsers = (SELECT CAST([Value] as nvarchar(255)) FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE LOWER(Name) = LOWER('maxusers') and BoardID=@BoardID),
		MaxUsersWhen = (SELECT CAST([Value] as nvarchar(255)) FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE LOWER(Name) = LOWER('maxuserswhen') and BoardID=@BoardID),		
	    LastMemberInfo.*
	FROM
		(
			SELECT TOP 1 
				LastMemberInfoID= 1,
				LastMemberID	= UserID,
				LastMember	= [Name]
			FROM 
				[{databaseOwner}].[{objectQualifier}User]
			WHERE 
			   -- is approved
				(Flags & 2) = 2
				-- is not a guest
				AND (Flags & 4) <> 4
				AND BoardID = @BoardID 
			ORDER BY 
				Joined DESC
		) as LastMemberInfo
		
END
GO

create procedure [{databaseOwner}].[{objectQualifier}board_save](@BoardID int,@Name nvarchar(50), @LanguageFile nvarchar(50), @Culture char(5), @AllowThreaded bit) as
begin

		EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'culture', @Culture, @BoardID
		EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'language', @LanguageFile, @BoardID
		update [{databaseOwner}].[{objectQualifier}Board] set
		Name = @Name,
		AllowThreaded = @AllowThreaded
	where BoardID=@BoardID
	select @BoardID 
end
GO

create procedure [{databaseOwner}].[{objectQualifier}board_stats]
	@BoardID	int = null
as 
begin
		if (@BoardID is null) begin
		select
			NumPosts	= (select count(1) from [{databaseOwner}].[{objectQualifier}Message] where IsApproved = 1 AND IsDeleted = 0),
			NumTopics	= (select count(1) from [{databaseOwner}].[{objectQualifier}Topic] where IsDeleted = 0),
			NumUsers	= (select count(1) from [{databaseOwner}].[{objectQualifier}User] where IsApproved = 1),
			BoardStart	= (select min(Joined) from [{databaseOwner}].[{objectQualifier}User])
	end
	else begin
		select
			NumPosts	= (select count(1)	
								from [{databaseOwner}].[{objectQualifier}Message] a
								join [{databaseOwner}].[{objectQualifier}Topic] b ON a.TopicID=b.TopicID
								join [{databaseOwner}].[{objectQualifier}Forum] c ON b.ForumID=c.ForumID
								join [{databaseOwner}].[{objectQualifier}Category] d ON c.CategoryID=d.CategoryID
								where a.IsApproved = 1 AND a.IsDeleted = 0 and b.IsDeleted = 0 AND d.BoardID=@BoardID
							),
			NumTopics	= (select count(1) 
								from [{databaseOwner}].[{objectQualifier}Topic] a
								join [{databaseOwner}].[{objectQualifier}Forum] b ON a.ForumID=b.ForumID
								join [{databaseOwner}].[{objectQualifier}Category] c ON b.CategoryID=c.CategoryID
								where c.BoardID=@BoardID AND a.IsDeleted = 0
							),
			NumUsers	= (select count(1) from [{databaseOwner}].[{objectQualifier}User] where IsApproved = 1 and BoardID=@BoardID),
			BoardStart	= (select min(Joined) from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID)
	end
end
GO

create procedure [{databaseOwner}].[{objectQualifier}category_delete](@CategoryID int) as
begin
		declare @flag int
 
	if exists(select 1 from [{databaseOwner}].[{objectQualifier}Forum] where CategoryID = @CategoryID)
	begin
		set @flag = 0
	end else
	begin
		delete from [{databaseOwner}].[{objectQualifier}Category] where CategoryID = @CategoryID
		set @flag = 1
	end

	select @flag
end
GO

create procedure [{databaseOwner}].[{objectQualifier}category_list](@BoardID int,@CategoryID int=null) as
begin
		if @CategoryID is null
		select * from [{databaseOwner}].[{objectQualifier}Category] where BoardID = @BoardID order by SortOrder
	else
		select * from [{databaseOwner}].[{objectQualifier}Category] where BoardID = @BoardID and CategoryID = @CategoryID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}category_listread](@BoardID int,@UserID int,@CategoryID int=null) as
begin
		select 
		a.CategoryID,
		a.Name,
		a.CategoryImage
	from 
		[{databaseOwner}].[{objectQualifier}Category] a
		join [{databaseOwner}].[{objectQualifier}Forum] b on b.CategoryID=a.CategoryID
		join [{databaseOwner}].[{objectQualifier}vaccess] v on v.ForumID=b.ForumID
	where
		a.BoardID=@BoardID and
		v.UserID=@UserID and
		(v.ReadAccess<>0 or (b.Flags & 2)=0) and
		(@CategoryID is null or a.CategoryID=@CategoryID) and
		b.ParentID is null
	group by
		a.CategoryID,
		a.Name,
		a.SortOrder,
		a.CategoryImage
	order by 
		a.SortOrder
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}category_save]
(
	@BoardID    INT,
	@CategoryID INT,
	@Name       NVARCHAR(128),	
	@SortOrder  SMALLINT,
	@CategoryImage NVARCHAR(255) = NULL
)
AS
BEGIN
		IF @CategoryID > 0
	BEGIN
		UPDATE [{databaseOwner}].[{objectQualifier}Category]
		SET    Name = @Name,
			   CategoryImage = @CategoryImage,
			   SortOrder = @SortOrder
		WHERE  CategoryID = @CategoryID
		SELECT CategoryID = @CategoryID
	END
	ELSE
	BEGIN
		INSERT INTO [{databaseOwner}].[{objectQualifier}Category]
				   (BoardID,
					[Name],
					[CategoryImage],
					SortOrder)
		VALUES     (@BoardID,
					@Name,
					@CategoryImage,
					@SortOrder)
		SELECT CategoryID = Scope_identity()
	END
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}checkemail_list]
(
	@Email nvarchar(50) = null
)
AS
BEGIN
		IF @Email IS NULL
		SELECT * FROM [{databaseOwner}].[{objectQualifier}CheckEmail]
	ELSE
		SELECT * FROM [{databaseOwner}].[{objectQualifier}CheckEmail] WHERE Email = LOWER(@Email)
END
GO

create procedure [{databaseOwner}].[{objectQualifier}checkemail_save]
(
	@UserID int,
	@Hash nvarchar(32),
	@Email nvarchar(50)
)
AS
BEGIN
		INSERT INTO [{databaseOwner}].[{objectQualifier}CheckEmail]
		(UserID,Email,Created,Hash)
	VALUES
		(@UserID,LOWER(@Email),GETUTCDATE() ,@Hash)	
END
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}checkemail_update](@Hash nvarchar(32)) as
begin
		declare @UserID int
	declare @CheckEmailID int
	declare @Email nvarchar(50)

	set @UserID = null

	select 
		@CheckEmailID = CheckEmailID,
		@UserID = UserID,
		@Email = Email
	from
		[{databaseOwner}].[{objectQualifier}CheckEmail]
	where
		Hash = @Hash

	if @UserID is null
	begin
		select convert(nvarchar(64),NULL) as ProviderUserKey, convert(nvarchar(255),NULL) as Email
		return
	end

	-- Update new user email
	update [{databaseOwner}].[{objectQualifier}User] set Email = LOWER(@Email), Flags = Flags | 2 where UserID = @UserID
	delete [{databaseOwner}].[{objectQualifier}CheckEmail] where CheckEmailID = @CheckEmailID

	-- return the UserProviderKey
	SELECT ProviderUserKey, Email FROM [{databaseOwner}].[{objectQualifier}User] WHERE UserID = @UserID
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}choice_vote](@ChoiceID int,@UserID int = NULL, @RemoteIP varchar(39) = NULL) AS
BEGIN
		DECLARE @PollID int

	SET @PollID = (SELECT PollID FROM [{databaseOwner}].[{objectQualifier}Choice] WHERE ChoiceID = @ChoiceID)

	IF @UserID = NULL
	BEGIN
		IF @RemoteIP != NULL
		BEGIN
			INSERT INTO [{databaseOwner}].[{objectQualifier}PollVote] (PollID, UserID, RemoteIP) VALUES (@PollID,NULL,@RemoteIP)	
		END
	END
	ELSE
	BEGIN
		INSERT INTO [{databaseOwner}].[{objectQualifier}PollVote] (PollID, UserID, RemoteIP) VALUES (@PollID,@UserID,@RemoteIP)
	END

	UPDATE [{databaseOwner}].[{objectQualifier}Choice] SET Votes = Votes + 1 WHERE ChoiceID = @ChoiceID
END
GO

create procedure [{databaseOwner}].[{objectQualifier}eventlog_create](@UserID int,@Source nvarchar(50),@Description ntext,@Type int) as
begin
		insert into [{databaseOwner}].[{objectQualifier}EventLog](UserID,Source,Description,Type)
	values(@UserID,@Source,@Description,@Type)

	-- delete entries older than 10 days
	delete from [{databaseOwner}].[{objectQualifier}EventLog] where EventTime+10<GETUTCDATE() 

	-- or if there are more then 1000	
	if ((select count(*) from [{databaseOwner}].[{objectQualifier}eventlog]) >= 1050)
	begin
		
		delete from [{databaseOwner}].[{objectQualifier}EventLog] WHERE EventLogID IN (SELECT TOP 100 EventLogID FROM [{databaseOwner}].[{objectQualifier}EventLog] ORDER BY EventTime)
	end	
	
end
GO

create procedure [{databaseOwner}].[{objectQualifier}eventlog_delete]
(
	@EventLogID int = null, 
	@BoardID int = null
) as
begin
		-- either EventLogID or BoardID must be null, not both at the same time
	if (@EventLogID is null) begin
		-- delete all events of this board
		delete from [{databaseOwner}].[{objectQualifier}EventLog]
		where
			(UserID is null or
			UserID in (select UserID from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID))
	end
	else begin
		-- delete just one event
		delete from [{databaseOwner}].[{objectQualifier}EventLog] where EventLogID=@EventLogID
	end
end
GO

create procedure [{databaseOwner}].[{objectQualifier}eventlog_list](@BoardID int) as
begin
		select
		a.*,
		ISNULL(b.[Name],'System') as [Name]
	from
		[{databaseOwner}].[{objectQualifier}EventLog] a
		left join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=a.UserID
	where
		(b.UserID IS NULL or b.BoardID = @BoardID)		
	order by
		a.EventLogID desc
end
GO

create procedure [{databaseOwner}].[{objectQualifier}extension_delete] (@ExtensionID int) as
begin
		delete from [{databaseOwner}].[{objectQualifier}Extension] 
	where ExtensionID = @ExtensionID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}extension_edit] (@ExtensionID int=NULL) as
BEGIN
		SELECT * 
	FROM [{databaseOwner}].[{objectQualifier}Extension] 
	WHERE ExtensionID = @ExtensionID 
	ORDER BY Extension
END
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}extension_list] (@BoardID int, @Extension nvarchar(10)) as
BEGIN
	
	-- If an extension is passed, then we want to check for THAT extension
	IF LEN(@Extension) > 0
		BEGIN
			SELECT
				a.*
			FROM
				[{databaseOwner}].[{objectQualifier}Extension] a
			WHERE
				a.BoardID = @BoardID AND a.Extension=@Extension
			ORDER BY
				a.Extension
		END

	ELSE
		-- Otherwise, just get a list for the given @BoardId
		BEGIN
			SELECT
				a.*
			FROM
				[{databaseOwner}].[{objectQualifier}Extension] a
			WHERE
				a.BoardID = @BoardID	
			ORDER BY
				a.Extension
		END
END
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}extension_save] (@ExtensionID int=null,@BoardID int,@Extension nvarchar(10)) as
begin
		if @ExtensionID is null or @ExtensionID = 0 begin
		insert into [{databaseOwner}].[{objectQualifier}Extension] (BoardID,Extension) 
		values(@BoardID,@Extension)
	end
	else begin
		update [{databaseOwner}].[{objectQualifier}Extension] 
		set Extension = @Extension 
		where ExtensionID = @ExtensionID
	end
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}forum_delete](@ForumID int) as
begin
		-- Maybe an idea to use cascading foreign keys instead? Too bad they don't work on MS SQL 7.0...
	update [{databaseOwner}].[{objectQualifier}Forum] set LastMessageID=null,LastTopicID=null where ForumID=@ForumID
	update [{databaseOwner}].[{objectQualifier}Topic] set LastMessageID=null where ForumID=@ForumID
	update [{databaseOwner}].[{objectQualifier}Active] set ForumID=null where ForumID=@ForumID
	delete from [{databaseOwner}].[{objectQualifier}WatchTopic] from [{databaseOwner}].[{objectQualifier}Topic] where [{databaseOwner}].[{objectQualifier}Topic].ForumID = @ForumID and [{databaseOwner}].[{objectQualifier}WatchTopic].TopicID = [{databaseOwner}].[{objectQualifier}Topic].TopicID
	delete from [{databaseOwner}].[{objectQualifier}Active] from [{databaseOwner}].[{objectQualifier}Topic] where [{databaseOwner}].[{objectQualifier}Topic].ForumID = @ForumID and [{databaseOwner}].[{objectQualifier}Active].TopicID = [{databaseOwner}].[{objectQualifier}Topic].TopicID
	delete from [{databaseOwner}].[{objectQualifier}NntpTopic] from [{databaseOwner}].[{objectQualifier}NntpForum] where [{databaseOwner}].[{objectQualifier}NntpForum].ForumID = @ForumID and [{databaseOwner}].[{objectQualifier}NntpTopic].NntpForumID = [{databaseOwner}].[{objectQualifier}NntpForum].NntpForumID
	delete from [{databaseOwner}].[{objectQualifier}NntpForum] where ForumID=@ForumID	
	delete from [{databaseOwner}].[{objectQualifier}WatchForum] where ForumID = @ForumID

	-- BAI CHANGED 02.02.2004
	-- Delete topics, messages and attachments

	declare @tmpTopicID int;
	declare topic_cursor cursor for
		select TopicID from [{databaseOwner}].[{objectQualifier}topic]
		where ForumID = @ForumID
		order by TopicID desc
	
	open topic_cursor
	
	fetch next from topic_cursor
	into @tmpTopicID
	
	-- Check @@FETCH_STATUS to see if there are any more rows to fetch.
	while @@FETCH_STATUS = 0
	begin
		exec [{databaseOwner}].[{objectQualifier}topic_delete] @tmpTopicID,1,1;
	
	   -- This is executed as long as the previous fetch succeeds.
		fetch next from topic_cursor
		into @tmpTopicID
	end
	
	close topic_cursor
	deallocate topic_cursor

	-- TopicDelete finished
	-- END BAI CHANGED 02.02.2004

	delete from [{databaseOwner}].[{objectQualifier}ForumAccess] where ForumID = @ForumID
	--ABOT CHANGED
	--Delete UserForums Too 
	delete from [{databaseOwner}].[{objectQualifier}UserForum] where ForumID = @ForumID
	--END ABOT CHANGED 09.04.2004
	delete from [{databaseOwner}].[{objectQualifier}Forum] where ForumID = @ForumID
end

GO

create procedure [{databaseOwner}].[{objectQualifier}forum_list](@BoardID int,@ForumID int=null) as
begin
	if @ForumID = 0 set @ForumID = null
	if @ForumID is null
		select a.* from [{databaseOwner}].[{objectQualifier}Forum] a join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID=a.CategoryID where b.BoardID=@BoardID order by a.SortOrder
	else
		select a.* from [{databaseOwner}].[{objectQualifier}Forum] a join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID=a.CategoryID where b.BoardID=@BoardID and a.ForumID = @ForumID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}forum_listall] (@BoardID int,@UserID int,@root int = 0) as
begin
	if @root = 0
begin
	  select
		b.CategoryID,
		Category = b.Name,
		a.ForumID,
		Forum = a.Name,
		Indent = 0,
		a.ParentID,
		a.PollGroupID
	from
		[{databaseOwner}].[{objectQualifier}Forum] a
		join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID=a.CategoryID
		join [{databaseOwner}].[{objectQualifier}vaccess] c on c.ForumID=a.ForumID
	where
		c.UserID=@UserID and
		b.BoardID=@BoardID and
		c.ReadAccess>0
	order by
		b.SortOrder,
		a.SortOrder,
		b.CategoryID,
		a.ForumID
end
else if  @root > 0
begin
	select
		b.CategoryID,
		Category = b.Name,
		a.ForumID,
		Forum = a.Name,
		Indent = 0,
		a.ParentID
	from
		[{databaseOwner}].[{objectQualifier}Forum] a
		join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID=a.CategoryID
		join [{databaseOwner}].[{objectQualifier}vaccess] c on c.ForumID=a.ForumID
	where
		c.UserID=@UserID and
		b.BoardID=@BoardID and
		c.ReadAccess>0 and
		a.ForumID = @root

	order by
		b.SortOrder,
		a.SortOrder,
		b.CategoryID,
		a.ForumID
end
else
begin
	select
		b.CategoryID,
		Category = b.Name,
		a.ForumID,
		Forum = a.Name,
		Indent = 0,
		a.ParentID
	from
		[{databaseOwner}].[{objectQualifier}Forum] a
		join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID=a.CategoryID
		join [{databaseOwner}].[{objectQualifier}vaccess] c on c.ForumID=a.ForumID
	where
		c.UserID=@UserID and
		b.BoardID=@BoardID and
		c.ReadAccess>0 and
		b.CategoryID = -@root

	order by
		b.SortOrder,
		a.SortOrder,
		b.CategoryID,
		a.ForumID
end
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}forum_listall_fromcat](@BoardID int,@CategoryID int) AS
BEGIN
		SELECT     b.CategoryID, b.Name AS Category, a.ForumID, a.Name AS Forum, a.ParentID, a.PollGroupID 
	FROM         [{databaseOwner}].[{objectQualifier}Forum] a INNER JOIN
						  [{databaseOwner}].[{objectQualifier}Category] b ON b.CategoryID = a.CategoryID
		WHERE
			b.CategoryID=@CategoryID and
			b.BoardID=@BoardID
		ORDER BY
			b.SortOrder,
			a.SortOrder
END
GO

create procedure [{databaseOwner}].[{objectQualifier}forum_listallmymoderated](@BoardID int,@UserID int) as
begin
		select
		b.CategoryID,
		Category = b.Name,
		a.ForumID,
		Forum = a.Name,
		x.Indent
	from
		(select
			b.ForumID,
			Indent = 0
		from
			[{databaseOwner}].[{objectQualifier}Category] a
			join [{databaseOwner}].[{objectQualifier}Forum] b on b.CategoryID=a.CategoryID
		where
			a.BoardID=@BoardID and
			b.ParentID is null
	
		union
	
		select
			c.ForumID,
			Indent = 1
		from
			[{databaseOwner}].[{objectQualifier}Category] a
			join [{databaseOwner}].[{objectQualifier}Forum] b on b.CategoryID=a.CategoryID
			join [{databaseOwner}].[{objectQualifier}Forum] c on c.ParentID=b.ForumID
		where
			a.BoardID=@BoardID and
			b.ParentID is null
	
		union
	
		select
			d.ForumID,
			Indent = 2
		from
			[{databaseOwner}].[{objectQualifier}Category] a
			join [{databaseOwner}].[{objectQualifier}Forum] b on b.CategoryID=a.CategoryID
			join [{databaseOwner}].[{objectQualifier}Forum] c on c.ParentID=b.ForumID
			join [{databaseOwner}].[{objectQualifier}Forum] d on d.ParentID=c.ForumID
		where
			a.BoardID=@BoardID and
			b.ParentID is null
		) as x
		join [{databaseOwner}].[{objectQualifier}Forum] a on a.ForumID=x.ForumID
		join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID=a.CategoryID
		join [{databaseOwner}].[{objectQualifier}vaccess] c on c.ForumID=a.ForumID
	where
		c.UserID=@UserID and
		b.BoardID=@BoardID and
		c.ModeratorAccess>0
	order by
		b.SortOrder,
		a.SortOrder
end
GO

create procedure [{databaseOwner}].[{objectQualifier}forum_listpath](@ForumID int) as
begin
		-- supports up to 4 levels of nested forums
	select
		a.ForumID,
		a.Name
	from
		(select
			a.ForumID,
			Indent = 0
		from
			[{databaseOwner}].[{objectQualifier}Forum] a
		where
			a.ForumID=@ForumID

		union

		select
			b.ForumID,
			Indent = 1
		from
			[{databaseOwner}].[{objectQualifier}Forum] a
			join [{databaseOwner}].[{objectQualifier}Forum] b on b.ForumID=a.ParentID
		where
			a.ForumID=@ForumID

		union

		select
			c.ForumID,
			Indent = 2
		from
			[{databaseOwner}].[{objectQualifier}Forum] a
			join [{databaseOwner}].[{objectQualifier}Forum] b on b.ForumID=a.ParentID
			join [{databaseOwner}].[{objectQualifier}Forum] c on c.ForumID=b.ParentID
		where
			a.ForumID=@ForumID

		union 

		select
			d.ForumID,
			Indent = 3
		from
			[{databaseOwner}].[{objectQualifier}Forum] a
			join [{databaseOwner}].[{objectQualifier}Forum] b on b.ForumID=a.ParentID
			join [{databaseOwner}].[{objectQualifier}Forum] c on c.ForumID=b.ParentID
			join [{databaseOwner}].[{objectQualifier}Forum] d on d.ForumID=c.ParentID
		where
			a.ForumID=@ForumID
		) as x	
		join [{databaseOwner}].[{objectQualifier}Forum] a on a.ForumID=x.ForumID
	order by
		x.Indent desc
end
GO

create procedure [{databaseOwner}].[{objectQualifier}forum_listread](@BoardID int,@UserID int,@CategoryID int=null,@ParentID int=null) as
begin
		select 
		a.CategoryID, 
		Category		= a.Name, 
		ForumID			= b.ForumID,
		Forum			= b.Name, 
		b.[Description],
		b.ImageUrl,
		b.Styles,
		b.PollGroupID,
		Topics			= [{databaseOwner}].[{objectQualifier}forum_topics](b.ForumID),
		Posts			= [{databaseOwner}].[{objectQualifier}forum_posts](b.ForumID),
		Subforums		= [{databaseOwner}].[{objectQualifier}forum_subforums](b.ForumID, @UserID),
		LastPosted		= t.LastPosted,
		LastMessageID	= t.LastMessageID,
		LastMessageFlags = t.LastMessageFlags,
		LastUserID		= t.LastUserID,
		LastUser		= IsNull(t.LastUserName,(select Name from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=t.LastUserID)),
		LastTopicID		= t.TopicID,
		TopicMovedID    = t.TopicMovedID,
		LastTopicName	= t.Topic,
		b.Flags,
		Viewing			= (select count(1) from [{databaseOwner}].[{objectQualifier}Active] x JOIN [{databaseOwner}].[{objectQualifier}User] usr ON x.UserID = usr.UserID where x.ForumID=b.ForumID AND usr.IsActiveExcluded = 0),
		b.RemoteURL,
		x.ReadAccess
	from 
		[{databaseOwner}].[{objectQualifier}Category] a
		join [{databaseOwner}].[{objectQualifier}Forum] b on b.CategoryID=a.CategoryID
		join [{databaseOwner}].[{objectQualifier}vaccess] x on x.ForumID=b.ForumID
		left outer join [{databaseOwner}].[{objectQualifier}Topic] t ON t.TopicID = [{databaseOwner}].[{objectQualifier}forum_lasttopic](b.ForumID,@UserID,b.LastTopicID,b.LastPosted)
	where 
		a.BoardID = @BoardID and
		((b.Flags & 2)=0 or x.ReadAccess<>0) and
		(@CategoryID is null or a.CategoryID=@CategoryID) and
		((@ParentID is null and b.ParentID is null) or b.ParentID=@ParentID) and
		x.UserID = @UserID
	order by
		a.SortOrder,
		b.SortOrder
end
GO

create procedure [{databaseOwner}].[{objectQualifier}forum_listSubForums](@ForumID int) as
begin
		select Sum(1) from [{databaseOwner}].[{objectQualifier}Forum] where ParentID = @ForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}forum_listtopics](@ForumID int) as
begin
		select * from [{databaseOwner}].[{objectQualifier}Topic]
	Where ForumID = @ForumID
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}forum_moderatelist](@BoardID int,@UserID int) AS
BEGIN
	
SELECT
		b.*,
		MessageCount  = 
		(SELECT     count([{databaseOwner}].[{objectQualifier}Message].MessageID)
		FROM         [{databaseOwner}].[{objectQualifier}Message] INNER JOIN
							  [{databaseOwner}].[{objectQualifier}Topic] ON [{databaseOwner}].[{objectQualifier}Message].TopicID = [{databaseOwner}].[{objectQualifier}Topic].TopicID
		WHERE (([{databaseOwner}].[{objectQualifier}Message].Flags & 16)=0) and (([{databaseOwner}].[{objectQualifier}Message].Flags & 8)=0) and (([{databaseOwner}].[{objectQualifier}Topic].Flags & 8) = 0) AND ([{databaseOwner}].[{objectQualifier}Topic].ForumID=b.ForumID)),

		ReportedCount	= 
		(SELECT     count([{databaseOwner}].[{objectQualifier}Message].MessageID)
		FROM         [{databaseOwner}].[{objectQualifier}Message] INNER JOIN
							  [{databaseOwner}].[{objectQualifier}Topic] ON [{databaseOwner}].[{objectQualifier}Message].TopicID = [{databaseOwner}].[{objectQualifier}Topic].TopicID
		WHERE (([{databaseOwner}].[{objectQualifier}Message].Flags & 128)=128) and (([{databaseOwner}].[{objectQualifier}Message].Flags & 8)=0) and (([{databaseOwner}].[{objectQualifier}Topic].Flags & 8) = 0) AND ([{databaseOwner}].[{objectQualifier}Topic].ForumID=b.ForumID))
		FROM
		[{databaseOwner}].[{objectQualifier}Category] a

	JOIN [{databaseOwner}].[{objectQualifier}Forum] b ON b.CategoryID=a.CategoryID
	JOIN [{databaseOwner}].[{objectQualifier}vaccess] c ON c.ForumID=b.ForumID

	WHERE
		a.BoardID=@BoardID AND
		c.ModeratorAccess>0 AND
		c.UserID=@UserID
	ORDER BY
		a.SortOrder,
		b.SortOrder
END
GO

create procedure [{databaseOwner}].[{objectQualifier}forum_moderators] as
BEGIN
		select
		ForumID = a.ForumID, 
		ModeratorID = a.GroupID, 
		ModeratorName = b.Name,
		IsGroup=1
	from
		[{databaseOwner}].[{objectQualifier}ForumAccess] a WITH(NOLOCK)
		INNER JOIN [{databaseOwner}].[{objectQualifier}Group] b WITH(NOLOCK) ON b.GroupID = a.GroupID
		INNER JOIN [{databaseOwner}].[{objectQualifier}AccessMask] c WITH(NOLOCK) ON c.AccessMaskID = a.AccessMaskID
	where
		(b.Flags & 1)=0 and
		(c.Flags & 64)<>0
	union all
	select 
		ForumID = access.ForumID, 
		ModeratorID = usr.UserID, 
		ModeratorName = usr.Name,
		IsGroup=0
	from
		[{databaseOwner}].[{objectQualifier}User] usr WITH(NOLOCK)
		INNER JOIN (
			select
				UserID				= a.UserID,
				ForumID				= x.ForumID,
				ModeratorAccess		= MAX(ModeratorAccess)
			from
				[{databaseOwner}].[{objectQualifier}vaccessfull] as x WITH(NOLOCK)
				INNER JOIN [{databaseOwner}].[{objectQualifier}UserGroup] a WITH(NOLOCK) on a.UserID=x.UserID
				INNER JOIN [{databaseOwner}].[{objectQualifier}Group] b WITH(NOLOCK) on b.GroupID=a.GroupID
			WHERE 
				ModeratorAccess <> 0 AND x.AdminGroup = 0
			GROUP BY a.UserId, x.ForumID
		) access ON usr.UserID = access.UserID
	where
		access.ModeratorAccess<>0
	order by
		IsGroup desc,
		ModeratorName asc
END
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}forum_save](
	@ForumID 		int,
	@CategoryID		int,
	@ParentID		int=null,
	@Name			nvarchar(50),
	@Description	nvarchar(255),
	@SortOrder		smallint,
	@Locked			bit,
	@Hidden			bit,
	@IsTest			bit,
	@Moderated		bit,
	@RemoteURL		nvarchar(100)=null,
	@ThemeURL		nvarchar(100)=null,
	@ImageURL       nvarchar(128)=null,
	@Styles         nvarchar(255)=null,
	@AccessMaskID	int = null
) as
begin
	declare @BoardID	int
	declare @Flags		int	
	
	set @Flags = 0
	if @Locked<>0 set @Flags = @Flags | 1
	if @Hidden<>0 set @Flags = @Flags | 2
	if @IsTest<>0 set @Flags = @Flags | 4
	if @Moderated<>0 set @Flags = @Flags | 8
	
	if @ForumID = 0 set @ForumID = null
	if @ParentID = 0 set @ParentID = null
	
	if @ForumID is not null begin	
		update [{databaseOwner}].[{objectQualifier}Forum] set 
			ParentID=@ParentID,
			Name=@Name,
			[Description]=@Description,
			SortOrder=@SortOrder,
			CategoryID=@CategoryID,
			RemoteURL = @RemoteURL,
			ThemeURL = @ThemeURL,
			ImageURL = @ImageURL,
			Styles = @Styles,
			Flags = @Flags
		where ForumID=@ForumID
	end
	else begin
		select @BoardID=BoardID from [{databaseOwner}].[{objectQualifier}Category] where CategoryID=@CategoryID
	
		insert into [{databaseOwner}].[{objectQualifier}Forum](ParentID,Name,Description,SortOrder,CategoryID,NumTopics,NumPosts,RemoteURL,ThemeURL,Flags,ImageURL,Styles)
		values(@ParentID,@Name,@Description,@SortOrder,@CategoryID,0,0,@RemoteURL,@ThemeURL,@Flags,@ImageURL,@Styles)
		select @ForumID = SCOPE_IDENTITY()

		insert into [{databaseOwner}].[{objectQualifier}ForumAccess](GroupID,ForumID,AccessMaskID) 
		select GroupID,@ForumID,@AccessMaskID
		from [{databaseOwner}].[{objectQualifier}Group]
		where BoardID=@BoardID
	end
	select ForumID = @ForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}forum_updatelastpost](@ForumID int) as
begin
		update [{databaseOwner}].[{objectQualifier}Forum] set
		LastPosted = (select top 1 y.Posted from [{databaseOwner}].[{objectQualifier}Topic] x join [{databaseOwner}].[{objectQualifier}Message] y on y.TopicID=x.TopicID where x.ForumID = @ForumID and (y.Flags & 24)=16 and x.IsDeleted = 0 order by y.Posted desc),
		LastTopicID = (select top 1 y.TopicID from [{databaseOwner}].[{objectQualifier}Topic] x join [{databaseOwner}].[{objectQualifier}Message] y on y.TopicID=x.TopicID where x.ForumID = @ForumID and (y.Flags & 24)=16 and x.IsDeleted = 0order by y.Posted desc),
		LastMessageID = (select top 1 y.MessageID from [{databaseOwner}].[{objectQualifier}Topic] x join [{databaseOwner}].[{objectQualifier}Message] y on y.TopicID=x.TopicID where x.ForumID = @ForumID and (y.Flags & 24)=16 and x.IsDeleted = 0order by y.Posted desc),
		LastUserID = (select top 1 y.UserID from [{databaseOwner}].[{objectQualifier}Topic] x join [{databaseOwner}].[{objectQualifier}Message] y on y.TopicID=x.TopicID where x.ForumID = @ForumID and (y.Flags & 24)=16 and x.IsDeleted = 0order by y.Posted desc),
		LastUserName = (select top 1 y.UserName from [{databaseOwner}].[{objectQualifier}Topic] x join [{databaseOwner}].[{objectQualifier}Message] y on y.TopicID=x.TopicID where x.ForumID = @ForumID and (y.Flags & 24)=16 and x.IsDeleted = 0order by y.Posted desc)
	where ForumID = @ForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}forum_updatestats](@ForumID int) as
begin
		update [{databaseOwner}].[{objectQualifier}Forum] set 
		NumPosts = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x join [{databaseOwner}].[{objectQualifier}Topic] y on y.TopicID=x.TopicID where y.ForumID = @ForumID and x.IsApproved = 1 and x.IsDeleted = 0 and y.IsDeleted = 0 ),
		NumTopics = (select count(distinct x.TopicID) from [{databaseOwner}].[{objectQualifier}Topic] x join [{databaseOwner}].[{objectQualifier}Message] y on y.TopicID=x.TopicID where x.ForumID = @ForumID and y.IsApproved = 1 and y.IsDeleted = 0 and x.IsDeleted = 0)
	where ForumID=@ForumID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}forumaccess_group](@GroupID int) as
begin
		select 
		a.*,
		ForumName = b.Name,
		CategoryName = c.Name ,
		CategoryID = b.CategoryID,
		ParentID = b.ParentID,
		BoardName = brd.Name 
	from 
		[{databaseOwner}].[{objectQualifier}ForumAccess] a
		inner join [{databaseOwner}].[{objectQualifier}Forum] b on b.ForumID=a.ForumID
		inner join [{databaseOwner}].[{objectQualifier}Category] c on c.CategoryID=b.CategoryID
		inner join [{databaseOwner}].[{objectQualifier}Board] brd on brd.BoardID=c.BoardID
	where 
		a.GroupID = @GroupID
	order by
		brd.Name,
		c.SortOrder,
		b.SortOrder
end
GO

create procedure [{databaseOwner}].[{objectQualifier}forumaccess_list](@ForumID int) as
begin
		select 
		a.*,
		GroupName=b.Name 
	from 
		[{databaseOwner}].[{objectQualifier}ForumAccess] a 
		inner join [{databaseOwner}].[{objectQualifier}Group] b on b.GroupID=a.GroupID
	where 
		a.ForumID = @ForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}forumaccess_save](
	@ForumID			int,
	@GroupID			int,
	@AccessMaskID		int
) as
begin
		update [{databaseOwner}].[{objectQualifier}ForumAccess]
		set AccessMaskID=@AccessMaskID
	where 
		ForumID = @ForumID and 
		GroupID = @GroupID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}group_delete](@GroupID int) as
begin
	delete from [{databaseOwner}].[{objectQualifier}ForumAccess] where GroupID = @GroupID
	delete from [{databaseOwner}].[{objectQualifier}UserGroup] where GroupID = @GroupID
	delete from [{databaseOwner}].[{objectQualifier}Group] where GroupID = @GroupID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}group_list](@BoardID int,@GroupID int=null) as
begin
		if @GroupID is null
		select * from [{databaseOwner}].[{objectQualifier}Group] where BoardID=@BoardID
	else
		select * from [{databaseOwner}].[{objectQualifier}Group] where BoardID=@BoardID and GroupID=@GroupID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}group_member](@BoardID int,@UserID int) as
begin
		select 
		a.GroupID,
		a.Name,
		Member = (select count(1) from [{databaseOwner}].[{objectQualifier}UserGroup] x where x.UserID=@UserID and x.GroupID=a.GroupID)
	from
		[{databaseOwner}].[{objectQualifier}Group] a
	where
		a.BoardID=@BoardID
	order by
		a.Name
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}group_save](
	@GroupID		int,
	@BoardID		int,
	@Name			nvarchar(50),
	@IsAdmin		bit,
	@IsStart		bit,
	@IsModerator	bit,
	@IsGuest		bit,
	@AccessMaskID	int=null,
	@PMLimit int=null,
	@Style nvarchar(255)=null,
	@SortOrder smallint,
	@Description nvarchar(128)=null,
	@UsrSigChars int=null,
	@UsrSigBBCodes	nvarchar(255)=null,
	@UsrSigHTMLTags nvarchar(255)=null,
	@UsrAlbums int=null,
	@UsrAlbumImages int=null
) as
begin
		declare @Flags	int
	
	set @Flags = 0
	if @IsAdmin<>0 set @Flags = @Flags | 1
	if @IsGuest<>0 set @Flags = @Flags | 2
	if @IsStart<>0 set @Flags = @Flags | 4
	if @IsModerator<>0 set @Flags = @Flags | 8

	if @GroupID>0 begin
		update [{databaseOwner}].[{objectQualifier}Group] set
			Name = @Name,
			Flags = @Flags,
			PMLimit = @PMLimit,
			Style = @Style,
			SortOrder = @SortOrder,
			Description = @Description,
			UsrSigChars = @UsrSigChars,
			UsrSigBBCodes = @UsrSigBBCodes,
			UsrSigHTMLTags = @UsrSigHTMLTags,
			UsrAlbums = @UsrAlbums,
			UsrAlbumImages = @UsrAlbumImages 
		where GroupID = @GroupID
	end
	else begin
		insert into [{databaseOwner}].[{objectQualifier}Group](Name,BoardID,Flags,PMLimit,Style, SortOrder,Description,UsrSigChars,UsrSigBBCodes,UsrSigHTMLTags,UsrAlbums,UsrAlbumImages)
		values(@Name,@BoardID,@Flags,@PMLimit,@Style,@SortOrder,@Description,@UsrSigChars,@UsrSigBBCodes,@UsrSigHTMLTags,@UsrAlbums,@UsrAlbumImages);
		set @GroupID = SCOPE_IDENTITY()
		insert into [{databaseOwner}].[{objectQualifier}ForumAccess](GroupID,ForumID,AccessMaskID)
		select @GroupID,a.ForumID,@AccessMaskID from [{databaseOwner}].[{objectQualifier}Forum] a join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID=a.CategoryID where b.BoardID=@BoardID
	end
	select GroupID = @GroupID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}group_rank_style]( @BoardID int) as
begin
-- added fields to get overall info about groups and ranks
SELECT 1 AS LegendID,[Name],Style, PMLimit,Description,UsrSigChars,UsrSigBBCodes,UsrSigHTMLTags,UsrAlbums,UsrAlbumImages FROM [{databaseOwner}].[{objectQualifier}Group]
WHERE BoardID = @BoardID GROUP BY SortOrder,[Name],Style,Description,PMLimit,UsrSigChars,UsrSigBBCodes,UsrSigHTMLTags,UsrAlbums,UsrAlbumImages
UNION
SELECT 2  AS LegendID,[Name],Style,PMLimit, Description,UsrSigChars,UsrSigBBCodes,UsrSigHTMLTags,UsrAlbums,UsrAlbumImages FROM [{databaseOwner}].[{objectQualifier}Rank]
WHERE BoardID = @BoardID GROUP BY SortOrder,[Name],Style,Description,PMLimit,UsrSigChars,UsrSigBBCodes,UsrSigHTMLTags,UsrAlbums,UsrAlbumImages
end
GO

create procedure [{databaseOwner}].[{objectQualifier}mail_create]
(
	@From nvarchar(255),
	@FromName nvarchar(255) = NULL,
	@To nvarchar(255),
	@ToName nvarchar(255) = NULL,
	@Subject nvarchar(100),
	@Body ntext,
	@BodyHtml ntext = NULL
)
AS 
BEGIN
		insert into [{databaseOwner}].[{objectQualifier}Mail]
		(FromUser,FromUserName,ToUser,ToUserName,Created,Subject,Body,BodyHtml)
	values
		(@From,@FromName,@To,@ToName,GETUTCDATE() ,@Subject,@Body,@BodyHtml)	
END
GO

create procedure [{databaseOwner}].[{objectQualifier}mail_createwatch]
(
	@TopicID int,
	@From nvarchar(255),
	@FromName nvarchar(255) = NULL,
	@Subject nvarchar(100),
	@Body ntext,
	@BodyHtml ntext = null,
	@UserID int
)
AS
BEGIN
	insert into [{databaseOwner}].[{objectQualifier}Mail](FromUser,FromUserName,ToUser,ToUserName,Created,Subject,Body,BodyHtml)
	select
		@From,
		@FromName,
		b.Email,
		b.Name,
		GETUTCDATE() ,
		@Subject,
		@Body,
		@BodyHtml
	from
		[{databaseOwner}].[{objectQualifier}WatchTopic] a
		inner join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=a.UserID
	where
		b.UserID <> @UserID and
		b.NotificationType NOT IN (10, 20) AND
		a.TopicID = @TopicID and
		(a.LastMail is null or a.LastMail < b.LastVisit)
	
	insert into [{databaseOwner}].[{objectQualifier}Mail](FromUser,FromUserName,ToUser,ToUserName,Created,Subject,Body,BodyHtml)
	select
		@From,
		@FromName,
		b.Email,
		b.Name,
		GETUTCDATE(),
		@Subject,
		@Body,
		@BodyHtml
	from
		[{databaseOwner}].[{objectQualifier}WatchForum] a
		inner join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=a.UserID
		inner join [{databaseOwner}].[{objectQualifier}Topic] c on c.ForumID=a.ForumID
	where
		b.UserID <> @UserID and
		b.NotificationType NOT IN (10, 20) AND
		c.TopicID = @TopicID and
		(a.LastMail is null or a.LastMail < b.LastVisit) and
		not exists(select 1 from [{databaseOwner}].[{objectQualifier}WatchTopic] x where x.UserID=b.UserID and x.TopicID=c.TopicID)

	update [{databaseOwner}].[{objectQualifier}WatchTopic] set LastMail = GETUTCDATE()
	where TopicID = @TopicID
	and UserID <> @UserID
	
	update [{databaseOwner}].[{objectQualifier}WatchForum] set LastMail = GETUTCDATE()  
	where ForumID = (select ForumID from [{databaseOwner}].[{objectQualifier}Topic] where TopicID = @TopicID)
	and UserID <> @UserID
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}mail_delete](@MailID int) as
BEGIN
		DELETE FROM [{databaseOwner}].[{objectQualifier}Mail] WHERE MailID = @MailID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}mail_list]
(
	@ProcessID int
)
AS
BEGIN
		UPDATE [{databaseOwner}].[{objectQualifier}Mail]
	SET 
		SendTries = SendTries + 1,
		SendAttempt = DATEADD(n,5,GETUTCDATE()),
		ProcessID = @ProcessID
	WHERE
		MailID IN (SELECT TOP 10 MailID FROM [{databaseOwner}].[{objectQualifier}Mail] WHERE SendAttempt < GETUTCDATE() OR SendAttempt IS NULL ORDER BY SendAttempt, Created)

	-- now select all mail reserved for this process...
	SELECT TOP 10 * FROM [{databaseOwner}].[{objectQualifier}Mail] WHERE ProcessID = @ProcessID ORDER BY SendAttempt desc, Created
END
GO

create procedure [{databaseOwner}].[{objectQualifier}message_approve](@MessageID int) as begin
	
	declare	@UserID		int
	declare	@ForumID	int
	declare	@TopicID	int
	declare	@Flags	    int
	declare @Posted		datetime
	declare	@UserName	nvarchar(255)

	select 
		@UserID = a.UserID,
		@TopicID = a.TopicID,
		@ForumID = b.ForumID,
		@Posted = a.Posted,
		@UserName = a.UserName,
		@Flags	= a.Flags
	from
		[{databaseOwner}].[{objectQualifier}Message] a
		inner join [{databaseOwner}].[{objectQualifier}Topic] b on b.TopicID=a.TopicID
	where
		a.MessageID = @MessageID

	-- update Message table, set meesage flag to approved
	update [{databaseOwner}].[{objectQualifier}Message] set Flags = Flags | 16 where MessageID = @MessageID

	-- update User table to increase postcount
	if exists(select 1 from [{databaseOwner}].[{objectQualifier}Forum] where ForumID=@ForumID and (Flags & 4)=0)
	begin
		update [{databaseOwner}].[{objectQualifier}User] set NumPosts = NumPosts + 1 where UserID = @UserID
		-- upgrade user, i.e. promote rank if conditions allow it
		exec [{databaseOwner}].[{objectQualifier}user_upgrade] @UserID
	end

	-- update Forum table with last topic/post info
	update [{databaseOwner}].[{objectQualifier}Forum] set
		LastPosted = @Posted,
		LastTopicID = @TopicID,
		LastMessageID = @MessageID,
		LastUserID = @UserID,
		LastUserName = @UserName
	where ForumID = @ForumID

	-- update Topic table with info about last post in topic
	update [{databaseOwner}].[{objectQualifier}Topic] set
		LastPosted = @Posted,
		LastMessageID = @MessageID,
		LastUserID = @UserID,
		LastUserName = @UserName,		
		LastMessageFlags = @Flags | 16,
		NumPosts = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and x.IsApproved = 1 and x.IsDeleted = 0)
	where TopicID = @TopicID
	
	-- update forum stats
	exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @ForumID	
end
GO

create procedure [{databaseOwner}].[{objectQualifier}message_delete](@MessageID int, @EraseMessage bit = 0) as
begin
	
	declare @TopicID		int
	declare @ForumID		int
	declare @MessageCount	int
	declare @LastMessageID	int
	declare @UserID			int

	-- Find TopicID and ForumID
	select @TopicID=b.TopicID,@ForumID=b.ForumID,@UserID = a.UserID 
		from 
			[{databaseOwner}].[{objectQualifier}Message] a
			inner join [{databaseOwner}].[{objectQualifier}Topic] b on b.TopicID=a.TopicID
		where
			a.MessageID=@MessageID
   

	-- Update LastMessageID in Topic
	update [{databaseOwner}].[{objectQualifier}Topic] set 
		LastPosted = null,
		LastMessageID = null,
		LastUserID = null,
		LastUserName = null,
		LastMessageFlags = null
	where LastMessageID = @MessageID

	-- Update LastMessageID in Forum
	update [{databaseOwner}].[{objectQualifier}Forum] set 
		LastPosted = null,
		LastTopicID = null,
		LastMessageID = null,
		LastUserID = null,
		LastUserName = null
	where LastMessageID = @MessageID

	-- should it be physically deleter or not?
	if (@EraseMessage = 1) begin
		delete [{databaseOwner}].[{objectQualifier}Attachment] where MessageID = @MessageID
		delete [{databaseOwner}].[{objectQualifier}MessageReported] where MessageID = @MessageID
		delete [{databaseOwner}].[{objectQualifier}MessageReportedAudit] where MessageID = @MessageID
		--delete thanks related to this message
		delete [{databaseOwner}].[{objectQualifier}Thanks] where MessageID = @MessageID
		delete [{databaseOwner}].[{objectQualifier}MessageHistory] where MessageID = @MessageID
		delete [{databaseOwner}].[{objectQualifier}Message] where MessageID = @MessageID
		
	end
	else begin
		-- "Delete" it only by setting deleted flag message
		update [{databaseOwner}].[{objectQualifier}Message] set Flags = Flags | 8 where MessageID = @MessageID
	end
	
	-- update user post count
	UPDATE [{databaseOwner}].[{objectQualifier}User] SET NumPosts = (SELECT count(MessageID) FROM [{databaseOwner}].[{objectQualifier}Message] WHERE UserID = @UserID AND IsDeleted = 0 AND IsApproved = 1) WHERE UserID = @UserID
	
	-- Delete topic if there are no more messages
	select @MessageCount = count(1) from [{databaseOwner}].[{objectQualifier}Message] where TopicID = @TopicID and (Flags & 8)=0
	if @MessageCount=0 exec [{databaseOwner}].[{objectQualifier}topic_delete] @TopicID, 1, @EraseMessage

	-- update lastpost
	exec [{databaseOwner}].[{objectQualifier}topic_updatelastpost] @ForumID,@TopicID
	exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @ForumID

	-- update topic numposts
	update [{databaseOwner}].[{objectQualifier}Topic] set
		NumPosts = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and x.IsApproved = 1 and x.IsDeleted = 0)
	where TopicID = @TopicID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}message_findunread](@TopicID int,@LastRead datetime) as
begin
		select top 1 MessageID from [{databaseOwner}].[{objectQualifier}Message]
	where TopicID=@TopicID and Posted>@LastRead
	order by Posted
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_getReplies](@MessageID int) as
BEGIN
	SELECT MessageID FROM [{databaseOwner}].[{objectQualifier}Message] WHERE ReplyTo = @MessageID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_list](@MessageID int) AS
BEGIN
		SELECT
		a.MessageID,
		a.UserID,
		UserName = b.Name,
		a.[Message],
		c.TopicID,
		c.ForumID,
		c.Topic,
		c.Priority,
		a.Flags,
		c.UserID AS TopicOwnerID,
		Edited = IsNull(a.Edited,a.Posted),
		TopicFlags = c.Flags,
		ForumFlags = d.Flags,
		a.EditReason,
		a.Position,
		a.IsModeratorChanged,
		a.DeleteReason,
		a.BlogPostID,
		c.PollID,
		a.IP
	FROM
		[{databaseOwner}].[{objectQualifier}Message] a
		inner join [{databaseOwner}].[{objectQualifier}User] b on b.UserID = a.UserID
		inner join [{databaseOwner}].[{objectQualifier}Topic] c on c.TopicID = a.TopicID
		inner join [{databaseOwner}].[{objectQualifier}Forum] d on c.ForumID = d.ForumID
	WHERE
		a.MessageID = @MessageID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_secdata]( @UserID int, @MessageID int ) AS
BEGIN
-- BoardID=@BoardID and
if (@UserID is null)
select top 1 @UserID = UserID from [{databaseOwner}].[{objectQualifier}User] where  (Flags & 4)<>0 ORDER BY Joined DESC
SELECT
		m.MessageID,
		m.UserID,
		IsNull(t.UserName, u.Name) as Name,
		m.[Message],
		m.Posted,
		t.TopicID,
		t.ForumID,
		t.Topic,
		t.Priority,
		m.Flags,
		t.UserID,
		Edited = IsNull(m.Edited,m.Posted),
		EditedBy = IsNull(m.EditedBy,m.UserID), 
		TopicFlags = t.Flags,		
		m.EditReason,
		m.Position,
		m.IsModeratorChanged,
		m.DeleteReason,
		m.BlogPostID,
		t.PollID,
		m.IP
	FROM		
		[{databaseOwner}].[{objectQualifier}Topic] t 
		join  [{databaseOwner}].[{objectQualifier}Message] m ON m.TopicID = t.TopicID
		join  [{databaseOwner}].[{objectQualifier}User] u ON u.UserID = t.UserID
		left join [{databaseOwner}].[{objectQualifier}vaccess] x on x.ForumID=IsNull(t.ForumID,0)
	WHERE
		m.MessageID = @MessageID AND x.UserID=@UserID  AND x.ReadAccess > 0
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_listreported](@ForumID int) AS
BEGIN
		SELECT
		a.*,
		OriginalMessage = b.[Message],
		b.[Flags],
		b.[IsModeratorChanged],	
		UserName	= IsNull(b.UserName,d.Name),
		UserID = b.UserID,
		Posted		= b.Posted,
		TopicID = b.TopicID,
		Topic		= c.Topic,		
		NumberOfReports = (SELECT count(LogID) FROM [{databaseOwner}].[{objectQualifier}MessageReportedAudit] WHERE [{databaseOwner}].[{objectQualifier}MessageReportedAudit].MessageID = a.MessageID)
	FROM
		[{databaseOwner}].[{objectQualifier}MessageReported] a
	INNER JOIN
		[{databaseOwner}].[{objectQualifier}Message] b ON a.MessageID = b.MessageID
	INNER JOIN
		[{databaseOwner}].[{objectQualifier}Topic] c ON b.TopicID = c.TopicID
	INNER JOIN
		[{databaseOwner}].[{objectQualifier}User] d ON b.UserID = d.UserID
	WHERE
		c.ForumID = @ForumID and
		(c.Flags & 16)=0 and
		(b.Flags & 8)=0 and
		(c.Flags & 8)=0 and
		(b.Flags & 128)=128
	ORDER BY
		b.TopicID DESC, b.Posted DESC
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_listreporters](@MessageID int, @UserID int = null) AS
BEGIN
	IF ( @UserID > 0 )
	BEGIN
	SELECT b.UserID, UserName = a.Name, b.ReportedNumber, b.ReportText  
	FROM [{databaseOwner}].[{objectQualifier}User] a,			
	[{databaseOwner}].[{objectQualifier}MessageReportedAudit] b		
	WHERE   a.UserID = b.UserID  AND b.MessageID = @MessageID AND b.UserID = @UserID 
	END
	ELSE
	BEGIN
	SELECT b.UserID, UserName = a.Name, b.ReportedNumber, b.ReportText  
	FROM [{databaseOwner}].[{objectQualifier}User] a,			
	[{databaseOwner}].[{objectQualifier}MessageReportedAudit] b		
	WHERE   a.UserID = b.UserID  AND b.MessageID = @MessageID
	END
	
	
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_report](@MessageID int, @ReporterID int, @ReportedDate datetime, @ReportText nvarchar(4000)) AS
BEGIN
	IF @ReportText IS NULL SET @ReportText = '';		
	IF NOT exists(SELECT MessageID from [{databaseOwner}].[{objectQualifier}MessageReportedAudit] WHERE MessageID=@MessageID AND UserID=@ReporterID)
		INSERT INTO [{databaseOwner}].[{objectQualifier}MessageReportedAudit](MessageID,UserID,Reported,ReportText) VALUES (@MessageID,@ReporterID,@ReportedDate, CONVERT(varchar,GETUTCDATE() )+ '??' + @ReportText)
	ELSE 
	UPDATE [{databaseOwner}].[{objectQualifier}MessageReportedAudit] SET ReportedNumber = ( CASE WHEN ReportedNumber < 2147483647 THEN  ReportedNumber  + 1 ELSE ReportedNumber END ), Reported = @ReportedDate, ReportText = (CASE WHEN (LEN(ReportText) + LEN(@ReportText) + 255 < 4000)  THEN  ReportText + '|' + CONVERT(varchar(36),GETUTCDATE() )+ '??' +  @ReportText ELSE ReportText END) WHERE MessageID=@MessageID AND UserID=@ReporterID 
	IF NOT exists(SELECT MessageID FROM [{databaseOwner}].[{objectQualifier}MessageReported] WHERE MessageID=@MessageID)
	BEGIN
		INSERT INTO [{databaseOwner}].[{objectQualifier}MessageReported](MessageID, [Message])
		SELECT 
			a.MessageID,
			a.[Message]
		FROM
			[{databaseOwner}].[{objectQualifier}Message] a
		WHERE
			a.MessageID = @MessageID
	END

	-- update Message table to set message with flag Reported
	UPDATE [{databaseOwner}].[{objectQualifier}Message] SET Flags = Flags | 128 WHERE MessageID = @MessageID

END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_reportresolve](@MessageFlag int, @MessageID int, @UserID int) AS
BEGIN
	
	UPDATE [{databaseOwner}].[{objectQualifier}MessageReported]
	SET Resolved = 1, ResolvedBy = @UserID, ResolvedDate = GETUTCDATE() 
	WHERE MessageID = @MessageID;
	
	/* Remove Flag */
	UPDATE [{databaseOwner}].[{objectQualifier}Message]
	SET Flags = Flags & (~POWER(2, @MessageFlag))
	WHERE MessageID = @MessageID;
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_reportcopyover](@MessageID int) AS
BEGIN
		UPDATE [{databaseOwner}].[{objectQualifier}MessageReported]
	SET [{databaseOwner}].[{objectQualifier}MessageReported].[Message] = m.[Message]
	FROM [{databaseOwner}].[{objectQualifier}MessageReported] mr
	JOIN [{databaseOwner}].[{objectQualifier}Message] m ON m.MessageID = mr.MessageID
	WHERE mr.MessageID = @MessageID;
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_save](
	@TopicID		int,
	@UserID			int,
	@Message		ntext,	
	@UserName		nvarchar(255)=null,
	@IP				varchar(39),
	@Posted			datetime=null,
	@ReplyTo		int,
	@BlogPostID		nvarchar(50) = null,
	@Flags			int,	
	@MessageID		int output
)
AS
BEGIN
		DECLARE @ForumID INT, @ForumFlags INT, @Position INT, @Indent INT

	IF @Posted IS NULL
		SET @Posted = GETUTCDATE() 

	SELECT @ForumID = x.ForumID, @ForumFlags = y.Flags
	FROM 
		[{databaseOwner}].[{objectQualifier}Topic] x
	INNER JOIN 
		[{databaseOwner}].[{objectQualifier}Forum] y ON y.ForumID=x.ForumID
	WHERE x.TopicID = @TopicID 

	IF @ReplyTo IS NULL
			SELECT @Position = 0, @Indent = 0 -- New thread

	ELSE IF @ReplyTo<0
		-- Find post to reply to AND indent of this post
		SELECT TOP 1 @ReplyTo = MessageID, @Indent = Indent+1
		FROM [{databaseOwner}].[{objectQualifier}Message]
		WHERE TopicID = @TopicID AND ReplyTo IS NULL
		ORDER BY Posted

	ELSE
		-- Got reply, find indent of this post
			SELECT @Indent=Indent+1
			FROM [{databaseOwner}].[{objectQualifier}Message]
			WHERE MessageID=@ReplyTo

	-- Find position
	IF @ReplyTo IS NOT NULL
	BEGIN
		DECLARE @temp INT
		
		SELECT @temp=ReplyTo,@Position=Position FROM [{databaseOwner}].[{objectQualifier}Message] WHERE MessageID=@ReplyTo

		IF @temp IS NULL
			-- We are replying to first post
			SELECT @Position=MAX(Position)+1 FROM [{databaseOwner}].[{objectQualifier}Message] WHERE TopicID=@TopicID

		ELSE
			-- Last position of replies to parent post
			SELECT @Position=MIN(Position) FROM [{databaseOwner}].[{objectQualifier}Message] WHERE ReplyTo=@temp AND Position>@Position

		-- No replies, THEN USE parent post's position+1
		IF @Position IS NULL
			SELECT @Position=Position+1 FROM [{databaseOwner}].[{objectQualifier}Message] WHERE MessageID=@ReplyTo
		-- Increase position of posts after this

		UPDATE [{databaseOwner}].[{objectQualifier}Message] SET Position=Position+1 WHERE TopicID=@TopicID AND Position>=@Position
	END

	-- Add points to Users total points
	UPDATE [{databaseOwner}].[{objectQualifier}User] SET Points = Points + 3 WHERE UserID = @UserID

	INSERT [{databaseOwner}].[{objectQualifier}Message] ( UserID, [Message], TopicID, Posted, UserName, IP, ReplyTo, Position, Indent, Flags, BlogPostID)
	VALUES ( @UserID, @Message, @TopicID, @Posted, @UserName, @IP, @ReplyTo, @Position, @Indent, @Flags & ~16, @BlogPostID)	
	
	SET @MessageID = SCOPE_IDENTITY()

	IF ((@ForumFlags & 8) = 0) OR ((@Flags & 16) = 16)
		EXEC [{databaseOwner}].[{objectQualifier}message_approve] @MessageID	
END
	
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}message_unapproved](@ForumID int) as begin
		select
		MessageID	= b.MessageID,
		UserID		= b.UserID,
		UserName	= IsNull(b.UserName,c.Name),		
		Posted		= b.Posted,
		TopicID		= a.TopicID,
		Topic		= a.Topic,
		[Message]	= b.[Message],
		[Flags]		= b.Flags,
		[IsModeratorChanged] = b.IsModeratorChanged
	from
		[{databaseOwner}].[{objectQualifier}Topic] a
		inner join [{databaseOwner}].[{objectQualifier}Message] b on b.TopicID = a.TopicID
		inner join [{databaseOwner}].[{objectQualifier}User] c on c.UserID = b.UserID
	where
		a.ForumID = @ForumID and
		(b.Flags & 16)=0 and
		(a.Flags & 8)=0 and
		(b.Flags & 8)=0
	order by
		a.Posted
end

GO

CREATE procedure [{databaseOwner}].[{objectQualifier}message_update](
@MessageID int,
@Priority int,
@Subject nvarchar(100),
@Flags int, 
@Message ntext, 
@Reason nvarchar(100), 
@EditedBy int,
@IsModeratorChanged bit, 
@OverrideApproval bit = null,
@OriginalMessage ntext) as
begin
		declare @TopicID	int
	declare	@ForumFlags	int

	set @Flags = @Flags & ~16	
	
	select 
		@TopicID	= a.TopicID,
		@ForumFlags	= c.Flags
	from 
		[{databaseOwner}].[{objectQualifier}Message] a
		inner join [{databaseOwner}].[{objectQualifier}Topic] b on b.TopicID = a.TopicID
		inner join [{databaseOwner}].[{objectQualifier}Forum] c on c.ForumID = b.ForumID
	where 
		a.MessageID = @MessageID

	if (@OverrideApproval = 1 OR (@ForumFlags & 8)=0) set @Flags = @Flags | 16
	
	
	-- insert current message variant - use OriginalMessage in future 	
	insert into [{databaseOwner}].[{objectQualifier}MessageHistory]
	(MessageID,		
		[Message],
		IP,
		Edited,
		EditedBy,		
		EditReason,
		IsModeratorChanged,
		Flags)
	select 
	MessageID, OriginalMessage=@OriginalMessage, IP , IsNull(Edited,Posted), IsNull(EditedBy,UserID), EditReason, IsModeratorChanged, Flags
	from [{databaseOwner}].[{objectQualifier}Message] where
		MessageID = @MessageID
	
	update [{databaseOwner}].[{objectQualifier}Message] set
		[Message] = @Message,
		Edited = GETUTCDATE() ,
		EditedBy = @EditedBy,
		Flags = @Flags,
		IsModeratorChanged  = @IsModeratorChanged,
				EditReason = @Reason
	where
		MessageID = @MessageID

	if @Priority is not null begin
		update [{databaseOwner}].[{objectQualifier}Topic] set
			Priority = @Priority
		where
			TopicID = @TopicID
	end

	if not @Subject = '' and @Subject is not null begin
		update [{databaseOwner}].[{objectQualifier}Topic] set
			Topic = @Subject
		where
			TopicID = @TopicID
	end 
	
	-- If forum is moderated, make sure last post pointers are correct
	if (@ForumFlags & 8)<>0 exec [{databaseOwner}].[{objectQualifier}topic_updatelastpost]
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntpforum_delete](@NntpForumID int) as
begin
		delete from [{databaseOwner}].[{objectQualifier}NntpTopic] where NntpForumID = @NntpForumID
	delete from [{databaseOwner}].[{objectQualifier}NntpForum] where NntpForumID = @NntpForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntpforum_list](@BoardID int,@Minutes int=null,@NntpForumID int=null,@Active bit=null) as
begin
		select
		a.Name,
		a.[Address],
		Port = IsNull(a.Port,119),
		a.UserName,
		a.UserPass,		
		a.NntpServerID,
		b.NntpForumID,		
		b.GroupName,
		b.ForumID,
		b.LastMessageNo,
		b.LastUpdate,
		b.Active,
		ForumName = c.Name
	from
		[{databaseOwner}].[{objectQualifier}NntpServer] a
		join [{databaseOwner}].[{objectQualifier}NntpForum] b on b.NntpServerID = a.NntpServerID
		join [{databaseOwner}].[{objectQualifier}Forum] c on c.ForumID = b.ForumID
	where
		(@Minutes is null or datediff(n,b.LastUpdate,GETUTCDATE() )>@Minutes) and
		(@NntpForumID is null or b.NntpForumID=@NntpForumID) and
		a.BoardID=@BoardID and
		(@Active is null or b.Active=@Active)
	order by
		a.Name,
		b.GroupName
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntpforum_save](@NntpForumID int=null,@NntpServerID int,@GroupName nvarchar(100),@ForumID int,@Active bit) as
begin
		if @NntpForumID is null
		insert into [{databaseOwner}].[{objectQualifier}NntpForum](NntpServerID,GroupName,ForumID,LastMessageNo,LastUpdate,Active)
		values(@NntpServerID,@GroupName,@ForumID,0,GETUTCDATE() ,@Active)
	else
		update [{databaseOwner}].[{objectQualifier}NntpForum] set
			NntpServerID = @NntpServerID,
			GroupName = @GroupName,
			ForumID = @ForumID,
			Active = @Active
		where NntpForumID = @NntpForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntpforum_update](@NntpForumID int,@LastMessageNo int,@UserID int) as
begin
		declare	@ForumID	int
	
	select @ForumID=ForumID from [{databaseOwner}].[{objectQualifier}NntpForum] where NntpForumID=@NntpForumID

	update [{databaseOwner}].[{objectQualifier}NntpForum] set
		LastMessageNo = @LastMessageNo,
		LastUpdate = GETUTCDATE() 
	where NntpForumID = @NntpForumID

	update [{databaseOwner}].[{objectQualifier}Topic] set 
		NumPosts = (select count(1) from [{databaseOwner}].[{objectQualifier}message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and x.IsApproved = 1 and x.IsDeleted = 0)
	where ForumID=@ForumID

	--exec [{databaseOwner}].[{objectQualifier}user_upgrade] @UserID
	exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @ForumID
	-- exec [{databaseOwner}].[{objectQualifier}topic_updatelastpost] @ForumID,null
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntpserver_delete](@NntpServerID int) as
begin
		delete from [{databaseOwner}].[{objectQualifier}NntpTopic] where NntpForumID in (select NntpForumID from [{databaseOwner}].[{objectQualifier}NntpForum] where NntpServerID = @NntpServerID)
	delete from [{databaseOwner}].[{objectQualifier}NntpForum] where NntpServerID = @NntpServerID
	delete from [{databaseOwner}].[{objectQualifier}NntpServer] where NntpServerID = @NntpServerID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntpserver_list](@BoardID int=null,@NntpServerID int=null) as
begin
		if @NntpServerID is null
		select * from [{databaseOwner}].[{objectQualifier}NntpServer] where BoardID=@BoardID order by Name
	else
		select * from [{databaseOwner}].[{objectQualifier}NntpServer] where NntpServerID=@NntpServerID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntpserver_save](
	@NntpServerID 	int=null,
	@BoardID	int,
	@Name		nvarchar(50),
	@Address	nvarchar(100),
	@Port		int,
	@UserName	nvarchar(255)=null,
	@UserPass	nvarchar(50)=null
) as begin
		if @NntpServerID is null
		insert into [{databaseOwner}].[{objectQualifier}NntpServer](Name,BoardID,Address,Port,UserName,UserPass)
		values(@Name,@BoardID,@Address,@Port,@UserName,@UserPass)
	else
		update [{databaseOwner}].[{objectQualifier}NntpServer] set
			Name = @Name,
			[Address] = @Address,
			Port = @Port,
			UserName = @UserName,
			UserPass = @UserPass
		where NntpServerID = @NntpServerID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntptopic_list](@Thread char(32)) as
begin
		select
		a.*
	from
		[{databaseOwner}].[{objectQualifier}NntpTopic] a
	where
		a.Thread = @Thread
end
GO

create procedure [{databaseOwner}].[{objectQualifier}nntptopic_savemessage](
	@NntpForumID	int,
	@Topic 			nvarchar(100),
	@Body 			ntext,
	@UserID 		int,
	@UserName		nvarchar(255),
	@IP				varchar(39),
	@Posted			datetime,
	@Thread			char(32)
) as 
begin
	declare	@ForumID	int
	declare @TopicID	int
	declare	@MessageID	int

	select @ForumID=ForumID from [{databaseOwner}].[{objectQualifier}NntpForum] where NntpForumID=@NntpForumID

	if exists(select 1 from [{databaseOwner}].[{objectQualifier}NntpTopic] where Thread=@Thread)
	begin
		-- thread exists
		select @TopicID=TopicID from [{databaseOwner}].[{objectQualifier}NntpTopic] where Thread=@Thread
	end else
	begin
		-- thread doesn't exists
		insert into [{databaseOwner}].[{objectQualifier}Topic](ForumID,UserID,UserName,Posted,Topic,Views,Priority,NumPosts)
		values(@ForumID,@UserID,@UserName,@Posted,@Topic,0,0,0)
		set @TopicID=SCOPE_IDENTITY()

		insert into [{databaseOwner}].[{objectQualifier}NntpTopic](NntpForumID,Thread,TopicID)
		values(@NntpForumID,@Thread,@TopicID)
	end

	-- save message
	insert into [{databaseOwner}].[{objectQualifier}Message](TopicID,UserID,UserName,Posted,Message,IP,Position,Indent)
	values(@TopicID,@UserID,@UserName,@Posted,@Body,@IP,0,0)
	set @MessageID=SCOPE_IDENTITY()

	-- update user
	if exists(select 1 from [{databaseOwner}].[{objectQualifier}Forum] where ForumID=@ForumID and (Flags & 4)=0)
	begin
		update [{databaseOwner}].[{objectQualifier}User] set NumPosts=NumPosts+1 where UserID=@UserID
	end
	
	-- update topic
	update [{databaseOwner}].[{objectQualifier}Topic] set 
		LastPosted		= @Posted,
		LastMessageID	= @MessageID,
		LastUserID		= @UserID,
		LastUserName	= @UserName
	where TopicID=@TopicID	
	-- update forum
	update [{databaseOwner}].[{objectQualifier}Forum] set
		LastPosted		= @Posted,
		LastTopicID	= @TopicID,
		LastMessageID	= @MessageID,
		LastUserID		= @UserID,
		LastUserName	= @UserName
	where ForumID=@ForumID and (LastPosted is null or LastPosted<@Posted)
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}pageload](
	@SessionID	nvarchar(24),
	@BoardID	int,
	@UserKey	nvarchar(64),
	@IP			varchar(39),
	@Location	nvarchar(255),
	@ForumPage nvarchar(255) = null,
	@Browser	nvarchar(50),
	@Platform	nvarchar(50),
	@CategoryID	int = null,
	@ForumID	int = null,
	@TopicID	int = null,
	@MessageID	int = null,
	@IsCrawler	bit = 0,
	@DontTrack	bit = 0
) as
begin
	declare @UserID			int
	declare @UserBoardID	int
	declare @IsGuest		tinyint	
	declare @rowcount		int
	declare @PreviousVisit	datetime
	declare @ActiveUpdate   tinyint
	declare @CurrentTime	datetime
	declare @ActiveFlags	int
	
	set implicit_transactions off
	set @CurrentTime = GETUTCDATE()
	-- set IsActiveNow ActiveFlag - it's a default
	set @ActiveFlags = 1;
	if @UserKey is null
	begin
		select @UserID = UserID from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID and (Flags & 4)<>0 ORDER BY Joined DESC
		set @rowcount=@@rowcount
		if (@rowcount = 0)
		begin
			raiserror('Found %d possible guest users. There should be one and only one user marked as guest.',16,1,@rowcount)
		end
		set @IsGuest = 1
		-- set IsGuest ActiveFlag  1 | 2
		set @ActiveFlags = 3
		set @UserBoardID = @BoardID
		-- crawlers are always guests 
		if	@IsCrawler = 1
			begin
				-- set IsCrawler ActiveFlag
				set @ActiveFlags =  @ActiveFlags | 8
			end 
	end else	
	begin
		select @UserID = UserID, @UserBoardID = BoardID from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID and ProviderUserKey=@UserKey
		set @IsGuest = 0
		-- make sure that registered users are not crawlers
		set @IsCrawler = 0
		-- set IsRegistered ActiveFlag
		set @ActiveFlags = @ActiveFlags | 4
	end

	
	-- Check valid ForumID
	if @ForumID is not null and not exists(select 1 from [{databaseOwner}].[{objectQualifier}Forum] where ForumID=@ForumID) begin
		set @ForumID = null
	end
	-- Check valid CategoryID
	if @CategoryID is not null and not exists(select 1 from [{databaseOwner}].[{objectQualifier}Category] where CategoryID=@CategoryID) begin
		set @CategoryID = null
	end
	-- Check valid MessageID
	if @MessageID is not null and not exists(select 1 from [{databaseOwner}].[{objectQualifier}Message] where MessageID=@MessageID) begin
		set @MessageID = null
	end
	-- Check valid TopicID
	if @TopicID is not null and not exists(select 1 from [{databaseOwner}].[{objectQualifier}Topic] where TopicID=@TopicID) begin
		set @TopicID = null
	end
	
	-- get previous visit
	if @IsGuest=0 begin
		select @PreviousVisit = LastVisit from [{databaseOwner}].[{objectQualifier}User] where UserID = @UserID
	end
	
	-- update last visit
	update [{databaseOwner}].[{objectQualifier}User] set 
		LastVisit = @CurrentTime,
		IP = @IP
	where UserID = @UserID

	-- find missing ForumID/TopicID
	if @MessageID is not null begin
		select
			@CategoryID = c.CategoryID,
			@ForumID = b.ForumID,
			@TopicID = b.TopicID
		from
			[{databaseOwner}].[{objectQualifier}Message] a
			inner join [{databaseOwner}].[{objectQualifier}Topic] b on b.TopicID = a.TopicID
			inner join [{databaseOwner}].[{objectQualifier}Forum] c on c.ForumID = b.ForumID
			inner join [{databaseOwner}].[{objectQualifier}Category] d on d.CategoryID = c.CategoryID
		where
			a.MessageID = @MessageID and
			d.BoardID = @BoardID
	end
	else if @TopicID is not null begin
		select 
			@CategoryID = b.CategoryID,
			@ForumID = a.ForumID 
		from 
			[{databaseOwner}].[{objectQualifier}Topic] a
			inner join [{databaseOwner}].[{objectQualifier}Forum] b on b.ForumID = a.ForumID
			inner join [{databaseOwner}].[{objectQualifier}Category] c on c.CategoryID = b.CategoryID
		where 
			a.TopicID = @TopicID and
			c.BoardID = @BoardID
	end
	else if @ForumID is not null begin
		select
			@CategoryID = a.CategoryID
		from
			[{databaseOwner}].[{objectQualifier}Forum] a
			inner join [{databaseOwner}].[{objectQualifier}Category] b on b.CategoryID = a.CategoryID
		where
			a.ForumID = @ForumID and
			b.BoardID = @BoardID
	end
	-- update active
	if @DontTrack != 1 and @UserID is not null and @UserBoardID=@BoardID begin
	  if exists(select 1 from [{databaseOwner}].[{objectQualifier}Active] where (SessionID=@SessionID OR ( Browser = @Browser AND (Flags & 8) = 8 )) and BoardID=@BoardID)
		begin
		  -- user is not a crawler - use his session id
		  if @IsCrawler <> 1
		  begin		   
			update [{databaseOwner}].[{objectQualifier}Active] set
				UserID = @UserID,
				IP = @IP,
				LastActive = @CurrentTime ,
				Location = @Location,
				ForumID = @ForumID,
				TopicID = @TopicID,
				Browser = @Browser,
				[Platform] = @Platform,
				ForumPage = @ForumPage		
			where SessionID = @SessionID			
			end
			else
			begin
			-- search crawler by other parameters then session id
			update [{databaseOwner}].[{objectQualifier}Active] set
				UserID = @UserID,
				IP = @IP,
				LastActive = @CurrentTime ,
				Location = @Location,
				ForumID = @ForumID,
				TopicID = @TopicID,
				Browser = @Browser,
				[Platform] = @Platform,
				ForumPage = @ForumPage	
			where Browser = @Browser AND IP = @IP
			-- trace crawler: the cache is reset every time crawler moves to next page ? Disabled as cache reset will overload server 
			-- set @ActiveUpdate = 1			
			end
		end
		else begin	
		   -- we set @ActiveFlags ready flags 	
			insert into [{databaseOwner}].[{objectQualifier}Active](SessionID,BoardID,UserID,IP,Login,LastActive,Location,ForumID,TopicID,Browser,[Platform],Flags)
			values(@SessionID,@BoardID,@UserID,@IP,@CurrentTime,@CurrentTime,@Location,@ForumID,@TopicID,@Browser,@Platform,@ActiveFlags)			

			-- update max user stats
			exec [{databaseOwner}].[{objectQualifier}active_updatemaxstats] @BoardID
			-- parameter to update active users cache if this is a new user
			if @IsGuest=0
				  begin
				  set @ActiveUpdate = 1
				  end
		end
		-- remove duplicate users
		if @IsGuest=0
		begin
			delete from [{databaseOwner}].[{objectQualifier}Active] where UserID=@UserID and BoardID=@BoardID and SessionID<>@SessionID		    
		end
		
	end
	-- return information
	select
		ActiveUpdate        = ISNULL(@ActiveUpdate,0),
		PreviousVisit		= @PreviousVisit,	   
		x.*,
		IsCrawler           = @IsCrawler,
		CategoryID			= @CategoryID,
		CategoryName		= (select Name from [{databaseOwner}].[{objectQualifier}Category] where CategoryID = @CategoryID),
		ForumName			= (select Name from [{databaseOwner}].[{objectQualifier}Forum] where ForumID = @ForumID),
		TopicID				= @TopicID,
		TopicName			= (select Topic from [{databaseOwner}].[{objectQualifier}Topic] where TopicID = @TopicID),
		ForumTheme			= (select ThemeURL from [{databaseOwner}].[{objectQualifier}Forum] where ForumID = @ForumID)	 
	from
	 [{databaseOwner}].[{objectQualifier}vaccess] x 
	where
		x.UserID = @UserID and x.ForumID=IsNull(@ForumID,0)
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_delete](@UserPMessageID int, @FromOutbox bit = 0) as
BEGIN
		DECLARE @PMessageID int

	SET @PMessageID = (SELECT TOP 1 PMessageID FROM [{databaseOwner}].[{objectQualifier}UserPMessage] where UserPMessageID = @UserPMessageID);
		
	IF ( @FromOutbox = 1 AND EXISTS(SELECT (1) FROM [{databaseOwner}].[{objectQualifier}UserPMessage] WHERE UserPMessageID = @UserPMessageID AND IsInOutbox = 1 ) )
	BEGIN
		-- set IsInOutbox bit which will remove it from the senders outbox
		UPDATE [{databaseOwner}].[{objectQualifier}UserPMessage] SET [Flags] = ([Flags] ^ 2) WHERE UserPMessageID = @UserPMessageID
	END
	
	IF ( @FromOutbox = 0 )
	BEGIN
			-- The pmessage is in archive but still is in sender outbox  
	IF ( EXISTS(SELECT (1) FROM [{databaseOwner}].[{objectQualifier}UserPMessage] WHERE UserPMessageID = @UserPMessageID AND IsInOutbox = 1 AND IsArchived = 1 AND IsDeleted = 0) )
	BEGIN
	-- Remove archive flag and set IsDeleted flag
	UPDATE [{databaseOwner}].[{objectQualifier}UserPMessage] SET [Flags] = [Flags] ^ 4  WHERE UserPMessageID = @UserPMessageID AND IsArchived = 1	
	END
		-- set is deleted...
		UPDATE [{databaseOwner}].[{objectQualifier}UserPMessage] SET [Flags] = ([Flags] ^ 8) WHERE UserPMessageID = @UserPMessageID
	END	
	
	-- see if there are no longer references to this PM.
	IF ( EXISTS(SELECT (1) FROM [{databaseOwner}].[{objectQualifier}UserPMessage] WHERE UserPMessageID = @UserPMessageID AND IsInOutbox = 0 AND IsDeleted = 1 ) )
	BEGIN
		-- delete
		DELETE FROM [{databaseOwner}].[{objectQualifier}UserPMessage] WHERE [PMessageID] = @PMessageID
		DELETE FROM [{databaseOwner}].[{objectQualifier}PMessage] WHERE [PMessageID] = @PMessageID
	END	

END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_info] as
begin
		select
		NumRead	= (select count(1) from [{databaseOwner}].[{objectQualifier}UserPMessage] WHERE IsRead<>0  AND IsDeleted<>1),
		NumUnread = (select count(1) from [{databaseOwner}].[{objectQualifier}UserPMessage] WHERE IsRead=0  AND IsDeleted<>1),
		NumTotal = (select count(1) from [{databaseOwner}].[{objectQualifier}UserPMessage] WHERE IsDeleted<>1)
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_list](@FromUserID int=null,@ToUserID int=null,@UserPMessageID int=null) AS
BEGIN				
		SELECT PMessageID, UserPMessageID, FromUserID, FromUser, ToUserID, ToUser, Created, Subject, Body,  Flags, IsRead, IsInOutbox, IsArchived, IsDeleted
		FROM [{databaseOwner}].[{objectQualifier}PMessageView]
		WHERE	((@UserPMessageID IS NOT NULL AND UserPMessageID=@UserPMessageID) OR 
				 (@ToUserID   IS NOT NULL AND ToUserID = @ToUserID) OR (@FromUserID IS NOT NULL AND FromUserID = @FromUserID))		
		ORDER BY Created DESC
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_markread](@UserPMessageID int=null)
AS
BEGIN
		UPDATE [{databaseOwner}].[{objectQualifier}UserPMessage] SET [Flags] = [Flags] | 1 WHERE UserPMessageID = @UserPMessageID AND IsRead = 0
END
GO

create procedure [{databaseOwner}].[{objectQualifier}pmessage_prune](@DaysRead int,@DaysUnread int) as
begin
		delete from [{databaseOwner}].[{objectQualifier}UserPMessage]
	where IsRead<>0
	and datediff(dd,(select Created from [{databaseOwner}].[{objectQualifier}PMessage] x where x.PMessageID=[{databaseOwner}].[{objectQualifier}UserPMessage].PMessageID),GETUTCDATE() )>@DaysRead

	delete from [{databaseOwner}].[{objectQualifier}UserPMessage]
	where IsRead=0
	and datediff(dd,(select Created from [{databaseOwner}].[{objectQualifier}PMessage] x where x.PMessageID=[{databaseOwner}].[{objectQualifier}UserPMessage].PMessageID),GETUTCDATE() )>@DaysUnread

	delete from [{databaseOwner}].[{objectQualifier}PMessage]
	where not exists(select 1 from [{databaseOwner}].[{objectQualifier}UserPMessage] x where x.PMessageID=[{databaseOwner}].[{objectQualifier}PMessage].PMessageID)
end
GO

create procedure [{databaseOwner}].[{objectQualifier}pmessage_save](
	@FromUserID	int,
	@ToUserID	int,
	@Subject	nvarchar(100),
	@Body		ntext,
	@Flags		int
) as
begin
	declare @PMessageID int
	declare @UserID int      
	 
	insert into [{databaseOwner}].[{objectQualifier}PMessage](FromUserID,Created,Subject,Body,Flags)
	values(@FromUserID,GETUTCDATE() ,@Subject,@Body,@Flags)

	set @PMessageID = SCOPE_IDENTITY()
	if (@ToUserID = 0)
	begin
		insert into [{databaseOwner}].[{objectQualifier}UserPMessage](UserID,PMessageID,Flags)
		select
				a.UserID,@PMessageID,2
		from
				[{databaseOwner}].[{objectQualifier}User] a
				join [{databaseOwner}].[{objectQualifier}UserGroup] b on b.UserID=a.UserID
				join [{databaseOwner}].[{objectQualifier}Group] c on c.GroupID=b.GroupID where
				(c.Flags & 2)=0 and
				c.BoardID=(select BoardID from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=@FromUserID) and a.UserID<>@FromUserID
		group by
				a.UserID
	end
	else
	begin
		insert into [{databaseOwner}].[{objectQualifier}UserPMessage](UserID,PMessageID,Flags) values(@ToUserID,@PMessageID,2)
	end	
end
GO


CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}pmessage_archive](@UserPMessageID int = NULL) AS
BEGIN
		-- set IsArchived bit
	UPDATE [{databaseOwner}].[{objectQualifier}UserPMessage] SET [Flags] = ([Flags] | 4) WHERE UserPMessageID = @UserPMessageID AND IsArchived = 0
END
GO


CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}poll_stats](@PollID int = null) AS
BEGIN

  	SELECT
			
		a.PollID,
		b.Question,
		b.Closes,
		b.UserID,		
		a.[ObjectPath],
		a.[MimeType],
		QuestionObjectPath = b.[ObjectPath],
		QuestionMimeType = b.[MimeType],
		a.ChoiceID,
		a.Choice,
		a.Votes,
		IsBound = convert(int,pg.Flags & 2), 
		IsClosedBound = convert(int,pg.Flags & 4), 
		(select sum(x.Votes) from [{databaseOwner}].[{objectQualifier}Choice] x where  x.PollID = a.PollID) as [Total],
		[Stats] = (select 100 * a.Votes / case sum(x.Votes) when 0 then 1 else sum(x.Votes) end from [{databaseOwner}].[{objectQualifier}Choice] x where x.PollID=a.PollID)
	FROM
		[{databaseOwner}].[{objectQualifier}Choice] a		
	INNER JOIN 
		[{databaseOwner}].[{objectQualifier}Poll] b ON b.PollID = a.PollID
	INNER JOIN  
		[{databaseOwner}].[{objectQualifier}PollGroupCluster] pg ON pg.PollGroupID = b.PollGroupID	
		WHERE
		b.PollID = @PollID

END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}pollgroup_stats](@PollGroupID int) AS
BEGIN
		SELECT		
		GroupUserID = pg.UserID,	
		a.PollID,
		b.PollGroupID,
		b.Question,
		b.Closes,
		a.ChoiceID,
		a.Choice,
		a.Votes,
		a.ObjectPath,
		a.MimeType,
		QuestionObjectPath = b.[ObjectPath],
		QuestionMimeType = b.[MimeType],
		IsBound = convert(int,pg.Flags & 2),
		IsClosedBound = convert(int,pg.Flags & 4),
		(select sum(x.Votes) from [{databaseOwner}].[{objectQualifier}Choice] x where  x.PollID = a.PollID) as [Total],
		[Stats] = (select 100 * a.Votes / case sum(x.Votes) when 0 then 1 else sum(x.Votes) end from [{databaseOwner}].[{objectQualifier}Choice] x where x.PollID=a.PollID)
	FROM
		[{databaseOwner}].[{objectQualifier}Choice] a		
	INNER JOIN 
		[{databaseOwner}].[{objectQualifier}Poll] b ON b.PollID = a.PollID
	INNER JOIN  
		[{databaseOwner}].[{objectQualifier}PollGroupCluster] pg ON pg.PollGroupID = b.PollGroupID			
	WHERE
		pg.PollGroupID = @PollGroupID
		ORDER BY b.PollGroupID
	--	GROUP BY a.PollID, b.Question, b.Closes, a.ChoiceID, a.Choice,a.Votes
		END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}pollvote_check](@PollID int, @UserID int = NULL,@RemoteIP varchar(39) = NULL) AS
		IF @UserID IS NULL
	BEGIN
		IF @RemoteIP IS NOT NULL
		BEGIN
			-- check by remote IP
			SELECT PollVoteID FROM [{databaseOwner}].[{objectQualifier}PollVote] WHERE PollID = @PollID AND RemoteIP = @RemoteIP
		END
	END
	ELSE
	BEGIN
		-- check by userid or remote IP
		SELECT PollVoteID FROM [{databaseOwner}].[{objectQualifier}PollVote] WHERE PollID = @PollID AND (UserID = @UserID OR RemoteIP = @RemoteIP)
	END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}pollgroup_votecheck](@PollGroupID int, @UserID int = NULL,@RemoteIP varchar(39) = NULL) AS
	IF @UserID IS NULL
	  BEGIN
		IF @RemoteIP IS NOT NULL
		BEGIN
			-- check by remote IP
			SELECT PollID FROM [{databaseOwner}].[{objectQualifier}PollVote] WHERE PollID IN ( SELECT PollID FROM [{databaseOwner}].[{objectQualifier}Poll] WHERE PollGroupID = @PollGroupID) AND RemoteIP = @RemoteIP
		END
		ELSE
		BEGIN
		-- to get structure
		    SELECT PollID FROM [{databaseOwner}].[{objectQualifier}PollVote] WHERE PollID IN ( SELECT PollID FROM [{databaseOwner}].[{objectQualifier}Poll] WHERE PollGroupID = @PollGroupID) AND RemoteIP = @RemoteIP
		END
	  END
	ELSE
	  BEGIN
		-- check by userid or remote IP
		SELECT PollID FROM [{databaseOwner}].[{objectQualifier}PollVote] WHERE PollID IN ( SELECT PollID FROM [{databaseOwner}].[{objectQualifier}Poll] WHERE PollGroupID = @PollGroupID) AND (UserID = @UserID OR RemoteIP = @RemoteIP)
	   END
GO

create procedure [{databaseOwner}].[{objectQualifier}post_alluser](@BoardID int,@UserID int,@PageUserID int,@topCount int = 0) as
begin
		IF (@topCount IS NULL) SET @topCount = 0;		
		SET NOCOUNT ON
		SET ROWCOUNT @topCount

	select
		a.MessageID,
		a.Posted,
		[Subject] = c.Topic,
		a.[Message],		
		a.IP,
		a.UserID,
		a.Flags,
		UserName = IsNull(a.UserName,b.Name),
		b.[Signature],
		c.TopicID
	from
		[{databaseOwner}].[{objectQualifier}Message] a
		join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=a.UserID
		join [{databaseOwner}].[{objectQualifier}Topic] c on c.TopicID=a.TopicID
		join [{databaseOwner}].[{objectQualifier}Forum] d on d.ForumID=c.ForumID
		join [{databaseOwner}].[{objectQualifier}Category] e on e.CategoryID=d.CategoryID
		join [{databaseOwner}].[{objectQualifier}vaccess] x on x.ForumID=d.ForumID
	where
		a.UserID = @UserID and
		x.UserID = @PageUserID and
		x.ReadAccess <> 0 and
		e.BoardID = @BoardID and
		(a.Flags & 24)=16 and
		(c.Flags & 8)=0
	order by
		a.Posted desc
		
	SET ROWCOUNT 0;
end
GO

create procedure [{databaseOwner}].[{objectQualifier}post_list](@TopicID int,@UpdateViewCount smallint=1, @ShowDeleted bit = 1, @StyledNicks bit = 0) as
begin
		set nocount on
	if @UpdateViewCount>0
		update [{databaseOwner}].[{objectQualifier}Topic] set [Views] = [Views] + 1 where TopicID = @TopicID
	select
		d.TopicID,		
		TopicFlags	= d.Flags,
		ForumFlags	= g.Flags,
		a.MessageID,
		a.Posted,
		[Subject] = d.Topic,
		[Message] = '', -- no longer returns message
		a.UserID,
		a.Position,
		a.Indent,
		a.IP,
		a.Flags,
		a.EditReason,
		a.IsModeratorChanged,
		a.IsDeleted,
		a.DeleteReason,
		UserName	= IsNull(a.UserName,b.Name),
		b.Joined,
		b.Avatar,
		b.[Signature],
		Posts		= b.NumPosts,
		b.Points,
		d.[Views],
		d.ForumID,
		RankName = c.Name,		
		c.RankImage,
		Style = case(@StyledNicks)
			when 1 then  ISNULL(( SELECT TOP 1 f.Style FROM [{databaseOwner}].[{objectQualifier}UserGroup] e 
		join [{databaseOwner}].[{objectQualifier}Group] f on f.GroupID=e.GroupID WHERE e.UserID=b.UserID AND LEN(f.Style) > 2 ORDER BY f.SortOrder), c.Style)  
			else ''	 end, 
		Edited = IsNull(a.Edited,a.Posted),
		HasAttachments	= (select count(1) from [{databaseOwner}].[{objectQualifier}Attachment] x where x.MessageID=a.MessageID),
		HasAvatarImage = (select count(1) from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=b.UserID and AvatarImage is not null)
	from
		[{databaseOwner}].[{objectQualifier}Message] a
		join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=a.UserID
		join [{databaseOwner}].[{objectQualifier}Topic] d on d.TopicID=a.TopicID
		join [{databaseOwner}].[{objectQualifier}Forum] g on g.ForumID=d.ForumID
		join [{databaseOwner}].[{objectQualifier}Category] h on h.CategoryID=g.CategoryID
		join [{databaseOwner}].[{objectQualifier}Rank] c on c.RankID=b.RankID	
	where
		a.TopicID = @TopicID
		AND a.IsApproved = 1
		AND (a.IsDeleted = 0 OR (@showdeleted = 1 AND a.IsDeleted = 1)) 
	order by
		a.Posted asc
end
GO

create procedure [{databaseOwner}].[{objectQualifier}post_list_reverse10](@TopicID int) as
begin
		set nocount on

	select top 10
		a.Posted,
		[Subject] = d.Topic,
		a.[Message],
		a.UserID,
		a.Flags,
		UserName = IsNull(a.UserName,b.Name),
		b.[Signature]
	from
		[{databaseOwner}].[{objectQualifier}Message] a 
		inner join [{databaseOwner}].[{objectQualifier}User] b on b.UserID = a.UserID
		inner join [{databaseOwner}].[{objectQualifier}Topic] d on d.TopicID = a.TopicID
	where
		(a.Flags & 24)=16 and
		a.TopicID = @TopicID
	order by
		a.Posted desc
end
GO

create procedure [{databaseOwner}].[{objectQualifier}rank_delete](@RankID int) as begin
		delete from [{databaseOwner}].[{objectQualifier}Rank] where RankID = @RankID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}rank_list](@BoardID int,@RankID int=null) as begin
		if @RankID is null
		select
			a.*
		from
			[{databaseOwner}].[{objectQualifier}Rank] a
		where
			a.BoardID=@BoardID
		order by
			a.MinPosts,
			a.Name
	else
		select
			a.*
		from
			[{databaseOwner}].[{objectQualifier}Rank] a
		where
			a.RankID = @RankID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}rank_save](
	@RankID		int,
	@BoardID	int,
	@Name		nvarchar(50),
	@IsStart	bit,
	@IsLadder	bit,
	@MinPosts	int,
	@RankImage	nvarchar(50)=null,
	@PMLimit    int,
	@Style      nvarchar(255)=null,
	@SortOrder  smallint,
	@Description nvarchar(128)=null,
	@UsrSigChars int=null,
	@UsrSigBBCodes	nvarchar(255)=null,
	@UsrSigHTMLTags nvarchar(255)=null,
	@UsrAlbums int=null,
	@UsrAlbumImages int=null  
) as
begin
		declare @Flags int

	if @IsLadder=0 set @MinPosts = null
	if @IsLadder=1 and @MinPosts is null set @MinPosts = 0
	
	set @Flags = 0
	if @IsStart<>0 set @Flags = @Flags | 1
	if @IsLadder<>0 set @Flags = @Flags | 2
	
	if @RankID>0 begin
		update [{databaseOwner}].[{objectQualifier}Rank] set
			Name = @Name,
			Flags = @Flags,
			MinPosts = @MinPosts,
			RankImage = @RankImage,
			PMLimit = @PMLimit,
			Style = @Style,
			SortOrder = @SortOrder,
			[Description] = @Description,
			UsrSigChars = @UsrSigChars,
			UsrSigBBCodes = @UsrSigBBCodes,
			UsrSigHTMLTags = @UsrSigHTMLTags,
			UsrAlbums = @UsrAlbums,
			UsrAlbumImages = @UsrAlbumImages
		where RankID = @RankID
	end
	else begin
		insert into [{databaseOwner}].[{objectQualifier}Rank](BoardID,Name,Flags,MinPosts,RankImage, PMLimit,Style,SortOrder,Description,UsrSigChars,UsrSigBBCodes,UsrSigHTMLTags,UsrAlbums,UsrAlbumImages)
		values(@BoardID,@Name,@Flags,@MinPosts,@RankImage,@PMLimit,@Style,@SortOrder,@Description,@UsrSigChars,@UsrSigBBCodes,@UsrSigHTMLTags,@UsrAlbums,@UsrAlbumImages);
	end
end
GO

create procedure [{databaseOwner}].[{objectQualifier}registry_list](@Name nvarchar(50) = null,@BoardID int = null) as
BEGIN
		if @BoardID is null
	begin
		IF @Name IS NULL OR @Name = ''
		BEGIN
			SELECT * FROM [{databaseOwner}].[{objectQualifier}Registry] where BoardID is null
		END ELSE
		BEGIN
			SELECT * FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE LOWER(Name) = LOWER(@Name) and BoardID is null
		END
	end else 
	begin
		IF @Name IS NULL OR @Name = ''
		BEGIN
			SELECT * FROM [{databaseOwner}].[{objectQualifier}Registry] where BoardID=@BoardID
		END ELSE
		BEGIN
			SELECT * FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE LOWER(Name) = LOWER(@Name) and BoardID=@BoardID
		END
	end
END
GO

create procedure [{databaseOwner}].[{objectQualifier}registry_save](
	@Name nvarchar(50),
	@Value ntext = NULL,
	@BoardID int = null
) AS
BEGIN
		if @BoardID is null
	begin
		if exists(select 1 from [{databaseOwner}].[{objectQualifier}Registry] where lower(Name)=lower(@Name))
			update [{databaseOwner}].[{objectQualifier}Registry] set Value = @Value where lower(Name)=lower(@Name) and BoardID is null
		else
		begin
			insert into [{databaseOwner}].[{objectQualifier}Registry](Name,Value) values(lower(@Name),@Value)
		end
	end else
	begin
		if exists(select 1 from [{databaseOwner}].[{objectQualifier}Registry] where lower(Name)=lower(@Name) and BoardID=@BoardID)
			update [{databaseOwner}].[{objectQualifier}Registry] set Value = @Value where lower(Name)=lower(@Name) and BoardID=@BoardID
		else
		begin
			insert into [{databaseOwner}].[{objectQualifier}Registry](Name,Value,BoardID) values(lower(@Name),@Value,@BoardID)
		end
	end
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}replace_words_delete](@ID int) AS
BEGIN
		DELETE FROM [{databaseOwner}].[{objectQualifier}replace_words] WHERE ID = @ID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}replace_words_list]
(
	@BoardID int,
	@ID int = null
)
AS BEGIN
		IF (@ID IS NOT NULL AND @ID <> 0)
		SELECT * FROM [{databaseOwner}].[{objectQualifier}Replace_Words] WHERE BoardID = @BoardID AND ID = @ID
	ELSE
		SELECT * FROM [{databaseOwner}].[{objectQualifier}Replace_Words] WHERE BoardID = @BoardID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}replace_words_save]
(
	@BoardID int,
	@ID int = null,
	@BadWord nvarchar(255),
	@GoodWord nvarchar(255)
)
AS
BEGIN
		IF (@ID IS NOT NULL AND @ID <> 0)
	BEGIN
		UPDATE [{databaseOwner}].[{objectQualifier}replace_words] SET BadWord = @BadWord, GoodWord = @GoodWord WHERE ID = @ID		
	END
	ELSE BEGIN
		INSERT INTO [{databaseOwner}].[{objectQualifier}replace_words]
			(BoardID,BadWord,GoodWord)
		VALUES
			(@BoardID,@BadWord,@GoodWord)
	END
END
GO

create procedure [{databaseOwner}].[{objectQualifier}smiley_delete](@SmileyID int=null) as begin
		if @SmileyID is not null
		delete from [{databaseOwner}].[{objectQualifier}Smiley] where SmileyID=@SmileyID
	else
		delete from [{databaseOwner}].[{objectQualifier}Smiley]
end
GO

create procedure [{databaseOwner}].[{objectQualifier}smiley_list](@BoardID int,@SmileyID int=null) as
begin
		if @SmileyID is null
		select * from [{databaseOwner}].[{objectQualifier}Smiley] where BoardID=@BoardID order by SortOrder, LEN(Code) desc
	else
		select * from [{databaseOwner}].[{objectQualifier}Smiley] where SmileyID=@SmileyID order by SortOrder
end
GO

create procedure [{databaseOwner}].[{objectQualifier}smiley_listunique](@BoardID int) as
begin
		select 
		Icon, 
		Emoticon,
		Code = (select top 1 Code from [{databaseOwner}].[{objectQualifier}Smiley] x where x.Icon=[{databaseOwner}].[{objectQualifier}Smiley].Icon),
		SortOrder = (select top 1 SortOrder from [{databaseOwner}].[{objectQualifier}Smiley] x where x.Icon=[{databaseOwner}].[{objectQualifier}Smiley].Icon order by x.SortOrder asc)
	from 
		[{databaseOwner}].[{objectQualifier}Smiley]
	where
		BoardID=@BoardID
	group by
		Icon,
		Emoticon
	order by
		SortOrder,
		Code
end
GO

create procedure [{databaseOwner}].[{objectQualifier}smiley_save](@SmileyID int=null,@BoardID int,@Code nvarchar(10),@Icon nvarchar(50),@Emoticon nvarchar(50),@SortOrder tinyint,@Replace smallint=0) as begin
		if @SmileyID is not null begin
		update [{databaseOwner}].[{objectQualifier}Smiley] set Code = @Code, Icon = @Icon, Emoticon = @Emoticon, SortOrder = @SortOrder where SmileyID = @SmileyID
	end
	else begin
		if @Replace>0
			delete from [{databaseOwner}].[{objectQualifier}Smiley] where Code=@Code

		if not exists(select 1 from [{databaseOwner}].[{objectQualifier}Smiley] where BoardID=@BoardID and Code=@Code)
			insert into [{databaseOwner}].[{objectQualifier}Smiley](BoardID,Code,Icon,Emoticon,SortOrder) values(@BoardID,@Code,@Icon,@Emoticon,@SortOrder)
	end
end
GO

create procedure [{databaseOwner}].[{objectQualifier}smiley_resort](@BoardID int,@SmileyID int,@Move int) as
begin
		declare @Position int

	SELECT @Position=SortOrder FROM [{databaseOwner}].[{objectQualifier}Smiley] WHERE BoardID=@BoardID and SmileyID=@SmileyID

	if (@Position is null) return

	if (@Move > 0) begin
		update [{databaseOwner}].[{objectQualifier}Smiley]
			set SortOrder=SortOrder-1
			where BoardID=@BoardID and 
				SortOrder between @Position and (@Position + @Move) and
				SortOrder between 1 and 255
	end
	else if (@Move < 0) begin
		update [{databaseOwner}].[{objectQualifier}Smiley]
			set SortOrder=SortOrder+1
			where BoardID=@BoardID and 
				SortOrder between (@Position+@Move) and @Position and
				SortOrder between 0 and 254
	end

	SET @Position = @Position + @Move

	if (@Position>255) SET @Position = 255
	else if (@Position<0) SET @Position = 0

	update [{databaseOwner}].[{objectQualifier}Smiley]
		set SortOrder=@Position
		where BoardID=@BoardID and 
			SmileyID=@SmileyID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}system_initialize](
	@Name		nvarchar(50),
	@TimeZone	int,
	@Culture	char(5),
	@LanguageFile nvarchar(50),
	@ForumEmail	nvarchar(50),
	@SmtpServer	nvarchar(50),
	@User		nvarchar(255),
	@UserEmail	nvarchar(255),
	@Userkey	nvarchar(64)
	
) as 
begin
		DECLARE @tmpValue AS nvarchar(100)

	-- initalize required 'registry' settings
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'version','1'
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'versionname','1.0.0'
	SET @tmpValue = CAST(@TimeZone AS nvarchar(100))
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'timezone', @tmpValue
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'culture', @Culture
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'language', @LanguageFile
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'smtpserver', @SmtpServer
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'forumemail', @ForumEmail

	-- initalize new board
	EXEC [{databaseOwner}].[{objectQualifier}board_create] @Name, @Culture, @LanguageFile, '','',@User,@UserEmail,@UserKey,1
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}system_updateversion]
(
	@Version		int,
	@VersionName	nvarchar(50)
) 
AS
BEGIN
		DECLARE @tmpValue AS nvarchar(100)
	SET @tmpValue = CAST(@Version AS nvarchar(100))
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'version', @tmpValue
	EXEC [{databaseOwner}].[{objectQualifier}registry_save] 'versionname',@VersionName

END
GO

create procedure [{databaseOwner}].[{objectQualifier}topic_active](@BoardID int,@UserID int,@Since datetime,@CategoryID int=null, @StyledNicks bit = 0) as
begin
		select
		c.ForumID,
		c.TopicID,
		c.TopicMovedID,
		c.Posted,
		LinkTopicID = IsNull(c.TopicMovedID,c.TopicID),
		[Subject] = c.Topic,
		c.UserID,
		Starter = IsNull(c.UserName,b.Name),
		NumPostsDeleted = (SELECT COUNT(1) FROM [{databaseOwner}].[{objectQualifier}Message] mes WHERE mes.TopicID = c.TopicID AND mes.IsDeleted = 1 AND mes.IsApproved = 1 AND ((@UserID IS NOT NULL AND mes.UserID = @UserID) OR (@UserID IS NULL)) ),
		Replies = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=c.TopicID and (x.Flags & 8)=0) - 1,
		[Views] = c.[Views],
		LastPosted = c.LastPosted,
		LastUserID = c.LastUserID,
		LastUserName = IsNull(c.LastUserName,(select Name from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=c.LastUserID)),
		LastMessageID = c.LastMessageID,
		LastMessageFlags = c.LastMessageFlags,
		LastTopicID = c.TopicID,
		TopicFlags = c.Flags,
		c.Priority,
		c.PollID,
		ForumName = d.Name,
		c.TopicMovedID,
		ForumFlags = d.Flags,
		FirstMessage = (SELECT TOP 1 CAST([Message] as nvarchar(1000)) FROM [{databaseOwner}].[{objectQualifier}Message] mes2 where mes2.TopicID = IsNull(c.TopicMovedID,c.TopicID) AND mes2.Position = 0),
		StarterStyle = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](c.UserID)  
			else ''	 end,
		LastUserStyle = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](c.LastUserID)  
			else ''	 end
	from
		[{databaseOwner}].[{objectQualifier}Topic] c
		join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=c.UserID
		join [{databaseOwner}].[{objectQualifier}Forum] d on d.ForumID=c.ForumID
		join [{databaseOwner}].[{objectQualifier}vaccess] x on x.ForumID=d.ForumID
		join [{databaseOwner}].[{objectQualifier}Category] e on e.CategoryID=d.CategoryID
	where
		@Since < c.LastPosted and
		x.UserID = @UserID and
		x.ReadAccess <> 0 and
		e.BoardID = @BoardID and
		(@CategoryID is null or e.CategoryID=@CategoryID) and
		c.IsDeleted = 0
		and	c.TopicMovedID is null 
	order by
		d.Name asc,
		Priority desc,
		LastPosted desc
end
GO


CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_delete] (@TopicID int,@UpdateLastPost bit=1,@EraseTopic bit=0) 
AS
BEGIN
		SET NOCOUNT ON
	DECLARE @ForumID int
	DECLARE @pollID int
	
	SELECT @ForumID=ForumID FROM  [{databaseOwner}].[{objectQualifier}Topic] WHERE TopicID=@TopicID
	
	UPDATE [{databaseOwner}].[{objectQualifier}Topic] SET LastMessageID = null WHERE TopicID = @TopicID
	
	UPDATE [{databaseOwner}].[{objectQualifier}Forum] SET 
		LastTopicID = null,
		LastMessageID = null,
		LastUserID = null,
		LastUserName = null,
		LastPosted = null
	WHERE LastMessageID IN (SELECT MessageID FROM  [{databaseOwner}].[{objectQualifier}Message] WHERE TopicID = @TopicID)
	
	UPDATE  [{databaseOwner}].[{objectQualifier}Active] SET TopicID = null WHERE TopicID = @TopicID
	
	--delete messages and topics
	DELETE FROM  [{databaseOwner}].[{objectQualifier}nntptopic] WHERE TopicID = @TopicID
	
	IF @EraseTopic = 0
	BEGIN
		UPDATE  [{databaseOwner}].[{objectQualifier}topic] set Flags = Flags | 8 where TopicMovedID = @TopicID
		UPDATE  [{databaseOwner}].[{objectQualifier}topic] set Flags = Flags | 8 where TopicID = @TopicID
		UPDATE  [{databaseOwner}].[{objectQualifier}Message] set Flags = Flags | 8 where TopicID = @TopicID
	END
	ELSE
	BEGIN
		--remove polls	
		SELECT @pollID = pollID FROM  [{databaseOwner}].[{objectQualifier}topic] WHERE TopicID = @TopicID
		IF (@pollID is not null)
		BEGIN
			UPDATE  [{databaseOwner}].[{objectQualifier}topic] SET PollID = null WHERE TopicID = @TopicID
			EXEC [{databaseOwner}].[{objectQualifier}pollgroup_remove] @pollID, @TopicID, null, null, null, 0, 0 
		END	
	
		DELETE FROM  [{databaseOwner}].[{objectQualifier}topic] WHERE TopicMovedID = @TopicID
		
		DELETE  [{databaseOwner}].[{objectQualifier}Attachment] WHERE MessageID IN (SELECT MessageID FROM  [{databaseOwner}].[{objectQualifier}message] WHERE TopicID = @TopicID) 
		DELETE  [{databaseOwner}].[{objectQualifier}MessageHistory] WHERE MessageID IN (SELECT MessageID FROM  [{databaseOwner}].[{objectQualifier}message] WHERE TopicID = @TopicID) 	
		DELETE  [{databaseOwner}].[{objectQualifier}Message] WHERE TopicID = @TopicID
		DELETE  [{databaseOwner}].[{objectQualifier}WatchTopic] WHERE TopicID = @TopicID
		DELETE  [{databaseOwner}].[{objectQualifier}FavoriteTopic]  WHERE TopicID = @TopicID
		DELETE  [{databaseOwner}].[{objectQualifier}Topic] WHERE TopicMovedID = @TopicID
		DELETE  [{databaseOwner}].[{objectQualifier}Topic] WHERE TopicID = @TopicID
		DELETE  [{databaseOwner}].[{objectQualifier}MessageReportedAudit] WHERE MessageID IN (SELECT MessageID FROM  [{databaseOwner}].[{objectQualifier}message] WHERE TopicID = @TopicID) 
		DELETE  [{databaseOwner}].[{objectQualifier}MessageReported] WHERE MessageID IN (SELECT MessageID FROM  [{databaseOwner}].[{objectQualifier}message] WHERE TopicID = @TopicID)
		
	END
		
	--commit
	IF @UpdateLastPost<>0
		EXEC  [{databaseOwner}].[{objectQualifier}forum_updatelastpost] @ForumID
	
	IF @ForumID is not null
		EXEC  [{databaseOwner}].[{objectQualifier}forum_updatestats] @ForumID
END
GO

create procedure [{databaseOwner}].[{objectQualifier}pollgroup_remove](@PollGroupID int, @TopicID int =null, @ForumID int= null, @CategoryID int = null, @BoardID int = null, @RemoveCompletely bit, @RemoveEverywhere bit)
 as
  begin
   
	 declare @polllist table
	( PollID int)
	declare @tmp int


		 if @RemoveEverywhere <> 1 
			 begin
				   if @TopicID > 0
				   Update [{databaseOwner}].[{objectQualifier}Topic] set PollID = NULL where TopicID = @TopicID                 
                  
				   if @ForumID > 0
                   Update [{databaseOwner}].[{objectQualifier}Forum] set PollGroupID = NULL where ForumID = @ForumID
              
	               if @CategoryID > 0
                   Update [{databaseOwner}].[{objectQualifier}Category] set PollGroupID = NULL where CategoryID = @CategoryID
                
		           end
	
	      if ( @RemoveEverywhere = 1 OR @RemoveCompletely = 1)
		 begin
				   Update [{databaseOwner}].[{objectQualifier}Topic] set PollID = NULL where PollID = @PollGroupID 
                   Update [{databaseOwner}].[{objectQualifier}Forum] set PollGroupID = NULL where PollGroupID = @PollGroupID
				   Update [{databaseOwner}].[{objectQualifier}Category] set PollGroupID = NULL where PollGroupID = @PollGroupID				 
         end

	        	-- all polls in the group 
	if @RemoveCompletely = 1 
	begin

	insert into @polllist (PollID)
	select PollID from [{databaseOwner}].[{objectQualifier}Poll] where PollGroupID = @PollGroupID   

	
			DELETE FROM  [{databaseOwner}].[{objectQualifier}pollvote] WHERE PollID IN (SELECT PollID FROM @polllist)
			DELETE FROM  [{databaseOwner}].[{objectQualifier}choice] WHERE PollID IN (SELECT PollID FROM @polllist)
			UPDATE [{databaseOwner}].[{objectQualifier}poll] SET PollGroupID = NULL WHERE PollGroupID = @PollGroupID
			DELETE FROM  [{databaseOwner}].[{objectQualifier}poll] WHERE PollGroupID = @PollGroupID 
    end
	else
	begin
	UPDATE [{databaseOwner}].[{objectQualifier}poll] SET PollGroupID = NULL WHERE   PollGroupID = @PollGroupID
	end


				    
	-- this is the last one
	IF NOT EXISTS (select 1 from [{databaseOwner}].[{objectQualifier}Poll] where PollGroupID = @PollGroupID)
	begin	 
        DELETE FROM  [{databaseOwner}].[{objectQualifier}PollGroupCluster] WHERE PollGroupID = @PollGroupID		
	end
		end
GO

create procedure [{databaseOwner}].[{objectQualifier}pollgroup_attach](@PollGroupID int, @TopicID int = null, @ForumID int = null, @CategoryID int = null, @BoardID int = null) as
begin
	               if @TopicID > 0
				   begin
				   if exists (select 1 from [{databaseOwner}].[{objectQualifier}Topic] where TopicID = @TopicID  and PollID is not null)
				   begin
				   SELECT 1
				   end
				   else
				   begin
				   Update [{databaseOwner}].[{objectQualifier}Topic] set PollID = @PollGroupID where TopicID = @TopicID 
				   SELECT 0
				   end
				   end              
                  
				   if @ForumID > 0
				   begin
				   if exists (select 1 from [{databaseOwner}].[{objectQualifier}Forum] where ForumID = @ForumID and PollGroupID is not null)
                   begin
				   SELECT 1
				   end
				   else
				   begin
				   Update [{databaseOwner}].[{objectQualifier}Forum] set PollGroupID = @PollGroupID where ForumID = @ForumID
                   SELECT 0
				   end
				   end

	               if @CategoryID > 0
				   begin
				   if exists (select 1 from [{databaseOwner}].[{objectQualifier}Category] where CategoryID = @CategoryID and PollGroupID is null)
                   begin
				   SELECT 1
				   end
				   else
				   begin
				   Update [{databaseOwner}].[{objectQualifier}Category] set PollGroupID = @PollGroupID where CategoryID = @CategoryID
                   SELECT 0
				   end
				   end
		               

end
GO

create procedure [{databaseOwner}].[{objectQualifier}pollgroup_list](@UserID int, @ForumID int = null, @BoardID int) as
begin
	select distinct(p.Question), p.PollGroupID from [{databaseOwner}].[{objectQualifier}Poll] p
	LEFT JOIN 	[{databaseOwner}].[{objectQualifier}PollGroupCluster] pgc ON pgc.PollGroupID = p.PollGroupID
	-- WHERE p.Closes IS NULL OR p.Closes > GETUTCDATE()
	order by Question asc
end
GO


create procedure [{databaseOwner}].[{objectQualifier}topic_findnext](@TopicID int) as
begin
		declare @LastPosted datetime
	declare @ForumID int
	select @LastPosted = LastPosted, @ForumID = ForumID from [{databaseOwner}].[{objectQualifier}Topic] where TopicID = @TopicID
	select top 1 TopicID from [{databaseOwner}].[{objectQualifier}Topic] where LastPosted>@LastPosted and ForumID = @ForumID AND (Flags & 8) = 0 order by LastPosted asc
end
GO

create procedure [{databaseOwner}].[{objectQualifier}topic_findprev](@TopicID int) AS 
BEGIN
		DECLARE @LastPosted datetime
	DECLARE @ForumID int
	SELECT @LastPosted = LastPosted, @ForumID = ForumID FROM [{databaseOwner}].[{objectQualifier}Topic] WHERE TopicID = @TopicID
	SELECT TOP 1 TopicID from [{databaseOwner}].[{objectQualifier}Topic] where LastPosted<@LastPosted AND ForumID = @ForumID AND (Flags & 8) = 0 ORDER BY LastPosted DESC
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_info]
(
	@TopicID int = null,
	@ShowDeleted bit = 0
)
AS
BEGIN
		IF @TopicID = 0 SET @TopicID = NULL

	IF @TopicID IS NULL
	BEGIN
		IF @ShowDeleted = 1 
			SELECT * FROM [{databaseOwner}].[{objectQualifier}Topic]
		ELSE
			SELECT * FROM [{databaseOwner}].[{objectQualifier}Topic] WHERE (Flags & 8) = 0
	END
	ELSE
	BEGIN
		IF @ShowDeleted = 1 
			SELECT * FROM [{databaseOwner}].[{objectQualifier}Topic] WHERE TopicID = @TopicID
		ELSE
			SELECT * FROM [{databaseOwner}].[{objectQualifier}Topic] WHERE TopicID = @TopicID AND (Flags & 8) = 0		
	END
END
GO


CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_announcements]
(
	@BoardID int,
	@NumPosts int,
	@UserID int
)
AS
BEGIN
		DECLARE @SQL nvarchar(500)

	SET @SQL = 'SELECT DISTINCT TOP ' + convert(varchar, @NumPosts) + ' t.Topic, t.LastPosted, t.Posted, t.TopicID, t.LastMessageID, t.LastMessageFlags FROM'
	SET @SQL = @SQL + ' [{databaseOwner}].[{objectQualifier}Topic] t INNER JOIN [{databaseOwner}].[{objectQualifier}Category] c INNER JOIN [{databaseOwner}].[{objectQualifier}Forum] f ON c.CategoryID = f.CategoryID ON t.ForumID = f.ForumID'
	SET @SQL = @SQL + ' join [{databaseOwner}].[{objectQualifier}vaccess] v on v.ForumID=f.ForumID'
	SET @SQL = @SQL + ' WHERE c.BoardID = ' + convert(varchar, @BoardID) + ' AND v.UserID=' + convert(varchar,@UserID) + ' AND (v.ReadAccess <> 0 or (f.Flags & 2) = 0) AND (t.Flags & 8) != 8 AND t.TopicMovedID IS NULL AND (t.Priority = 2) ORDER BY t.LastPosted DESC'

	EXEC(@SQL)	

END
GO


CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_latest]
(
	@BoardID int,
	@NumPosts int,
	@UserID int,
	@StyledNicks bit = 0,
	@ShowNoCountPosts  bit = 0
)
AS
BEGIN	
	
	SET ROWCOUNT @NumPosts
	SELECT
		t.LastPosted,
		t.ForumID,
		f.Name as Forum,
		t.Topic,
		t.TopicID,
		t.TopicMovedID,
		t.UserID,
		t.UserName,		
		t.LastMessageID,
		t.LastMessageFlags,
		t.LastUserID,
		t.NumPosts,
		t.Posted,		
		LastUserName = IsNull(t.LastUserName,(select [Name] from [{databaseOwner}].[{objectQualifier}User] x where x.UserID = t.LastUserID)),
		LastUserStyle = case(@StyledNicks) when 1 
		then  [{databaseOwner}].[{objectQualifier}get_userstyle](t.LastUserID)  
		else '' end		 	
	FROM	
		[{databaseOwner}].[{objectQualifier}Topic] t 
	INNER JOIN
		[{databaseOwner}].[{objectQualifier}Forum] f ON t.ForumID = f.ForumID	
	INNER JOIN
		[{databaseOwner}].[{objectQualifier}Category] c ON c.CategoryID = f.CategoryID
	JOIN
		[{databaseOwner}].[{objectQualifier}vaccess] v ON v.ForumID=f.ForumID
	WHERE	
		c.BoardID = @BoardID
		AND t.TopicMovedID is NULL
		AND v.UserID=@UserID
		AND (v.ReadAccess <> 0)
		AND t.IsDeleted != 1
		AND t.LastPosted IS NOT NULL
		AND
		f.Flags & 4 <> (CASE WHEN @ShowNoCountPosts > 0 THEN -1 ELSE 4 END)
	ORDER BY
		t.LastPosted DESC;
END
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}topic_list]
(
	@ForumID int,
	@UserID int = null,
	@Announcement smallint,
	@Date datetime=null,
	@Offset int,
	@Count int,
	@StyledNicks bit = 0,
	@ShowMoved  bit = 0
)
AS
begin
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED -- Hold no locks; allows more concurrency
	
	CREATE TABLE #data(
			RowNo	int identity primary key not null,
			TopicID	int not null
	)

	DECLARE	@RowCount int	 

	-- Step 1: Does the host setting show moved topic pointers?
	-- SELECT @ShowMoved = CASE WHEN CAST(Value as NVarChar) = 'True' THEN 1 ELSE 0 END FROM [{databaseOwner}].[{objectQualifier}Registry] WHERE Name='showmoved'
	
	-- Step 2: Get the "root" topics (i.e. non-moved)
	INSERT #data(TopicID)
	SELECT c.TopicID
	FROM [{databaseOwner}].[{objectQualifier}Topic] c JOIN [{databaseOwner}].[{objectQualifier}User] b 
		ON b.UserID=c.UserID 
	JOIN [{databaseOwner}].[{objectQualifier}Forum] d 
		ON d.ForumID=c.ForumID
	WHERE c.ForumID = @ForumID
		AND	(@Date IS NULL OR c.Posted>=@Date OR c.LastPosted>=@Date OR Priority>0) 
		AND ((@Announcement=1 AND c.Priority=2) OR (@Announcement=0 AND c.Priority<>2) OR (@Announcement<0)) 
		AND	(c.Flags & 8) = 0
		AND	(c.TopicMovedID IS NOT NULL OR c.NumPosts > 0) 
	ORDER BY Priority DESC,	c.LastPosted DESC

	SET @RowCount = @@ROWCOUNT	

	IF @ShowMoved = 1
		SELECT
			[RowCount] = @RowCount,
			c.ForumID,
			c.TopicID,
			c.Posted,
			LinkTopicID = IsNull(c.TopicMovedID,c.TopicID),
			c.TopicMovedID,
			[Subject] = c.Topic,
			c.UserID,
			Starter = IsNull(c.UserName,b.Name),
			Replies = c.NumPosts - 1,
			NumPostsDeleted = (SELECT COUNT(1) FROM [{databaseOwner}].[{objectQualifier}Message] mes WHERE mes.TopicID = c.TopicID AND mes.IsDeleted = 1 AND mes.IsApproved = 1 AND ((@UserID IS NOT NULL AND mes.UserID = @UserID) OR (@UserID IS NULL)) ),
			[Views] = c.[Views],
			LastPosted = c.LastPosted,
			LastUserID = c.LastUserID,
			LastUserName = IsNull(c.LastUserName,(SELECT Name FROM [{databaseOwner}].[{objectQualifier}User] x where x.UserID=c.LastUserID)),
			LastMessageID = c.LastMessageID,
			LastTopicID = c.TopicID,
			TopicFlags = c.Flags,
			c.Priority,
			c.PollID,
			ForumFlags = d.Flags,
			FirstMessage = (SELECT TOP 1 CAST([Message] as nvarchar(1000)) FROM [{databaseOwner}].[{objectQualifier}Message] mes2 where mes2.TopicID = IsNull(c.TopicMovedID,c.TopicID) AND mes2.Position = 0),
			StarterStyle = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](c.UserID)  
			else ''	 end,
			LastUserStyle = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](c.LastUserID)  
			else ''	 end
		FROM [{databaseOwner}].[{objectQualifier}Topic] c JOIN [{databaseOwner}].[{objectQualifier}User] b 
			ON b.UserID=c.UserID
		JOIN [{databaseOwner}].[{objectQualifier}Forum] d 
			ON d.ForumID=c.ForumID 
		JOIN #data e 
			ON e.TopicID=c.TopicID
		WHERE e.RowNo BETWEEN @Offset+1 AND @Offset + @Count
		ORDER BY e.RowNo
	ELSE -- Do not show moved topics
		SELECT
			[RowCount] = @RowCount,
			c.ForumID,
			c.TopicID,
			c.Posted,
			LinkTopicID = IsNull(c.TopicMovedID,c.TopicID),
			c.TopicMovedID,
			[Subject] = c.Topic,
			c.UserID,
			Starter = IsNull(c.UserName,b.Name),
			Replies = c.NumPosts - 1,
			NumPostsDeleted = (SELECT COUNT(1) FROM [{databaseOwner}].[{objectQualifier}Message] mes WHERE mes.TopicID = c.TopicID AND mes.IsDeleted = 1 AND mes.IsApproved = 1 AND ((@UserID IS NOT NULL AND mes.UserID = @UserID) OR (@UserID IS NULL)) ),			
			[Views] = c.[Views],
			LastPosted = c.LastPosted,
			LastUserID = c.LastUserID,
			LastUserName = IsNull(c.LastUserName,(SELECT Name FROM [{databaseOwner}].[{objectQualifier}User] x where x.UserID=c.LastUserID)),
			LastMessageID = c.LastMessageID,
			LastTopicID = c.TopicID,
			TopicFlags = c.Flags,
			c.Priority,
			c.PollID,
			ForumFlags = d.Flags,
			FirstMessage = (SELECT TOP 1 CAST([Message] as nvarchar(1000)) FROM [{databaseOwner}].[{objectQualifier}Message] mes2 where mes2.TopicID = IsNull(c.TopicMovedID,c.TopicID) AND mes2.Position = 0),
			StarterStyle = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](c.UserID)  
			else ''	 end,
			LastUserStyle = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](c.LastUserID)  
			else ''	 end
		FROM [{databaseOwner}].[{objectQualifier}Topic] c JOIN [{databaseOwner}].[{objectQualifier}User] b 
			ON b.UserID=c.UserID
		JOIN [{databaseOwner}].[{objectQualifier}Forum] d 
			ON d.ForumID=c.ForumID 
		JOIN #data e 
			ON e.TopicID=c.TopicID
		WHERE e.RowNo BETWEEN @Offset+1 AND @Offset + @Count
			AND c.TopicMovedID IS NULL 
		ORDER BY e.RowNo
end
GO

create procedure [{databaseOwner}].[{objectQualifier}topic_listmessages](@TopicID int) as
begin
		select * from [{databaseOwner}].[{objectQualifier}Message]
	where TopicID = @TopicID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}topic_lock](@TopicID int,@Locked bit) as
begin
		if @Locked<>0
		update [{databaseOwner}].[{objectQualifier}Topic] set Flags = Flags | 1 where TopicID = @TopicID
	else
		update [{databaseOwner}].[{objectQualifier}Topic] set Flags = Flags & ~1 where TopicID = @TopicID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}topic_move](@TopicID int,@ForumID int,@ShowMoved bit) AS
begin
		declare @OldForumID int		

	select @OldForumID = ForumID from [{databaseOwner}].[{objectQualifier}Topic] where TopicID = @TopicID

	if @ShowMoved <> 0 begin
        -- delete an old link if exists
	    delete from [{databaseOwner}].[{objectQualifier}Topic] where TopicMovedID = @TopicID
		-- create a moved message
		insert into [{databaseOwner}].[{objectQualifier}Topic](ForumID,UserID,UserName,Posted,Topic,[Views],Flags,Priority,PollID,TopicMovedID,LastPosted,NumPosts)
		select ForumID,UserID,UserName,Posted,Topic,0,Flags,Priority,PollID,@TopicID,LastPosted,0
		from [{databaseOwner}].[{objectQualifier}Topic] where TopicID = @TopicID
	end

	-- move the topic
	update [{databaseOwner}].[{objectQualifier}Topic] set ForumID = @ForumID where TopicID = @TopicID

	-- update last posts
	exec [{databaseOwner}].[{objectQualifier}forum_updatelastpost] @OldForumID
	exec [{databaseOwner}].[{objectQualifier}forum_updatelastpost] @ForumID
	
	-- update stats
	exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @OldForumID
	exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @ForumID
	
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_prune](@BoardID int, @ForumID int=null,@Days int, @PermDelete bit) as
BEGIN
		DECLARE @c cursor
	DECLARE @TopicID int
	DECLARE @Count int
	SET @Count = 0
	IF @ForumID = 0 SET @ForumID = NULL
	IF @ForumID IS NOT NULL
	BEGIN
		SET @c = cursor for
		SELECT 
			TopicID
		FROM [{databaseOwner}].[{objectQualifier}topic] yt
		INNER JOIN
		[{databaseOwner}].[{objectQualifier}Forum] yf
		ON
		yt.ForumID = yf.ForumID
		INNER JOIN
		[{databaseOwner}].[{objectQualifier}Category] yc
		ON
		yf.CategoryID = yc.CategoryID
		WHERE
			yc.BoardID = @BoardID AND
			yt.ForumID = @ForumID AND
			Priority = 0 AND
			(yt.Flags & 512) = 0 AND /* not flagged as persistent */
			datediff(dd,yt.LastPosted,GETUTCDATE() )>@Days
	END
	ELSE BEGIN
		SET @c = CURSOR FOR
		SELECT 
			TopicID
		FROM 
			[{databaseOwner}].[{objectQualifier}Topic]
		WHERE 
			Priority = 0 and
			(Flags & 512) = 0 and					/* not flagged as persistent */
			datediff(dd,LastPosted,GETUTCDATE() )>@Days
	END
	OPEN @c
	FETCH @c into @TopicID
	WHILE @@FETCH_STATUS=0 BEGIN
		IF (@Count % 100 = 1) WAITFOR DELAY '000:00:05'
		EXEC [{databaseOwner}].[{objectQualifier}topic_delete] @TopicID, @PermDelete
		SET @Count = @Count + 1
		FETCH @c INTO @TopicID
	END
	CLOSE @c
	DEALLOCATE @c

	-- This takes forever with many posts...
	--exec [{databaseOwner}].[{objectQualifier}topic_updatelastpost]

	SELECT Count = @Count
END
GO

create procedure [{databaseOwner}].[{objectQualifier}topic_save](
	@ForumID	int,
	@Subject	nvarchar(100),
	@UserID		int,
	@Message	ntext,
	@Priority	smallint,
	@UserName	nvarchar(255)=null,
	@IP			varchar(39),
	@Posted		datetime=null,
	@BlogPostID	nvarchar(50),
	@Flags		int
) as
begin
		declare @TopicID int
	declare @MessageID int

	if @Posted is null set @Posted = GETUTCDATE() 

	-- create the topic
	insert into [{databaseOwner}].[{objectQualifier}Topic](ForumID,Topic,UserID,Posted,[Views],Priority,UserName,NumPosts)
	values(@ForumID,@Subject,@UserID,@Posted,0,@Priority,@UserName,0)

	-- get its id
	set @TopicID = SCOPE_IDENTITY()
	
	-- add message to the topic
	exec [{databaseOwner}].[{objectQualifier}message_save] @TopicID,@UserID,@Message,@UserName,@IP,@Posted,null,@BlogPostID,@Flags,@MessageID output

	select TopicID = @TopicID, MessageID = @MessageID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}topic_updatelastpost]
(@ForumID int=null,@TopicID int=null) as
begin
		if @TopicID is not null
		update [{databaseOwner}].[{objectQualifier}Topic] set
			LastPosted = (select top 1 x.Posted from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc),
			LastMessageID = (select top 1 x.MessageID from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc),
			LastUserID = (select top 1 x.UserID from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc),
			LastUserName = (select top 1 x.UserName from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc),
			LastMessageFlags = (select top 1 x.Flags from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc)
		where TopicID = @TopicID
	else
		update [{databaseOwner}].[{objectQualifier}Topic] set
			LastPosted = (select top 1 x.Posted from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc),
			LastMessageID = (select top 1 x.MessageID from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc),
			LastUserID = (select top 1 x.UserID from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc),
			LastUserName = (select top 1 x.UserName from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc),
			LastMessageFlags = (select top 1 x.Flags from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and (x.Flags & 24)=16 order by Posted desc)
		where TopicMovedID is null
		and (@ForumID is null or ForumID=@ForumID)

	exec [{databaseOwner}].[{objectQualifier}forum_updatelastpost] @ForumID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}topic_updatetopic]
(@TopicID int,@Topic nvarchar (100)) as
begin
		if @TopicID is not null
		update [{databaseOwner}].[{objectQualifier}Topic] set
			Topic = @Topic
		where TopicID = @TopicID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_accessmasks](@BoardID int,@UserID int) as
begin
		
	select * from(
		select
			AccessMaskID	= e.AccessMaskID,
			AccessMaskName	= e.Name,
			ForumID			= f.ForumID,
			ForumName		= f.Name,
			CategoryID		= f.CategoryID,
			ParentID		= f.ParentID
		from
			[{databaseOwner}].[{objectQualifier}User] a 
			join [{databaseOwner}].[{objectQualifier}UserGroup] b on b.UserID=a.UserID
			join [{databaseOwner}].[{objectQualifier}Group] c on c.GroupID=b.GroupID
			join [{databaseOwner}].[{objectQualifier}ForumAccess] d on d.GroupID=c.GroupID
			join [{databaseOwner}].[{objectQualifier}AccessMask] e on e.AccessMaskID=d.AccessMaskID
			join [{databaseOwner}].[{objectQualifier}Forum] f on f.ForumID=d.ForumID
		where
			a.UserID=@UserID and
			c.BoardID=@BoardID
		group by
			e.AccessMaskID,
			e.Name,
			f.ForumID,
			f.ParentID,
			f.CategoryID,
			f.Name
		
		union
			
		select
			AccessMaskID	= c.AccessMaskID,
			AccessMaskName	= c.Name,
			ForumID			= d.ForumID,
			ForumName		= d.Name,
			CategoryID		= d.CategoryID,
			ParentID		= d.ParentID
		from
			[{databaseOwner}].[{objectQualifier}User] a 
			join [{databaseOwner}].[{objectQualifier}UserForum] b on b.UserID=a.UserID
			join [{databaseOwner}].[{objectQualifier}AccessMask] c on c.AccessMaskID=b.AccessMaskID
			join [{databaseOwner}].[{objectQualifier}Forum] d on d.ForumID=b.ForumID
		where
			a.UserID=@UserID and
			c.BoardID=@BoardID
		group by
			c.AccessMaskID,
			c.Name,
			d.ForumID,
			d.ParentID,
			d.CategoryID,
			d.Name
	) as x
	order by
		ForumName, AccessMaskName
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_activity_rank]
(
	@BoardID AS int,
	@DisplayNumber AS int,
	@StartDate AS datetime
)
AS
BEGIN
		
	DECLARE @GuestUserID int

	SET ROWCOUNT @DisplayNumber

	SET @GuestUserID =
	(SELECT top 1
		a.UserID
	from
		[{databaseOwner}].[{objectQualifier}User] a
		inner join [{databaseOwner}].[{objectQualifier}UserGroup] b on b.UserID = a.UserID
		inner join [{databaseOwner}].[{objectQualifier}Group] c on b.GroupID = c.GroupID
	where
		a.BoardID = @BoardID and
		(c.Flags & 2)<>0
	)

	SELECT
		counter.[ID],
		u.[Name],
		counter.[NumOfPosts]
	FROM
		[{databaseOwner}].[{objectQualifier}User] u inner join
		(
			SELECT m.UserID as ID, Count(m.UserID) as NumOfPosts FROM [{databaseOwner}].[{objectQualifier}Message] m
			WHERE m.Posted >= @StartDate
			GROUP BY m.UserID
		) AS counter ON u.UserID = counter.ID
	WHERE
		u.BoardID = @BoardID and u.UserID != @GuestUserID
	ORDER BY
		NumOfPosts DESC

	SET ROWCOUNT 0
END
GO


create PROCEDURE [{databaseOwner}].[{objectQualifier}user_addpoints] (@UserID int,@Points int) AS
BEGIN
		
	UPDATE [{databaseOwner}].[{objectQualifier}User] SET Points = Points + @Points WHERE UserID = @UserID
END

GO

create procedure [{databaseOwner}].[{objectQualifier}user_adminsave]
(@BoardID int,@UserID int,@Name nvarchar(255),@DisplayName nvarchar(255), @Email nvarchar(50),@Flags int,@RankID int) as
begin
		
	update [{databaseOwner}].[{objectQualifier}User] set
		Name = @Name,
		DisplayName = @DisplayName,
		Email = @Email,
		RankID = @RankID,
		Flags = @Flags
	where UserID = @UserID
	select UserID = @UserID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_approve](@UserID int) as
begin
		
	declare @CheckEmailID int
	declare @Email nvarchar(50)

	select 
		@CheckEmailID = CheckEmailID,
		@Email = Email
	from
		[{databaseOwner}].[{objectQualifier}CheckEmail]
	where
		UserID = @UserID

	-- Update new user email
	update [{databaseOwner}].[{objectQualifier}User] set Email = @Email, Flags = Flags | 2 where UserID = @UserID
	delete [{databaseOwner}].[{objectQualifier}CheckEmail] where CheckEmailID = @CheckEmailID
	select convert(bit,1)
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}user_approveall](@BoardID int) as
begin
		
	DECLARE userslist CURSOR FOR 
		SELECT UserID FROM [{databaseOwner}].[{objectQualifier}User] WHERE BoardID=@BoardID AND (Flags & 2)=0
		FOR READ ONLY


	OPEN userslist

	DECLARE @UserID int

	FETCH userslist INTO @UserID

	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC [{databaseOwner}].[{objectQualifier}user_approve] @UserID
		FETCH userslist INTO @UserID		
	END

	CLOSE userslist

end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_aspnet](@BoardID int,@UserName nvarchar(255),@DisplayName nvarchar(255) = null,@Email nvarchar(255),@ProviderUserKey nvarchar(64),@IsApproved bit) as
BEGIN
		SET NOCOUNT ON

	DECLARE @UserID int, @RankID int, @approvedFlag int

	SET @approvedFlag = 0;
	IF (@IsApproved = 1) SET @approvedFlag = 2;	
	
	IF EXISTS(SELECT 1 FROM [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID and ([ProviderUserKey]=@ProviderUserKey OR [Name] = @UserName))
	BEGIN
		SELECT TOP 1 @UserID = UserID FROM [{databaseOwner}].[{objectQualifier}User] WHERE [BoardID]=@BoardID and ([ProviderUserKey]=@ProviderUserKey OR [Name] = @UserName)
		
		IF (@DisplayName IS NULL) 
		BEGIN
			SELECT TOP 1 @DisplayName = DisplayName FROM [{databaseOwner}].[{objectQualifier}User] WHERE UserId = @UserID
		END

		UPDATE [{databaseOwner}].[{objectQualifier}User] SET 
			[Name] = @UserName,
			DisplayName = @DisplayName,
			Email = @Email,
			[ProviderUserKey] = @ProviderUserKey,
			Flags = Flags | @approvedFlag
		WHERE
			UserID = @UserID
	END ELSE
	BEGIN
		SELECT @RankID = RankID from [{databaseOwner}].[{objectQualifier}Rank] where (Flags & 1)<>0 and BoardID=@BoardID
		
		IF (@DisplayName IS NULL) 
		BEGIN
			SET @DisplayName = @UserName
		END		

		INSERT INTO [{databaseOwner}].[{objectQualifier}User](BoardID,RankID,[Name],DisplayName,Password,Email,Joined,LastVisit,NumPosts,TimeZone,Flags,ProviderUserKey) 
		VALUES(@BoardID,@RankID,@UserName,@DisplayName,'-',@Email,GETUTCDATE() ,GETUTCDATE() ,0,0,@approvedFlag,@ProviderUserKey)
	
		SET @UserID = SCOPE_IDENTITY()	
	END
	
	SELECT UserID=@UserID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_migrate]
(
	@UserID int,
	@ProviderUserKey nvarchar(64),
	@UpdateProvider bit = 0
)
AS
BEGIN
	
	DECLARE @Password nvarchar(255), @IsApproved bit, @LastActivity datetime, @Joined datetime
	
	UPDATE [{databaseOwner}].[{objectQualifier}User] SET ProviderUserKey = @ProviderUserKey where UserID = @UserID

	IF (@UpdateProvider = 1)
	BEGIN
		SELECT
			@Password = [Password],
			@IsApproved = (CASE (Flags & 2) WHEN 2 THEN 1 ELSE 0 END),
			@LastActivity = LastVisit,
			@Joined = Joined
		FROM
			[{databaseOwner}].[{objectQualifier}User]
		WHERE
			UserID = @UserID
		
		UPDATE
			[{databaseOwner}].[{objectQualifier}prov_Membership]
		SET
			[Password] = @Password,
			PasswordFormat = '1',
			LastActivity = @LastActivity,
			IsApproved = @IsApproved,
			Joined = @Joined
		WHERE
			UserID = @ProviderUserKey
	END
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_avatarimage]
(
	@UserID int
)
AS
BEGIN
	
	SELECT
		UserID,
		AvatarImage,
		AvatarImageType
	FROM
		[{databaseOwner}].[{objectQualifier}User]
	WHERE
		UserID = @UserID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_changepassword](@UserID int,@OldPassword nvarchar(32),@NewPassword nvarchar(32)) as
begin
	
	declare @CurrentOld nvarchar(32)
	select @CurrentOld = Password from [{databaseOwner}].[{objectQualifier}User] where UserID = @UserID
	if @CurrentOld<>@OldPassword begin
		select Success = convert(bit,0)
		return
	end
	update [{databaseOwner}].[{objectQualifier}User] set Password = @NewPassword where UserID = @UserID
	select Success = convert(bit,1)
end
GO

CREATE PROC [{databaseOwner}].[{objectQualifier}user_pmcount]
	(@UserID int) 
AS
BEGIN
		DECLARE @CountIn int	
		DECLARE @CountOut int
		DECLARE @CountArchivedIn int		
		DECLARE @plimit1 int        
		DECLARE @pcount int
		
	  set @plimit1 = (SELECT TOP 1 (c.PMLimit) FROM [{databaseOwner}].[{objectQualifier}User] a 
						JOIN [{databaseOwner}].[{objectQualifier}UserGroup] b
						  ON a.UserID = b.UserID
							JOIN [{databaseOwner}].[{objectQualifier}Group] c                         
							  ON b.GroupID = c.GroupID WHERE a.UserID = @UserID ORDER BY c.PMLimit DESC)
	  set @pcount = (SELECT TOP 1 c.PMLimit FROM [{databaseOwner}].[{objectQualifier}Rank] c 
						JOIN [{databaseOwner}].[{objectQualifier}User] d
						   ON c.RankID = d.RankID WHERE d.UserID = @UserID ORDER BY c.PMLimit DESC)
	  if (@plimit1 > @pcount) 
	  begin
	  set @pcount = @plimit1      
	  end 
	  
	-- get count of pm's in user's sent items
	
	SELECT 
		@CountOut=COUNT(*) 
	FROM 
		[{databaseOwner}].[{objectQualifier}UserPMessage] a
	INNER JOIN [{databaseOwner}].[{objectQualifier}PMessage] b ON a.PMessageID=b.PMessageID
	WHERE 
		(a.Flags & 2)<>0 AND 
		b.FromUserID = @UserID
	-- get count of pm's in user's  received items
	SELECT 
		@CountIn=COUNT(*) 
	FROM 
		[{databaseOwner}].[{objectQualifier}PMessageView] a
		WHERE
		a.IsDeleted = 0  AND a.IsArchived=0  AND
		a.ToUserID = @UserID
	
	SELECT 
		@CountArchivedIn=COUNT(*) 
	FROM 
		[{databaseOwner}].[{objectQualifier}PMessageView] a
		WHERE
		a.IsArchived <>0 AND
		a.ToUserID = @UserID

	-- return all pm data
	SELECT 
		NumberIn = @CountIn,
		NumberOut =  @CountOut,
		NumberTotal = @CountIn + @CountOut + @CountArchivedIn,
		NumberArchived =@CountArchivedIn,
		NumberAllowed = @pcount
			

END
GO

create procedure [{databaseOwner}].[{objectQualifier}user_delete](@UserID int) as
begin
	
	declare @GuestUserID	int
	declare @UserName		nvarchar(255)
	declare @GuestCount		int

	select @UserName = Name from [{databaseOwner}].[{objectQualifier}User] where UserID=@UserID

	select top 1
		@GuestUserID = a.UserID
	from
		[{databaseOwner}].[{objectQualifier}User] a
		inner join [{databaseOwner}].[{objectQualifier}UserGroup] b on b.UserID = a.UserID
		inner join [{databaseOwner}].[{objectQualifier}Group] c on b.GroupID = c.GroupID
	where
		(c.Flags & 2)<>0

	select 
		@GuestCount = count(1) 
	from 
		[{databaseOwner}].[{objectQualifier}UserGroup] a
		join [{databaseOwner}].[{objectQualifier}Group] b on b.GroupID=a.GroupID
	where
		(b.Flags & 2)<>0

	if @GuestUserID=@UserID and @GuestCount=1 begin
		return
	end

	update [{databaseOwner}].[{objectQualifier}Message] set UserName=@UserName,UserID=@GuestUserID where UserID=@UserID
	update [{databaseOwner}].[{objectQualifier}Topic] set UserName=@UserName,UserID=@GuestUserID where UserID=@UserID
	update [{databaseOwner}].[{objectQualifier}Topic] set LastUserName=@UserName,LastUserID=@GuestUserID where LastUserID=@UserID
	update [{databaseOwner}].[{objectQualifier}Forum] set LastUserName=@UserName,LastUserID=@GuestUserID where LastUserID=@UserID

	delete from [{databaseOwner}].[{objectQualifier}Active] where UserID=@UserID
	delete from [{databaseOwner}].[{objectQualifier}EventLog] where UserID=@UserID	
	delete from [{databaseOwner}].[{objectQualifier}UserPMessage] where UserID=@UserID
	delete from [{databaseOwner}].[{objectQualifier}PMessage] where FromUserID=@UserID AND PMessageID NOT IN (select PMessageID FROM [{databaseOwner}].[{objectQualifier}PMessage])
	-- Delete all the thanks entries associated with this UserID.
	delete from [{databaseOwner}].[{objectQualifier}Thanks] where ThanksFromUserID=@UserID OR ThanksToUserID=@UserID
	-- Delete all the FavoriteTopic entries associated with this UserID.
	delete from [{databaseOwner}].[{objectQualifier}FavoriteTopic] where UserID=@UserID
	-- Delete all the Buddy relations between this user and other users.
	delete from [{databaseOwner}].[{objectQualifier}Buddy] where FromUserID=@UserID   
	delete from [{databaseOwner}].[{objectQualifier}Buddy] where ToUserID=@UserID	 
	-- set messages as from guest so the User can be deleted
	update [{databaseOwner}].[{objectQualifier}PMessage] SET FromUserID = @GuestUserID WHERE FromUserID = @UserID
	delete from [{databaseOwner}].[{objectQualifier}CheckEmail] where UserID = @UserID
	delete from [{databaseOwner}].[{objectQualifier}WatchTopic] where UserID = @UserID
	delete from [{databaseOwner}].[{objectQualifier}WatchForum] where UserID = @UserID
	delete from [{databaseOwner}].[{objectQualifier}UserGroup] where UserID = @UserID
	-- ABOT CHANGED
	-- Delete UserForums entries Too 
	delete from [{databaseOwner}].[{objectQualifier}UserForum] where UserID = @UserID
	delete from [{databaseOwner}].[{objectQualifier}IgnoreUser] where UserID = @UserID OR IgnoredUserID = @UserID
	--END ABOT CHANGED 09.04.2004
	delete from [{databaseOwner}].[{objectQualifier}User] where UserID = @UserID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}user_deleteavatar](@UserID int) as begin
	
	UPDATE
		[{databaseOwner}].[{objectQualifier}User]
	SET
		AvatarImage = null,
		Avatar = null,
		AvatarImageType = null
	WHERE
		UserID = @UserID
END
GO

create procedure [{databaseOwner}].[{objectQualifier}user_deleteold](@BoardID int, @Days int) as
begin
	
	declare @Since datetime

	set @Since = GETUTCDATE() 

	delete from [{databaseOwner}].[{objectQualifier}EventLog]  where UserID in(select UserID from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID and [{databaseOwner}].[{objectQualifier}bitset](Flags,2)=0 and datediff(day,Joined,@Since)>@Days)
	delete from [{databaseOwner}].[{objectQualifier}CheckEmail] where UserID in(select UserID from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID and [{databaseOwner}].[{objectQualifier}bitset](Flags,2)=0 and datediff(day,Joined,@Since)>@Days)
	delete from [{databaseOwner}].[{objectQualifier}UserGroup] where UserID in(select UserID from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID and [{databaseOwner}].[{objectQualifier}bitset](Flags,2)=0 and datediff(day,Joined,@Since)>@Days)
	delete from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID and [{databaseOwner}].[{objectQualifier}bitset](Flags,2)=0 and datediff(day,Joined,@Since)>@Days
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_emails](@BoardID int,@GroupID int=null) as
begin
	
	if @GroupID = 0 set @GroupID = null
	if @GroupID is null
		select 
			a.Email 
		from 
			[{databaseOwner}].[{objectQualifier}User] a
		where 
			a.Email is not null and 
			a.BoardID = @BoardID and
			a.Email is not null and 
			a.Email<>''
	else
		select 
			a.Email 
		from 
			[{databaseOwner}].[{objectQualifier}User] a
			join [{databaseOwner}].[{objectQualifier}UserGroup] b on b.UserID=a.UserID
			join [{databaseOwner}].[{objectQualifier}Group] c on c.GroupID=b.GroupID
		where 
			b.GroupID = @GroupID and 
			(c.Flags & 2)=0 and
			a.Email is not null and 
			a.Email<>''
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_find](
	@BoardID int,
	@Filter bit,
	@UserName nvarchar(255)=null,
	@Email nvarchar(255)=null,
	@DisplayName nvarchar(255)=null,
	@NotificationType int = null,
	@DailyDigest bit = null
)
AS
begin
	
	if @Filter<>0
	begin
		if @UserName is not null
			set @UserName = '%' + @UserName + '%'
			
		if @DisplayName is not null
			set @DisplayName = '%' + @DisplayName + '%'			

		select 
			a.*,
			IsGuest = (select count(1) from [{databaseOwner}].[{objectQualifier}UserGroup] x join [{databaseOwner}].[{objectQualifier}Group] y on x.GroupID=y.GroupID where x.UserID=a.UserID and (y.Flags & 2)<>0),
			IsAdmin = (select count(1) from [{databaseOwner}].[{objectQualifier}UserGroup] x join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 1)<>0)
		from 
			[{databaseOwner}].[{objectQualifier}User] a
		where 
			a.BoardID=@BoardID and
			((@UserName is not null and a.Name like @UserName) or
			(@Email is not null and Email like @Email) or
			(@DisplayName is not null and a.DisplayName like @DisplayName) or
			(@NotificationType is not null and a.NotificationType = @NotificationType) or
			(@DailyDigest is not null and a.DailyDigest = @DailyDigest))
		order by
			a.Name
	end else
	begin
		select 
			a.*,
			IsGuest = (select count(1) from [{databaseOwner}].[{objectQualifier}UserGroup] x join [{databaseOwner}].[{objectQualifier}Group] y on x.GroupID=y.GroupID where x.UserID=a.UserID and (y.Flags & 2)<>0),
			IsAdmin = (select count(1) from [{databaseOwner}].[{objectQualifier}UserGroup] x join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 1)<>0)
		from 
			[{databaseOwner}].[{objectQualifier}User] a
		where 
			a.BoardID=@BoardID and
			((@UserName is not null and a.Name like @UserName) or
			(@Email is not null and Email like @Email) or
			(@DisplayName is not null and a.DisplayName like @DisplayName) or
			(@NotificationType is not null and a.NotificationType = @NotificationType) or
			(@DailyDigest is not null and a.DailyDigest = @DailyDigest))
	end
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_getpoints] (@UserID int) AS
BEGIN
	
	SELECT Points FROM [{databaseOwner}].[{objectQualifier}User] WHERE UserID = @UserID
END
GO

create procedure [{databaseOwner}].[{objectQualifier}user_getsignature](@UserID int) as
begin
	
	select Signature from [{databaseOwner}].[{objectQualifier}User] where UserID = @UserID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_guest]
(
	@BoardID int
)
as
begin
	
	select top 1
		a.UserID
	from
		[{databaseOwner}].[{objectQualifier}User] a
		inner join [{databaseOwner}].[{objectQualifier}UserGroup] b on b.UserID = a.UserID
		inner join [{databaseOwner}].[{objectQualifier}Group] c on b.GroupID = c.GroupID
	where
		a.BoardID = @BoardID and
		(c.Flags & 2)<>0
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_list](@BoardID int,@UserID int=null,@Approved bit=null,@GroupID int=null,@RankID int=null,@StyledNicks bit = null) as
begin	
	if @UserID is not null
		 select 
			a.*,
			a.NumPosts,
			CultureUser = a.Culture,			
			b.RankID,						
			RankName = b.Name,
			Style = case(@StyledNicks)
			when 1 then  ISNULL(( SELECT TOP 1 f.Style FROM [{databaseOwner}].[{objectQualifier}UserGroup] e 
			join [{databaseOwner}].[{objectQualifier}Group] f on f.GroupID=e.GroupID WHERE e.UserID=a.UserID AND LEN(f.Style) > 2 ORDER BY f.SortOrder), b.Style)  
			else ''	 end, 
			NumDays = datediff(d,a.Joined,GETUTCDATE() )+1,
			NumPostsForum = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where (x.Flags & 24)=16),
			HasAvatarImage = (select count(1) from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=a.UserID and AvatarImage is not null),
			IsAdmin	= IsNull(c.IsAdmin,0),
			IsGuest	= IsNull(a.Flags & 4,0),
			IsHostAdmin	= IsNull(a.Flags & 1,0),
			IsForumModerator	= IsNull(c.IsForumModerator,0),
			IsModerator		= IsNull(c.IsModerator,0)
		from 
			[{databaseOwner}].[{objectQualifier}User] a
			join [{databaseOwner}].[{objectQualifier}Rank] b on b.RankID=a.RankID			
			left join [{databaseOwner}].[{objectQualifier}vaccess] c on c.UserID=a.UserID
		where 
			a.UserID = @UserID and
			a.BoardID = @BoardID and
			IsNull(c.ForumID,0) = 0 and
			(@Approved is null or (@Approved=0 and (a.Flags & 2)=0) or (@Approved=1 and (a.Flags & 2)=2))
		order by 
			a.Name 
	else if @GroupID is null and @RankID is null
		select 
			a.*,
			a.NumPosts,
			CultureUser = a.Culture,	
			Style = case(@StyledNicks)
			when 1 then  ISNULL(( SELECT TOP 1 f.Style FROM [{databaseOwner}].[{objectQualifier}UserGroup] e 
			join [{databaseOwner}].[{objectQualifier}Group] f on f.GroupID=e.GroupID WHERE e.UserID=a.UserID AND LEN(f.Style) > 2 ORDER BY f.SortOrder), b.Style)  
			else ''	 end, 	
			IsAdmin = (select count(1) from [{databaseOwner}].[{objectQualifier}UserGroup] x join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 1)<>0),
			IsGuest	= IsNull(a.Flags & 4,0),
			IsHostAdmin	= IsNull(a.Flags & 1,0),
			b.RankID,
			RankName = b.Name
		from 
			[{databaseOwner}].[{objectQualifier}User] a
			join [{databaseOwner}].[{objectQualifier}Rank] b on b.RankID=a.RankID			
		where 
			a.BoardID = @BoardID and
			(@Approved is null or (@Approved=0 and (a.Flags & 2)=0) or (@Approved=1 and (a.Flags & 2)=2))
		order by 
			a.Name
	else
		select 
			a.*,
			a.NumPosts,
			CultureUser = a.Culture,
			IsAdmin = (select count(1) from [{databaseOwner}].[{objectQualifier}UserGroup] x join [{databaseOwner}].[{objectQualifier}Group] y on y.GroupID=x.GroupID where x.UserID=a.UserID and (y.Flags & 1)<>0),
			IsGuest	= IsNull(a.Flags & 4,0),
			IsHostAdmin	= IsNull(a.Flags & 1,0),
			b.RankID,
			RankName = b.Name,
			Style = case(@StyledNicks)
			when 1 then  ISNULL(( SELECT TOP 1 f.Style FROM [{databaseOwner}].[{objectQualifier}UserGroup] e 
			join [{databaseOwner}].[{objectQualifier}Group] f on f.GroupID=e.GroupID WHERE e.UserID=a.UserID AND LEN(f.Style) > 2 ORDER BY f.SortOrder), b.Style)  
			else ''	 end 
		from 
			[{databaseOwner}].[{objectQualifier}User] a
			join [{databaseOwner}].[{objectQualifier}Rank] b on b.RankID=a.RankID			
		where 
			a.BoardID = @BoardID and
			(@Approved is null or (@Approved=0 and (a.Flags & 2)=0) or (@Approved=1 and (a.Flags & 2)=2)) and
			(@GroupID is null or exists(select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] x where x.UserID=a.UserID and x.GroupID=@GroupID)) and
			(@RankID is null or a.RankID=@RankID)
		order by 
			a.Name
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_login](@BoardID int,@Name nvarchar(255),@Password nvarchar(32)) as
begin
	
	declare @UserID int

	-- Try correct board first
	if exists(select UserID from [{databaseOwner}].[{objectQualifier}User] where Name=@Name and Password=@Password and BoardID=@BoardID and (Flags & 2)=2)
	begin
		select UserID from [{databaseOwner}].[{objectQualifier}User] where Name=@Name and Password=@Password and BoardID=@BoardID and (Flags & 2)=2
		return
	end

	if not exists(select UserID from [{databaseOwner}].[{objectQualifier}User] where Name=@Name and Password=@Password and (BoardID=@BoardID or (Flags & 3)=3))
		set @UserID=null
	else
		select 
			@UserID=UserID 
		from 
			[{databaseOwner}].[{objectQualifier}User]
		where 
			Name=@Name and 
			[Password]=@Password and 
			(BoardID=@BoardID or (Flags & 1)=1) and
			(Flags & 2)=2

	select @UserID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_nntp](@BoardID int,@UserName nvarchar(255),@Email nvarchar(50),@TimeZone int) as
begin	
	
	declare @UserID int

	set @UserName = @UserName + ' (NNTP)'

	select
		@UserID=UserID
	from
		[{databaseOwner}].[{objectQualifier}User]
	where
		BoardID=@BoardID and
		Name=@UserName

	if @@ROWCOUNT<1
	begin
		exec [{databaseOwner}].[{objectQualifier}user_save] null,@BoardID,@UserName,@UserName,@Email,@TimeZone,null,null,null,null, 1, null, null, null, 0, 0
		-- The next one is not safe, but this procedure is only used for testing
		select @UserID=max(UserID) from [{databaseOwner}].[{objectQualifier}User]
	end

	select UserID=@UserID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_recoverpassword](@BoardID int,@UserName nvarchar(255),@Email nvarchar(50)) as
begin
	
	declare @UserID int
	select @UserID = UserID from [{databaseOwner}].[{objectQualifier}User] where BoardID = @BoardID and Name = @UserName and Email = @Email
	if @UserID is null begin
		select UserID = convert(int,null)
		return
	end else
	begin
		select UserID = @UserID
	end
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_removepoints] (@UserID int,@Points int) AS
BEGIN
	
	UPDATE [{databaseOwner}].[{objectQualifier}User] SET Points = Points - @Points WHERE UserID = @UserID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_removepointsbytopicid] (@TopicID int,@Points int) AS
BEGIN
	
	declare @UserID int
	select @UserID = UserID from [{databaseOwner}].[{objectQualifier}Topic] where TopicID = @TopicID
	update [{databaseOwner}].[{objectQualifier}User] SET points = points - @Points WHERE userID = @UserID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_resetpoints] AS
BEGIN
	
	UPDATE [{databaseOwner}].[{objectQualifier}User] SET Points = NumPosts * 3
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_savenotification](
	@UserID				int,
	@PMNotification		bit = null,
	@AutoWatchTopics    bit = null,
	@NotificationType	int = null,
	@DailyDigest		bit = null
)
AS
BEGIN

		UPDATE
			[{databaseOwner}].[{objectQualifier}User]
		SET
			PMNotification = (CASE WHEN (@PMNotification is not null) THEN  @PMNotification ELSE PMNotification END),
			AutoWatchTopics = (CASE WHEN (@AutoWatchTopics is not null) THEN  @AutoWatchTopics ELSE AutoWatchTopics END),
			NotificationType =  (CASE WHEN (@NotificationType is not null) THEN  @NotificationType ELSE NotificationType END),
			DailyDigest = (CASE WHEN (@DailyDigest is not null) THEN  @DailyDigest ELSE DailyDigest END)
		WHERE
			UserID = @UserID
END
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}user_save](
	@UserID				int,
	@BoardID			int,
	@UserName			nvarchar(255) = null,
	@DisplayName		nvarchar(255) = null,
	@Email				nvarchar(255) = null,
	@TimeZone			int,
	@LanguageFile		nvarchar(50) = null,
	@Culture		    char(5) = null,
	@ThemeFile			nvarchar(50) = null,
	@OverrideDefaultTheme	bit = null,
	@Approved			bit = null,
	@PMNotification		bit = null,
	@AutoWatchTopics    bit = null,
	@NotificationType	int = null,
	@ProviderUserKey	nvarchar(64) = null,
	@DSTUser            bit = null,
	@HideUser           bit = null)
AS
begin
	
	declare @RankID int
	declare @Flags int	 		
		
	if @DSTUser is null SET @DSTUser = 0
	if @HideUser is null SET @HideUser = 0
	if @PMNotification is null SET @PMNotification = 1
	if @AutoWatchTopics is null SET @AutoWatchTopics = 0
	if @OverrideDefaultTheme is null SET @OverrideDefaultTheme=0

	if @UserID is null or @UserID<1 begin
		set @Flags = 0	
		if @Approved<>0 set @Flags = @Flags | 2	
		if @Email = '' set @Email = null
		
		select @RankID = RankID from [{databaseOwner}].[{objectQualifier}Rank] where (Flags & 1)<>0 and BoardID=@BoardID

		insert into [{databaseOwner}].[{objectQualifier}User](BoardID,RankID,[Name],DisplayName,Password,Email,Joined,LastVisit,NumPosts,TimeZone,Flags,PMNotification,AutoWatchTopics,NotificationType,ProviderUserKey) 
		values(@BoardID,@RankID,@UserName,@DisplayName,'-',@Email,GETUTCDATE() ,GETUTCDATE() ,0,@TimeZone, @Flags,@PMNotification,@AutoWatchTopics,@NotificationType,@ProviderUserKey)		
	
		set @UserID = SCOPE_IDENTITY()

		insert into [{databaseOwner}].[{objectQualifier}UserGroup](UserID,GroupID) select @UserID,GroupID from [{databaseOwner}].[{objectQualifier}Group] where BoardID=@BoardID and (Flags & 4)<>0
	end
	else begin
		set @Flags = (SELECT Flags FROM [{databaseOwner}].[{objectQualifier}User] where UserID = @UserID)	
		
		IF ((@DSTUser<>0) AND (@Flags & 32) <> 32)		
		SET @Flags = @Flags | 32
		ELSE IF ((@DSTUser=0) AND (@Flags & 32) = 32)
		SET @Flags = @Flags ^ 32
			
		IF ((@HideUser<>0) AND ((@Flags & 16) <> 16)) 
		SET @Flags = @Flags | 16 
		ELSE IF ((@HideUser=0) AND ((@Flags & 16) = 16)) 
		SET @Flags = @Flags ^ 16
			
		update [{databaseOwner}].[{objectQualifier}User] set
			TimeZone = @TimeZone,
			LanguageFile = @LanguageFile,
			ThemeFile = @ThemeFile,
			Culture = @Culture,
			OverrideDefaultThemes = @OverrideDefaultTheme,
			PMNotification = (CASE WHEN (@PMNotification is not null) THEN  @PMNotification ELSE PMNotification END),
			AutoWatchTopics = (CASE WHEN (@AutoWatchTopics is not null) THEN  @AutoWatchTopics ELSE AutoWatchTopics END),
			NotificationType =  (CASE WHEN (@NotificationType is not null) THEN  @NotificationType ELSE NotificationType END),
			Flags = (CASE WHEN @Flags<>Flags THEN  @Flags ELSE Flags END),
			DisplayName = (CASE WHEN (@DisplayName is not null) THEN  @DisplayName ELSE DisplayName END),
			Email = (CASE WHEN (@Email is not null) THEN  @Email ELSE Email END) 
		where UserID = @UserID		
		
	end
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}user_saveavatar]
(
	@UserID int,
	@Avatar nvarchar(255) = NULL,
	@AvatarImage image = NULL,
	@AvatarImageType nvarchar(50) = NULL
)
AS
BEGIN
	
	IF @Avatar IS NOT NULL 
	BEGIN
		UPDATE
			[{databaseOwner}].[{objectQualifier}User]
		SET
			Avatar = @Avatar,
			AvatarImage = null,
			AvatarImageType = null
		WHERE
			UserID = @UserID
	END
	ELSE IF @AvatarImage IS NOT NULL 
	BEGIN
		UPDATE
			[{databaseOwner}].[{objectQualifier}User]
		SET
			AvatarImage = @AvatarImage,
			AvatarImageType = @AvatarImageType,
			Avatar = null
		WHERE
			UserID = @UserID
	END
END

GO

create procedure [{databaseOwner}].[{objectQualifier}user_savepassword](@UserID int,@Password nvarchar(32)) as
begin
	
	update [{databaseOwner}].[{objectQualifier}User] set Password = @Password where UserID = @UserID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_savesignature](@UserID int,@Signature ntext) as
begin
	
	update [{databaseOwner}].[{objectQualifier}User] set Signature = @Signature where UserID = @UserID
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_setpoints] (@UserID int,@Points int) AS
BEGIN
	
	UPDATE [{databaseOwner}].[{objectQualifier}User] SET Points = @Points WHERE UserID = @UserID
END
GO

create procedure [{databaseOwner}].[{objectQualifier}user_setrole](@BoardID int,@ProviderUserKey nvarchar(64),@Role nvarchar(50)) as
begin
	
	declare @UserID int, @GroupID int
	
	select @UserID=UserID from [{databaseOwner}].[{objectQualifier}User] where BoardID=@BoardID and ProviderUserKey=@ProviderUserKey

	if @Role is null
	begin
		delete from [{databaseOwner}].[{objectQualifier}UserGroup] where UserID=@UserID
	end else
	begin
		if not exists(select 1 from [{databaseOwner}].[{objectQualifier}Group] where BoardID=@BoardID and Name=@Role)
		begin
			insert into [{databaseOwner}].[{objectQualifier}Group](Name,BoardID,Flags)
			values(@Role,@BoardID,0);
			set @GroupID = SCOPE_IDENTITY()

			insert into [{databaseOwner}].[{objectQualifier}ForumAccess](GroupID,ForumID,AccessMaskID)
			select
				@GroupID,
				a.ForumID,
				min(a.AccessMaskID)
			from
				[{databaseOwner}].[{objectQualifier}ForumAccess] a
				join [{databaseOwner}].[{objectQualifier}Group] b on b.GroupID=a.GroupID
			where
				b.BoardID=@BoardID and
				(b.Flags & 4)=4
			group by
				a.ForumID
		end else
		begin
			select @GroupID = GroupID from [{databaseOwner}].[{objectQualifier}Group] where BoardID=@BoardID and Name=@Role
		end
		-- user already can be in the group even if Role isn't null, an extra check is required 
		if not exists(select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] where UserID=@UserID and GroupID=@GroupID)
		begin
		insert into [{databaseOwner}].[{objectQualifier}UserGroup](UserID,GroupID) values(@UserID,@GroupID)
		end
	end
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_suspend](@UserID int,@Suspend datetime=null) as
begin
	
	update [{databaseOwner}].[{objectQualifier}User] set Suspended = @Suspend where UserID=@UserID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}user_upgrade](@UserID int) as
begin
	
	declare @RankID			int
	declare @Flags			int
	declare @MinPosts		int
	declare @NumPosts		int
	declare @BoardId		int
	declare @RankBoardID	int

	-- Get user and rank information
	select
		@RankID = b.RankID,
		@Flags = b.Flags,
		@MinPosts = b.MinPosts,
		@NumPosts = a.NumPosts,
		@BoardId = a.BoardId		
	from
		[{databaseOwner}].[{objectQualifier}User] a
		inner join [{databaseOwner}].[{objectQualifier}Rank] b on b.RankID = a.RankID
	where
		a.UserID = @UserID
	
	-- If user isn't member of a ladder rank, exit
	if (@Flags & 2) = 0 return

	-- retrieve board current user's rank beling to	
	select @RankBoardId = BoardID
	from   [{databaseOwner}].[{objectQualifier}Rank]
	where  RankID = @RankID

	-- does user have rank from his board?
	IF @RankBoardId <> @BoardId begin
		-- get highest rank user can get
		select top 1
			   @RankID = RankID
		from   [{databaseOwner}].[{objectQualifier}Rank]
		where  BoardId = @BoardId
			   and (Flags & 2) = 2
			   and MinPosts <= @NumPosts
		order by
			   MinPosts desc
	end
	else begin
		-- See if user got enough posts for next ladder group
		select top 1
			@RankID = RankID
		from
			[{databaseOwner}].[{objectQualifier}Rank]
		where
			BoardId = @BoardId and
			(Flags & 2) = 2 and
			MinPosts <= @NumPosts and
			MinPosts > @MinPosts
		order by
			MinPosts
	end

	if @@ROWCOUNT=1
		update [{databaseOwner}].[{objectQualifier}User] set RankID = @RankID where UserID = @UserID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}userforum_delete](@UserID int,@ForumID int) as
begin
	
	delete from [{databaseOwner}].[{objectQualifier}UserForum] where UserID=@UserID and ForumID=@ForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}userforum_list](@UserID int=null,@ForumID int=null) as 
begin
	
	select 
		a.*,
		b.AccessMaskID,
		b.Accepted,
		Access = c.Name
	from
		[{databaseOwner}].[{objectQualifier}User] a
		join [{databaseOwner}].[{objectQualifier}UserForum] b on b.UserID=a.UserID
		join [{databaseOwner}].[{objectQualifier}AccessMask] c on c.AccessMaskID=b.AccessMaskID
	where
		(@UserID is null or a.UserID=@UserID) and
		(@ForumID is null or b.ForumID=@ForumID)
	order by
		a.Name	
end
GO

create procedure [{databaseOwner}].[{objectQualifier}userforum_save](@UserID int,@ForumID int,@AccessMaskID int) as
begin
	
	if exists(select 1 from [{databaseOwner}].[{objectQualifier}UserForum] where UserID=@UserID and ForumID=@ForumID)
		update [{databaseOwner}].[{objectQualifier}UserForum] set AccessMaskID=@AccessMaskID where UserID=@UserID and ForumID=@ForumID
	else
		insert into [{databaseOwner}].[{objectQualifier}UserForum](UserID,ForumID,AccessMaskID,Invited,Accepted) values(@UserID,@ForumID,@AccessMaskID,GETUTCDATE() ,1)
end
GO

create procedure [{databaseOwner}].[{objectQualifier}usergroup_list](@UserID int) as begin
	
	select 
		b.GroupID,
		b.Name,
		b.Style
	from
		[{databaseOwner}].[{objectQualifier}UserGroup] a
		join [{databaseOwner}].[{objectQualifier}Group] b on b.GroupID=a.GroupID
	where
		a.UserID = @UserID
	order by
		b.Name
end
GO

create procedure [{databaseOwner}].[{objectQualifier}usergroup_save](@UserID int,@GroupID int,@Member bit) as
begin
	
	if @Member=0
		delete from [{databaseOwner}].[{objectQualifier}UserGroup] where UserID=@UserID and GroupID=@GroupID
	else
		insert into [{databaseOwner}].[{objectQualifier}UserGroup](UserID,GroupID)
		select @UserID,@GroupID
		where not exists(select 1 from [{databaseOwner}].[{objectQualifier}UserGroup] where UserID=@UserID and GroupID=@GroupID)
end
GO

create procedure [{databaseOwner}].[{objectQualifier}userpmessage_delete](@UserPMessageID int) as
begin
	
	delete from [{databaseOwner}].[{objectQualifier}UserPMessage] where UserPMessageID=@UserPMessageID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}userpmessage_list](@UserPMessageID int) as
begin
	
	SELECT
		a.*,
		FromUser = b.Name,
		ToUserID = c.UserID,
		ToUser = c.Name,
		d.IsRead,
		d.UserPMessageID
	FROM
		[{databaseOwner}].[{objectQualifier}PMessage] a
		INNER JOIN [{databaseOwner}].[{objectQualifier}UserPMessage] d ON d.PMessageID = a.PMessageID
		INNER JOIN [{databaseOwner}].[{objectQualifier}User] b ON b.UserID = a.FromUserID
		inner join [{databaseOwner}].[{objectQualifier}User] c ON c.UserID = d.UserID
	WHERE
		d.UserPMessageID = @UserPMessageID
	AND
		d.IsDeleted=0
end
GO

create procedure [{databaseOwner}].[{objectQualifier}watchforum_add](@UserID int,@ForumID int) as
begin
	
	insert into [{databaseOwner}].[{objectQualifier}WatchForum](ForumID,UserID,Created)
	select @ForumID, @UserID, GETUTCDATE() 
	where not exists(select 1 from [{databaseOwner}].[{objectQualifier}WatchForum] where ForumID=@ForumID and UserID=@UserID)
end
GO

create procedure [{databaseOwner}].[{objectQualifier}watchforum_check](@UserID int,@ForumID int) as
begin
	
	SELECT WatchForumID FROM [{databaseOwner}].[{objectQualifier}WatchForum] WHERE UserID = @UserID AND ForumID = @ForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}watchforum_delete](@WatchForumID int) as
begin
	
	delete from [{databaseOwner}].[{objectQualifier}WatchForum] where WatchForumID = @WatchForumID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}watchforum_list](@UserID int) as
begin
	
	select
		a.*,
		ForumName = b.Name,
		[Messages] = (select count(1) from [{databaseOwner}].[{objectQualifier}Topic] x join [{databaseOwner}].[{objectQualifier}Message] y on y.TopicID=x.TopicID where x.ForumID=a.ForumID),
		Topics = (select count(1) from [{databaseOwner}].[{objectQualifier}Topic] x where x.ForumID=a.ForumID and x.TopicMovedID is null),
		b.LastPosted,
		b.LastMessageID,
		LastTopicID = (select TopicID from [{databaseOwner}].[{objectQualifier}Message] x where x.MessageID=b.LastMessageID),
		b.LastUserID,
		LastUserName = IsNull(b.LastUserName,(select Name from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=b.LastUserID))
	from
		[{databaseOwner}].[{objectQualifier}WatchForum] a
		inner join [{databaseOwner}].[{objectQualifier}Forum] b on b.ForumID = a.ForumID
	where
		a.UserID = @UserID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}watchtopic_add](@UserID int,@TopicID int) as
begin
	
	insert into [{databaseOwner}].[{objectQualifier}WatchTopic](TopicID,UserID,Created)
	select @TopicID, @UserID, GETUTCDATE() 
	where not exists(select 1 from [{databaseOwner}].[{objectQualifier}WatchTopic] where TopicID=@TopicID and UserID=@UserID)
end
GO

create procedure [{databaseOwner}].[{objectQualifier}watchtopic_check](@UserID int,@TopicID int) as
begin
	
	SELECT WatchTopicID FROM [{databaseOwner}].[{objectQualifier}WatchTopic] WHERE UserID = @UserID AND TopicID = @TopicID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}watchtopic_delete](@WatchTopicID int) as
begin
		delete from [{databaseOwner}].[{objectQualifier}WatchTopic] where WatchTopicID = @WatchTopicID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}watchtopic_list](@UserID int) as
begin
		select
		a.*,
		TopicName = b.Topic,
		Replies = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=b.TopicID),
		b.[Views],
		b.LastPosted,
		b.LastMessageID,
		b.LastUserID,
		LastUserName = IsNull(b.LastUserName,(select Name from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=b.LastUserID))
	from
		[{databaseOwner}].[{objectQualifier}WatchTopic] a
		inner join [{databaseOwner}].[{objectQualifier}Topic] b on b.TopicID = a.TopicID
	where
		a.UserID = @UserID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}message_reply_list](@MessageID int) as
begin
		set nocount on
	select
				a.MessageID,
		a.Posted,
		Subject = c.Topic,
		a.[Message],
		a.UserID,
		a.Flags,
		UserName = IsNull(a.UserName,b.Name),
		b.Signature
	from
		[{databaseOwner}].[{objectQualifier}Message] a
		inner join [{databaseOwner}].[{objectQualifier}User] b on b.UserID = a.UserID
		inner join [{databaseOwner}].[{objectQualifier}Topic] c on c.TopicID = a.TopicID
	where
		(a.Flags & 16)=16 and
		a.ReplyTo = @MessageID



end
GO


CREATE procedure [{databaseOwner}].[{objectQualifier}message_deleteundelete](@MessageID int, @isModeratorChanged bit, @DeleteReason nvarchar(100), @isDeleteAction int) as
begin
	
	declare @TopicID		int
	declare @ForumID		int
	declare @MessageCount	int
	declare @LastMessageID	int
	declare @UserID			int

	-- Find TopicID and ForumID
	select @TopicID=b.TopicID,@ForumID=b.ForumID,@UserID = a.UserID 
	from 
		[{databaseOwner}].[{objectQualifier}Message] a
		inner join [{databaseOwner}].[{objectQualifier}Topic] b on b.TopicID=a.TopicID
	where 
		a.MessageID=@MessageID

	-- Update LastMessageID in Topic and Forum
	update [{databaseOwner}].[{objectQualifier}Topic] set
		LastPosted = null,
		LastMessageID = null,
		LastUserID = null,
		LastUserName = null,
		LastMessageFlags = null
	where LastMessageID = @MessageID

	update [{databaseOwner}].[{objectQualifier}Forum] set
		LastPosted = null,
		LastTopicID = null,
		LastMessageID = null,
		LastUserID = null,
		LastUserName = null
	where LastMessageID = @MessageID

	-- "Delete" message
	update [{databaseOwner}].[{objectQualifier}Message]
	 set IsModeratorChanged = @isModeratorChanged, DeleteReason = @DeleteReason, Flags = Flags ^ 8
	 where MessageID = @MessageID and ((Flags & 8) <> @isDeleteAction*8)
	
	-- update num posts for user now that the delete/undelete status has been toggled...
	UPDATE [{databaseOwner}].[{objectQualifier}User] SET NumPosts = (SELECT count(MessageID) FROM [{databaseOwner}].[{objectQualifier}Message] WHERE UserID = @UserID AND IsDeleted = 0 AND IsApproved = 1) WHERE UserID = @UserID

	-- Delete topic if there are no more messages
	select @MessageCount = count(1) from [{databaseOwner}].[{objectQualifier}Message] where TopicID = @TopicID and (Flags & 8)=0
	if @MessageCount=0 exec [{databaseOwner}].[{objectQualifier}topic_delete] @TopicID
	-- update lastpost
	exec [{databaseOwner}].[{objectQualifier}topic_updatelastpost] @ForumID,@TopicID
	exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @ForumID
	-- update topic numposts
	update [{databaseOwner}].[{objectQualifier}Topic] set
		NumPosts = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and x.IsApproved = 1 and x.IsDeleted = 0 )
	where TopicID = @TopicID
end
GO

create procedure [{databaseOwner}].[{objectQualifier}topic_create_by_message] (
	@MessageID int,
	@ForumID	int,
	@Subject	nvarchar(100)
) as
begin
		
declare		@UserID		int
declare		@Posted		datetime

set @UserID = (select UserID from [{databaseOwner}].[{objectQualifier}message] where MessageID =  @MessageID)
set  @Posted  = (select  posted from [{databaseOwner}].[{objectQualifier}message] where MessageID =  @MessageID)


	declare @TopicID int
	--declare @MessageID int

	if @Posted is null set @Posted = GETUTCDATE() 

	insert into [{databaseOwner}].[{objectQualifier}Topic](ForumID,Topic,UserID,Posted,Views,Priority,PollID,UserName,NumPosts)
	values(@ForumID,@Subject,@UserID,@Posted,0,0,null,null,0)

	set @TopicID = @@IDENTITY
--	exec [{databaseOwner}].[{objectQualifier}message_save] @TopicID,@UserID,@Message,@UserName,@IP,@Posted,null,@Flags,@MessageID output
	select TopicID = @TopicID, MessageID = @MessageID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_move] (@MessageID int, @MoveToTopic int) AS
BEGIN
	DECLARE
	@Position int,
	@ReplyToID int,
	@OldTopicID int,
	@OldForumID int

	
	declare @NewForumID		int
	declare @MessageCount	int
	declare @LastMessageID	int

	-- Find TopicID and ForumID
--	select @OldTopicID=b.TopicID,@ForumID=b.ForumID from [{databaseOwner}].[{objectQualifier}Message] a,{objectQualifier}Topic b where a.MessageID=@MessageID and b.TopicID=a.TopicID

SET 	@NewForumID = (SELECT     ForumID
				FROM         [{databaseOwner}].[{objectQualifier}Topic]
				WHERE     (TopicId = @MoveToTopic))


SET 	@OldTopicID = 	(SELECT     TopicID
				FROM         [{databaseOwner}].[{objectQualifier}Message]
				WHERE     (MessageID = @MessageID))

SET 	@OldForumID = (SELECT     ForumID
				FROM         [{databaseOwner}].[{objectQualifier}Topic]
				WHERE     (TopicId = @OldTopicID))

SET	@ReplyToID = (SELECT     MessageID
			FROM         [{databaseOwner}].[{objectQualifier}Message]
			WHERE     ([Position] = 0) AND (TopicID = @MoveToTopic))

SET	@Position = 	(SELECT     MAX([Position]) + 1 AS Expr1
			FROM         [{databaseOwner}].[{objectQualifier}Message]
			WHERE     (TopicID = @MoveToTopic) and posted < (select posted from [{databaseOwner}].[{objectQualifier}Message] where MessageID = @MessageID ) )

if @Position is null  set @Position = 0

update [{databaseOwner}].[{objectQualifier}Message] set
		Position = Position+1
	 WHERE     (TopicID = @MoveToTopic) and posted > (select posted from [{databaseOwner}].[{objectQualifier}Message] where MessageID = @MessageID)

update [{databaseOwner}].[{objectQualifier}Message] set
		Position = Position-1
	 WHERE     (TopicID = @OldTopicID) and posted > (select posted from [{databaseOwner}].[{objectQualifier}Message] where MessageID = @MessageID)

	


	-- Update LastMessageID in Topic and Forum
	update [{databaseOwner}].[{objectQualifier}Topic] set
		LastPosted = null,
		LastMessageID = null,
		LastUserID = null,
		LastUserName = null,
		LastMessageFlags = null 
	where LastMessageID = @MessageID

	update [{databaseOwner}].[{objectQualifier}Forum] set
		LastPosted = null,
		LastTopicID = null,
		LastMessageID = null,
		LastUserID = null,
		LastUserName = null
	where LastMessageID = @MessageID


UPDATE [{databaseOwner}].[{objectQualifier}Message] SET
	TopicID = @MoveToTopic,
	ReplyTo = @ReplyToID,
	[Position] = @Position
WHERE  MessageID = @MessageID

	-- Delete topic if there are no more messages
	select @MessageCount = count(1) from [{databaseOwner}].[{objectQualifier}Message] where TopicID = @OldTopicID and (Flags & 8)=0
	if @MessageCount=0 exec [{databaseOwner}].[{objectQualifier}topic_delete] @OldTopicID

	-- update lastpost
	exec [{databaseOwner}].[{objectQualifier}topic_updatelastpost] @OldForumID,@OldTopicID
	exec [{databaseOwner}].[{objectQualifier}topic_updatelastpost] @NewForumID,@MoveToTopic

	-- update topic numposts
	update [{databaseOwner}].[{objectQualifier}Topic] set
		NumPosts = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and x.IsApproved = 1 and x.IsDeleted = 0)
	where TopicID = @OldTopicID
	update [{databaseOwner}].[{objectQualifier}Topic] set
		NumPosts = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=[{databaseOwner}].[{objectQualifier}Topic].TopicID and x.IsApproved = 1 and x.IsDeleted = 0)
	where TopicID = @MoveToTopic

	exec [{databaseOwner}].[{objectQualifier}forum_updatelastpost] @NewForumID
	exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @NewForumID
	exec [{databaseOwner}].[{objectQualifier}forum_updatelastpost] @OldForumID
	exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @OldForumID

END
GO

create proc [{databaseOwner}].[{objectQualifier}forum_resync]
	@BoardID int,
	@ForumID int = null
AS
begin
	
	if (@ForumID is null) begin
		declare curForums cursor for
			select 
				a.ForumID
			from
				[{databaseOwner}].[{objectQualifier}Forum] a
				JOIN [{databaseOwner}].[{objectQualifier}Category] b on a.CategoryID=b.CategoryID
				JOIN [{databaseOwner}].[{objectQualifier}Board] c on b.BoardID = c.BoardID  
			where
				c.BoardID=@BoardID

		open curForums
		
		-- cycle through forums
		fetch next from curForums into @ForumID
		while @@FETCH_STATUS = 0
		begin
			--update statistics
			exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @ForumID
			--update last post
			exec [{databaseOwner}].[{objectQualifier}forum_updatelastpost] @ForumID

			fetch next from curForums into @ForumID
		end
		close curForums
		deallocate curForums
	end
	else begin
		--update statistics
		exec [{databaseOwner}].[{objectQualifier}forum_updatestats] @ForumID
		--update last post
		exec [{databaseOwner}].[{objectQualifier}forum_updatelastpost] @ForumID
	end
end
GO

create proc [{databaseOwner}].[{objectQualifier}board_resync]
	@BoardID int = null
as
begin
	
	if (@BoardID is null) begin
		declare curBoards cursor for
			select BoardID from	[{databaseOwner}].[{objectQualifier}Board]

		open curBoards
		
		-- cycle through forums
		fetch next from curBoards into @BoardID
		while @@FETCH_STATUS = 0
		begin
			--resync board forums
			exec [{databaseOwner}].[{objectQualifier}forum_resync] @BoardID

			fetch next from curBoards into @BoardID
		end
		close curBoards
		deallocate curBoards
	end
	else begin
		--resync board forums
		exec [{databaseOwner}].[{objectQualifier}forum_resync] @BoardID
	end
end
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}category_simplelist](
				@StartID INT  = 0,
				@Limit   INT  = 500)
AS
	BEGIN
			
		SET ROWCOUNT  @Limit
		SELECT   c.[CategoryID],
				 c.[Name]
		FROM     [{databaseOwner}].[{objectQualifier}Category] c
		WHERE    c.[CategoryID] >= @StartID
		AND c.[CategoryID] < (@StartID + @Limit)
		ORDER BY c.[CategoryID]
		SET ROWCOUNT  0
	END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}forum_simplelist](
				@StartID INT  = 0,
				@Limit   INT  = 500)
AS
	BEGIN
				SET ARITHABORT ON				
		SET ROWCOUNT  @Limit
		SELECT   f.[ForumID],
				 f.[Name]
		FROM     [{databaseOwner}].[{objectQualifier}Forum] f
		WHERE    f.[ForumID] >= @StartID
		AND f.[ForumID] < (@StartID + @Limit)
		ORDER BY f.[ForumID]
		SET ROWCOUNT  0
	END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_simplelist](
				@StartID INT  = 0,
				@Limit   INT  = 1000)
AS
	BEGIN
				SET ARITHABORT ON				
		SET ROWCOUNT  @Limit
		SELECT   m.[MessageID],
				 m.[TopicID]
		FROM     [{databaseOwner}].[{objectQualifier}Message] m
		WHERE    m.[MessageID] >= @StartID
		AND m.[MessageID] < (@StartID + @Limit)
		AND m.[TopicID] IS NOT NULL
		ORDER BY m.[MessageID]
		SET ROWCOUNT  0
	END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_simplelist](
				@StartID INT  = 0,
				@Limit   INT  = 500)
AS
	BEGIN
			SET ARITHABORT ON				
		SET ROWCOUNT  @Limit
		SELECT   t.[TopicID],
				 t.[Topic]
		FROM     [{databaseOwner}].[{objectQualifier}Topic] t
		WHERE    t.[TopicID] >= @StartID
		AND t.[TopicID] < (@StartID + @Limit)
		ORDER BY t.[TopicID]
		SET ROWCOUNT  0
	END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_simplelist](
				@StartID INT  = 0,
				@Limit   INT  = 500)
AS
	BEGIN
				
		SET ROWCOUNT  @Limit
		SELECT   a.[UserID],
				 a.[Name]
		FROM     [{databaseOwner}].[{objectQualifier}User] a
		WHERE    a.[UserID] >= @StartID
		AND a.[UserID] < (@StartID + @Limit)
		ORDER BY a.[UserID]
		SET ROWCOUNT  0
	END
GO

-- BBCode

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}bbcode_delete]
(
	@BBCodeID int = NULL
)
AS
BEGIN
		
	IF @BBCodeID IS NOT NULL
		DELETE FROM [{objectQualifier}BBCode] WHERE BBCodeID = @BBCodeID
	ELSE
		DELETE FROM [{objectQualifier}BBCode]
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}bbcode_list]
(
	@BoardID int,
	@BBCodeID int = null
)
AS
BEGIN
		
	IF @BBCodeID IS NULL
		SELECT * FROM [{objectQualifier}BBCode] WHERE BoardID = @BoardID ORDER BY ExecOrder, [Name] DESC
	ELSE
		SELECT * FROM [{objectQualifier}BBCode] WHERE BBCodeID = @BBCodeID ORDER BY ExecOrder
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}bbcode_save]
(
	@BBCodeID int = null,
	@BoardID int,
	@Name nvarchar(255),
	@Description nvarchar(4000) = null,
	@OnClickJS nvarchar(1000) = null,
	@DisplayJS ntext = null,
	@EditJS ntext = null,
	@DisplayCSS ntext = null,
	@SearchRegEx ntext,
	@ReplaceRegEx ntext,
	@Variables nvarchar(1000) = null,
	@UseModule bit = null,
	@ModuleClass nvarchar(255) = null,	
	@ExecOrder int = 1
)
AS
BEGIN
		
	IF @BBCodeID IS NOT NULL BEGIN
		UPDATE
			[{objectQualifier}BBCode]
		SET
			[Name] = @Name,
			[Description] = @Description,
			[OnClickJS] = @OnClickJS,
			[DisplayJS] = @DisplayJS,
			[EditJS] = @EditJS,
			[DisplayCSS] = @DisplayCSS,
			[SearchRegEx] = @SearchRegEx,
			[ReplaceRegEx] = @ReplaceRegEx,
			[Variables] = @Variables,
			[UseModule] = @UseModule,
			[ModuleClass] = @ModuleClass,			
			[ExecOrder] = @ExecOrder
		WHERE
			BBCodeID = @BBCodeID
	END
	ELSE BEGIN
		IF NOT EXISTS(SELECT 1 FROM [{objectQualifier}BBCode] WHERE BoardID = @BoardID AND [Name] = @Name)
			INSERT INTO
				[{objectQualifier}BBCode] ([BoardID],[Name],[Description],[OnClickJS],[DisplayJS],[EditJS],[DisplayCSS],[SearchRegEx],[ReplaceRegEx],[Variables],[UseModule],[ModuleClass],[ExecOrder])
			VALUES (@BoardID,@Name,@Description,@OnClickJS,@DisplayJS,@EditJS,@DisplayCSS,@SearchRegEx,@ReplaceRegEx,@Variables,@UseModule,@ModuleClass,@ExecOrder)
	END
END
GO

-- polls

CREATE procedure [{databaseOwner}].[{objectQualifier}choice_add](
	@PollID		int,
	@Choice		nvarchar(50),
	@ObjectPath nvarchar(255),
	@MimeType nvarchar(50)
) as
begin
	
	insert into [{databaseOwner}].[{objectQualifier}Choice]
		(PollID, Choice, Votes, ObjectPath, MimeType)
		values
		(@PollID, @Choice, 0, @ObjectPath, @MimeType)
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}topic_poll_update](
	@TopicID	int=null,
	@MessageID	int=null,
	@PollID		int=null
) as
begin
	
	if not (@TopicID is null) begin
		update [{databaseOwner}].[{objectQualifier}Topic] 
			set PollID = @PollID 
			where TopicID = @TopicID
	end
	else if not (@MessageID is null) begin
		update [{databaseOwner}].[{objectQualifier}Topic] 
			set PollID = @PollID 
			where TopicID = (select TopicID from [{databaseOwner}].[{objectQualifier}Message] where MessageID = @MessageID)
	end
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}choice_update](
	@ChoiceID	int,
	@Choice		nvarchar(50),
	@ObjectPath nvarchar(255),
	@MimeType nvarchar(50)
) as
begin
	
	update [{databaseOwner}].[{objectQualifier}Choice]
		set Choice = @Choice, ObjectPath =  @ObjectPath, MimeType = @MimeType
		where ChoiceID = @ChoiceID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}choice_delete](
	@ChoiceID	int
) as
begin
	
	delete from [{databaseOwner}].[{objectQualifier}Choice]
		where ChoiceID = @ChoiceID
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}poll_update](
	@PollID		int,
	@Question	nvarchar(50),
	@Closes 	datetime = null,
	@QuestionObjectPath nvarchar(255), 
    @QuestionMimeType varchar(50),
	@IsBounded  bit,
	@IsClosedBounded  bit

) as
begin
	declare @pgid int
	update [{databaseOwner}].[{objectQualifier}Poll]
		set Question	=	@Question,
			Closes		=	@Closes,
			ObjectPath = @QuestionObjectPath,
		    MimeType = @QuestionMimeType
		where PollID = @PollID

      SELECT  @pgid = PollGroupID FROM [{databaseOwner}].[{objectQualifier}Poll]
	  where PollID = @PollID
   
	update [{databaseOwner}].[{objectQualifier}PollGroupCluster]
		set Flags	= (CASE 
		WHEN @IsBounded > 0 AND (Flags & 2) <> 2 THEN Flags | 2 		
		WHEN @IsBounded <= 0 AND (Flags & 2) = 2 THEN Flags ^ 2 		
		ELSE Flags END)		
		where PollGroupID = @pgid

	update [{databaseOwner}].[{objectQualifier}PollGroupCluster]
		set Flags	= (CASE		
		WHEN @IsClosedBounded > 0 AND (Flags & 4) <> 4 THEN Flags | 4		
		WHEN @IsClosedBounded <= 0 AND (Flags & 4) = 4 THEN Flags ^ 4
		ELSE Flags END)		
		where PollGroupID = @pgid
end
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}poll_remove](
	@PollGroupID int, @PollID int = null, @BoardID int = null, @RemoveCompletely bit, @RemoveEverywhere bit)
as
begin
declare @groupcount int
	
	if @RemoveCompletely = 1 
	begin
	-- delete vote records first
	delete from [{databaseOwner}].[{objectQualifier}PollVote] where PollID = @PollID
	-- delete choices 
	delete from [{databaseOwner}].[{objectQualifier}Choice] where PollID = @PollID
	-- delete poll
	Update [{databaseOwner}].[{objectQualifier}Poll] set PollGroupID = NULL where PollID = @PollID
	delete from [{databaseOwner}].[{objectQualifier}Poll] where PollID = @PollID 	
	end
	else
	begin    
	Update [{databaseOwner}].[{objectQualifier}Poll] set PollGroupID = NULL where PollID = @PollID	                         
	end
  

	if  NOT EXISTS (SELECT 1 FROM [{databaseOwner}].[{objectQualifier}Poll] where PollGroupID = @PollGroupID) 
        begin	
			  
                   Update [{databaseOwner}].[{objectQualifier}Topic] set PollID = NULL where PollID = @PollGroupID                 
                  
				   
                   Update [{databaseOwner}].[{objectQualifier}Forum] set PollGroupID = NULL where PollGroupID = @PollGroupID
              
	
                   Update [{databaseOwner}].[{objectQualifier}Category] set PollGroupID = NULL where PollGroupID = @PollGroupID                
		
              
       	
       
		 
        DELETE FROM  [{databaseOwner}].[{objectQualifier}PollGroupCluster] WHERE PollGroupID = @PollGroupID	
		end  	
		

end
GO


-- medals

create proc [{databaseOwner}].[{objectQualifier}group_medal_delete]
	@GroupID int,
	@MedalID int
as begin
	
	delete from [{databaseOwner}].[{objectQualifier}GroupMedal] where [GroupID]=@GroupID and [MedalID]=@MedalID
end
GO

CREATE proc [{databaseOwner}].[{objectQualifier}group_medal_list]
	@GroupID int = null,
	@MedalID int = null
as begin
	
	select 
		a.[MedalID],
		a.[Name],
		a.[MedalURL],
		a.[RibbonURL],
		a.[SmallMedalURL],
		a.[SmallRibbonURL],
		a.[SmallMedalWidth],
		a.[SmallMedalHeight],
		a.[SmallRibbonWidth],
		a.[SmallRibbonHeight],
		b.[SortOrder],
		a.[Flags],
		c.[Name] as [GroupName],
		b.[GroupID],
		isnull(b.[Message],a.[Message]) as [Message],
		b.[Message] as [MessageEx],
		b.[Hide],
		b.[OnlyRibbon],
		b.[SortOrder] as CurrentSortOrder
	from
		[{databaseOwner}].[{objectQualifier}Medal] a
		inner join [{databaseOwner}].[{objectQualifier}GroupMedal] b on b.[MedalID] = a.[MedalID]
		inner join [{databaseOwner}].[{objectQualifier}Group] c on  c.[GroupID] = b.[GroupID]
	where
		(@GroupID is null or b.[GroupID] = @GroupID) and
		(@MedalID is null or b.[MedalID] = @MedalID)		
	order by
		c.[Name] ASC,
		b.[SortOrder] ASC

end
GO

create proc [{databaseOwner}].[{objectQualifier}group_medal_save]
   @GroupID int,
   @MedalID int,
   @Message nvarchar(100) = NULL,
   @Hide bit,
   @OnlyRibbon bit,
   @SortOrder tinyint
as begin
	
	if exists(select 1 from [{databaseOwner}].[{objectQualifier}GroupMedal] where [GroupID]=@GroupID and [MedalID]=@MedalID) begin
		update [{databaseOwner}].[{objectQualifier}GroupMedal]
		set
			[Message] = @Message,
			[Hide] = @Hide,
			[OnlyRibbon] = @OnlyRibbon,
			[SortOrder] = @SortOrder
		where 
			[GroupID]=@GroupID and 
			[MedalID]=@MedalID
	end
	else begin

		insert into [{databaseOwner}].[{objectQualifier}GroupMedal]
			([GroupID],[MedalID],[Message],[Hide],[OnlyRibbon],[SortOrder])
		values
			(@GroupID,@MedalID,@Message,@Hide,@OnlyRibbon,@SortOrder)
	end

end
GO

CREATE proc [{databaseOwner}].[{objectQualifier}medal_delete]
	@BoardID	int = null,
	@MedalID	int = null,
	@Category	nvarchar(50) = null
as begin
	
	if not @MedalID is null begin
		delete from [{databaseOwner}].[{objectQualifier}GroupMedal] where [MedalID] = @MedalID
		delete from [{databaseOwner}].[{objectQualifier}UserMedal] where [MedalID] = @MedalID

		delete from [{databaseOwner}].[{objectQualifier}Medal] where [MedalID]=@MedalID
	end
	else if not @Category is null and not @BoardID is null begin
		delete from [{databaseOwner}].[{objectQualifier}GroupMedal] 
			where [MedalID] in (SELECT [MedalID] FROM [{databaseOwner}].[{objectQualifier}Medal] where [Category]=@Category and [BoardID]=@BoardID)

		delete from [{databaseOwner}].[{objectQualifier}UserMedal] 
			where [MedalID] in (SELECT [MedalID] FROM [{databaseOwner}].[{objectQualifier}Medal] where [Category]=@Category and [BoardID]=@BoardID)

		delete from [{databaseOwner}].[{objectQualifier}Medal] where [Category]=@Category
	end
	else if not @BoardID is null begin
		delete from [{databaseOwner}].[{objectQualifier}GroupMedal] 
			where [MedalID] in (SELECT [MedalID] FROM [{databaseOwner}].[{objectQualifier}Medal] where [BoardID]=@BoardID)

		delete from [{databaseOwner}].[{objectQualifier}UserMedal] 
			where [MedalID] in (SELECT [MedalID] FROM [{databaseOwner}].[{objectQualifier}Medal] where [BoardID]=@BoardID)

		delete from [{databaseOwner}].[{objectQualifier}Medal] where [BoardID]=@BoardID
	end

end
GO

CREATE proc [{databaseOwner}].[{objectQualifier}medal_list]
	@BoardID	int = null,
	@MedalID	int = null,
	@Category	nvarchar(50) = null
as begin
		if not @MedalID is null begin
		select 
			* 
		from 
			[{databaseOwner}].[{objectQualifier}Medal] 
		where 
			[MedalID]=@MedalID 
		order by 
			[Category] asc, 
			[SortOrder] asc
	end
	else if not @Category is null and not @BoardID is null begin
		select 
			* 
		from 
			[{databaseOwner}].[{objectQualifier}Medal] 
		where 
			[Category]=@Category and [BoardID]=@BoardID
		order by 
			[Category] asc, 
			[SortOrder] asc
	end
	else if not @BoardID is null begin
		select 
			* 
		from 
			[{databaseOwner}].[{objectQualifier}Medal] 
		where 
			[BoardID]=@BoardID
		order by 
			[Category] asc, 
			[SortOrder] asc
	end

end
GO

CREATE proc [{databaseOwner}].[{objectQualifier}medal_listusers]
	@MedalID	int
as begin
		(select 
		a.UserID, a.Name
	from 
		[{databaseOwner}].[{objectQualifier}User] a
		inner join [{databaseOwner}].[{objectQualifier}UserMedal] b on a.[UserID] = b.[UserID]
	where
		b.[MedalID]=@MedalID) 
	
	union	

	(select 
		a.UserID, a.Name
	from 
		[{databaseOwner}].[{objectQualifier}User] a
		inner join [{databaseOwner}].[{objectQualifier}UserGroup] b on a.[UserID] = b.[UserID]
		inner join [{databaseOwner}].[{objectQualifier}GroupMedal] c on b.[GroupID] = c.[GroupID]
	where
		c.[MedalID]=@MedalID) 


end
GO

create proc [{databaseOwner}].[{objectQualifier}medal_resort]
	@BoardID int,@MedalID int,@Move int
as
begin
		declare @Position int
	declare @Category nvarchar(50)

	select 
		@Position=[SortOrder],
		@Category=[Category]
	from 
		[{databaseOwner}].[{objectQualifier}Medal] 
	where 
		[BoardID]=@BoardID and [MedalID]=@MedalID

	if (@Position is null) return

	if (@Move > 0) begin
		update 
			[{databaseOwner}].[{objectQualifier}Medal]
		set 
			[SortOrder]=[SortOrder]-1
		where 
			[BoardID]=@BoardID and 
			[Category]=@Category and
			[SortOrder] between @Position and (@Position + @Move) and
			[SortOrder] between 1 and 255
	end
	else if (@Move < 0) begin
		update 
			[{databaseOwner}].[{objectQualifier}Medal]
		set
			[SortOrder]=[SortOrder]+1
		where 
			BoardID=@BoardID and 
			[Category]=@Category and
			[SortOrder] between (@Position+@Move) and @Position and
			[SortOrder] between 0 and 254
	end

	SET @Position = @Position + @Move

	if (@Position>255) SET @Position = 255
	else if (@Position<0) SET @Position = 0

	update [{databaseOwner}].[{objectQualifier}Medal]
		set [SortOrder]=@Position
		where [BoardID]=@BoardID and 
			[MedalID]=@MedalID
end
GO

CREATE proc [{databaseOwner}].[{objectQualifier}medal_save]
	@BoardID int = NULL,
	@MedalID int = NULL,
	@Name nvarchar(100),
	@Description ntext,
	@Message nvarchar(100),
	@Category nvarchar(50) = NULL,
	@MedalURL nvarchar(250),
	@RibbonURL nvarchar(250) = NULL,
	@SmallMedalURL nvarchar(250),
	@SmallRibbonURL nvarchar(250) = NULL,
	@SmallMedalWidth smallint,
	@SmallMedalHeight smallint,
	@SmallRibbonWidth smallint = NULL,
	@SmallRibbonHeight smallint = NULL,
	@SortOrder tinyint = 255,
	@Flags int = 0
as begin
		if @MedalID is null begin
		insert into [{databaseOwner}].[{objectQualifier}Medal]
			([BoardID],[Name],[Description],[Message],[Category],
			[MedalURL],[RibbonURL],[SmallMedalURL],[SmallRibbonURL],
			[SmallMedalWidth],[SmallMedalHeight],[SmallRibbonWidth],[SmallRibbonHeight],
			[SortOrder],[Flags])
		values
			(@BoardID,@Name,@Description,@Message,@Category,
			@MedalURL,@RibbonURL,@SmallMedalURL,@SmallRibbonURL,
			@SmallMedalWidth,@SmallMedalHeight,@SmallRibbonWidth,@SmallRibbonHeight,
			@SortOrder,@Flags)

		select @@rowcount
	end
	else begin
		update [{databaseOwner}].[{objectQualifier}Medal]
			set [BoardID] = BoardID,
				[Name] = @Name,
				[Description] = @Description,
				[Message] = @Message,
				[Category] = @Category,
				[MedalURL] = @MedalURL,
				[RibbonURL] = @RibbonURL,
				[SmallMedalURL] = @SmallMedalURL,
				[SmallRibbonURL] = @SmallRibbonURL,
				[SmallMedalWidth] = @SmallMedalWidth,
				[SmallMedalHeight] = @SmallMedalHeight,
				[SmallRibbonWidth] = @SmallRibbonWidth,
				[SmallRibbonHeight] = @SmallRibbonHeight,
				[SortOrder] = @SortOrder,
				[Flags] = @Flags
		where [MedalID] = @MedalID

		select @@rowcount
	end

end
GO

create proc [{databaseOwner}].[{objectQualifier}user_listmedals]
	@UserID	int
as begin
		(select
		a.[MedalID],
		a.[Name],
		isnull(b.[Message], a.[Message]) as [Message],
		a.[MedalURL],
		a.[RibbonURL],
		a.[SmallMedalURL],
		isnull(a.[SmallRibbonURL], a.[SmallMedalURL]) as [SmallRibbonURL],
		a.[SmallMedalWidth],
		a.[SmallMedalHeight],
		isnull(a.[SmallRibbonWidth], a.[SmallMedalWidth]) as [SmallRibbonWidth],
		isnull(a.[SmallRibbonHeight], a.[SmallMedalHeight]) as [SmallRibbonHeight],
		[{databaseOwner}].[{objectQualifier}medal_getsortorder](b.[SortOrder],a.[SortOrder],a.[Flags]) as [SortOrder],
		[{databaseOwner}].[{objectQualifier}medal_gethide](b.[Hide],a.[Flags]) as [Hide],
		[{databaseOwner}].[{objectQualifier}medal_getribbonsetting](a.[SmallRibbonURL],a.[Flags],b.[OnlyRibbon]) as [OnlyRibbon],
		a.[Flags],
		b.[DateAwarded]
	from
		[{databaseOwner}].[{objectQualifier}Medal] a
		inner join [{databaseOwner}].[{objectQualifier}UserMedal] b on a.[MedalID] = b.[MedalID]
	where
		b.[UserID] = @UserID)

	union

	(select
		a.[MedalID],
		a.[Name],
		isnull(b.[Message], a.[Message]) as [Message],
		a.[MedalURL],
		a.[RibbonURL],
		a.[SmallMedalURL],
		isnull(a.[SmallRibbonURL], a.[SmallMedalURL]) as [SmallRibbonURL],
		a.[SmallMedalWidth],
		a.[SmallMedalHeight],
		isnull(a.[SmallRibbonWidth], a.[SmallMedalWidth]) as [SmallRibbonWidth],
		isnull(a.[SmallRibbonHeight], a.[SmallMedalHeight]) as [SmallRibbonHeight],
		[{databaseOwner}].[{objectQualifier}medal_getsortorder](b.[SortOrder],a.[SortOrder],a.[Flags]) as [SortOrder],
		[{databaseOwner}].[{objectQualifier}medal_gethide](b.[Hide],a.[Flags]) as [Hide],
		[{databaseOwner}].[{objectQualifier}medal_getribbonsetting](a.[SmallRibbonURL],a.[Flags],b.[OnlyRibbon]) as [OnlyRibbon],
		a.[Flags],
		NULL as [DateAwarded]
	from
		[{databaseOwner}].[{objectQualifier}Medal] a
		inner join [{databaseOwner}].[{objectQualifier}GroupMedal] b on a.[MedalID] = b.[MedalID]
		inner join [{databaseOwner}].[{objectQualifier}UserGroup] c on b.[GroupID] = c.[GroupID]
	where
		c.[UserID] = @UserID)
	order by
		[OnlyRibbon] desc,
		[SortOrder] asc

end
GO

create proc [{databaseOwner}].[{objectQualifier}user_medal_delete]
	@UserID int,
	@MedalID int
as begin
		delete from [{databaseOwner}].[{objectQualifier}UserMedal] where [UserID]=@UserID and [MedalID]=@MedalID

end
GO

create proc [{databaseOwner}].[{objectQualifier}user_medal_list]
	@UserID int = null,
	@MedalID int = null
as begin
		select 
		a.[MedalID],
		a.[Name],
		a.[MedalURL],
		a.[RibbonURL],
		a.[SmallMedalURL],
		a.[SmallRibbonURL],
		a.[SmallMedalWidth],
		a.[SmallMedalHeight],
		a.[SmallRibbonWidth],
		a.[SmallRibbonHeight],
		b.[SortOrder],
		a.[Flags],
		c.[Name] as [UserName],
		c.[DisplayName] as [DisplayName],
		b.[UserID],
		isnull(b.[Message],a.[Message]) as [Message],
		b.[Message] as [MessageEx],
		b.[Hide],
		b.[OnlyRibbon],
		b.[SortOrder] as [CurrentSortOrder],
		b.[DateAwarded]
	from
		[{databaseOwner}].[{objectQualifier}Medal] a
		inner join [{databaseOwner}].[{objectQualifier}UserMedal] b on b.[MedalID] = a.[MedalID]
		inner join [{databaseOwner}].[{objectQualifier}User] c on c.[UserID] = b.[UserID]
	where
		(@UserID is null or b.[UserID] = @UserID) and
		(@MedalID is null or b.[MedalID] = @MedalID)		
	order by
		c.[Name] ASC,
		b.[SortOrder] ASC

end
GO

create proc [{databaseOwner}].[{objectQualifier}user_medal_save]
	@UserID int,
	@MedalID int,
	@Message nvarchar(100) = NULL,
	@Hide bit,
	@OnlyRibbon bit,
	@SortOrder tinyint,
	@DateAwarded datetime = NULL
as begin
		if exists(select 1 from [{databaseOwner}].[{objectQualifier}UserMedal] where [UserID]=@UserID and [MedalID]=@MedalID) begin
		update [{databaseOwner}].[{objectQualifier}UserMedal]
		set
			[Message] = @Message,
			[Hide] = @Hide,
			[OnlyRibbon] = @OnlyRibbon,
			[SortOrder] = @SortOrder
		where 
			[UserID]=@UserID and 
			[MedalID]=@MedalID
	end
	else begin

		if (@DateAwarded is null) set @DateAwarded = GETUTCDATE()  

		insert into [{databaseOwner}].[{objectQualifier}UserMedal]
			([UserID],[MedalID],[Message],[Hide],[OnlyRibbon],[SortOrder],[DateAwarded])
		values
			(@UserID,@MedalID,@Message,@Hide,@OnlyRibbon,@SortOrder,@DateAwarded)
	end

end
GO

/* User Ignore Procedures */

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_addignoreduser]
	@UserId int,
	@IgnoredUserId int
AS BEGIN
		IF NOT EXISTS (SELECT * FROM [{databaseOwner}].[{objectQualifier}IgnoreUser] WHERE UserID = @userId AND IgnoredUserID = @IgnoredUserId)
	BEGIN
		INSERT INTO [{databaseOwner}].[{objectQualifier}IgnoreUser] (UserID, IgnoredUserID) VALUES (@UserId, @IgnoredUserId)
	END
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_removeignoreduser]
	@UserId int,
	@IgnoredUserId int
AS BEGIN
		DELETE FROM [{databaseOwner}].[{objectQualifier}IgnoreUser] WHERE UserID = @userId AND IgnoredUserID = @IgnoredUserId
	
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_isuserignored]
	@UserId int,
	@IgnoredUserId int
AS BEGIN
		IF EXISTS(SELECT * FROM [{databaseOwner}].[{objectQualifier}IgnoreUser] WHERE UserID = @userId AND IgnoredUserID = @IgnoredUserId)
	BEGIN
		RETURN 1
	END
	ELSE
	BEGIN
		RETURN 0
	END
	
END	
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_ignoredlist]
	@UserId int
AS
BEGIN
		SELECT * FROM [{databaseOwner}].[{objectQualifier}IgnoreUser] WHERE UserID = @userId
END	
GO

/*****************************************************************************************************
//  Original code by: DLESKTECH at http://www.dlesktech.com/support.aspx
//  Modifications by: KASL Technologies at www.kasltechnologies.com
//  Modifications for integration into YAF/Conventions by Jaben Cargman
*****************************************************************************************************/

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}shoutbox_getmessages]
(
  @BoardId int,
  @NumberOfMessages int, @StyledNicks bit = 0
)  
AS
BEGIN	
	SET ROWCOUNT @NumberOfMessages

	SELECT
		Username,
		UserID,
		[Message],
		[Date],
		Style = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](UserID)  
			else ''	 end		
	FROM
		[{databaseOwner}].[{objectQualifier}ShoutboxMessage]
	WHERE 
		BoardId = @BoardId
	ORDER BY Date DESC
	
	SET ROWCOUNT 0
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}shoutbox_savemessage](
	@UserName		nvarchar(255)=null,
	@BoardId		int,
	@UserID			int,
	@Message		ntext,
	@Date			datetime=null,
	@IP				varchar(39)
)
AS
BEGIN
		IF @Date IS NULL
		SET @Date = GETUTCDATE() 

	INSERT [{databaseOwner}].[{objectQualifier}ShoutboxMessage] (UserName, BoardId, UserID, Message, Date, IP)
	VALUES (@UserName, @BoardId, @UserID, @Message, @Date, @IP)

END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}shoutbox_clearmessages]
(
	@BoardId int
)
AS
BEGIN
		DELETE FROM
			[{databaseOwner}].[{objectQualifier}ShoutboxMessage]
		WHERE
			BoardId = @BoardId AND
			DATEDIFF(minute, Date, GETUTCDATE() ) > 1
END
GO

/* Stored procedures for Buddy feature */

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_addrequest]
	@FromUserID INT,
	@ToUserID INT,
	@approved BIT = NULL OUT,
	@paramOutput NVARCHAR(255) = NULL OUT
AS 
	BEGIN
		IF NOT EXISTS ( SELECT  ID
						FROM    [{databaseOwner}].[{objectQualifier}Buddy]
						WHERE   ( FromUserID = @FromUserID
								  AND ToUserID = @ToUserID
								) ) 
			BEGIN
				IF ( NOT EXISTS ( SELECT    ID
								  FROM      [{databaseOwner}].[{objectQualifier}Buddy]
								  WHERE     ( FromUserID = @ToUserID
											  AND ToUserID = @FromUserID
											) )
				   ) 
					BEGIN
						INSERT  INTO [{databaseOwner}].[{objectQualifier}Buddy]
								(
								  FromUserID,
								 ToUserID,
								  Approved,
								  Requested
								)
						VALUES  (
								  @FromUserID,
								  @ToUserID,
								  0,
								  GETUTCDATE() 
								)
						SET @paramOutput = ( SELECT [Name]
											 FROM   [{databaseOwner}].[{objectQualifier}User]
											 WHERE  ( UserID = @ToUserID )
										   )
						SET @approved = 0
					END
				ELSE 
					BEGIN
						INSERT  INTO [{databaseOwner}].[{objectQualifier}Buddy]
								(
								  FromUserID,
								  ToUserID,
								  Approved,
								  Requested
								)
						VALUES  (
								  @FromUserID,
								  @ToUserID,
								  1,
								  GETUTCDATE() 
								)
						UPDATE  [{databaseOwner}].[{objectQualifier}Buddy]
						SET     Approved = 1
						WHERE   ( FromUserID = @ToUserID
								  AND ToUserID = @FromUserID
								)
						SET @paramOutput = ( SELECT [Name]
											 FROM   [{databaseOwner}].[{objectQualifier}User]
											 WHERE  ( UserID = @ToUserID )
										   )
						SET @approved = 1
					END
			END	
		ELSE 
			BEGIN
				SET @paramOutput = ''
				SET @approved = 0
			END
	END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_approverequest]
	@FromUserID INT,
	@ToUserID INT,
	@Mutual BIT,
	@paramOutput NVARCHAR(255) = NULL OUT
AS 
	BEGIN
		IF EXISTS ( SELECT  ID
					FROM    [{databaseOwner}].[{objectQualifier}Buddy]
					WHERE   ( FromUserID = @FromUserID
							  AND ToUserID = @ToUserID
							) ) 
			BEGIN
				UPDATE  [{databaseOwner}].[{objectQualifier}Buddy]
				SET     Approved = 1
				WHERE   ( FromUserID = @FromUserID
						  AND ToUserID = @ToUserID
						)
				SET @paramOutput = ( SELECT [Name]
									 FROM   [{databaseOwner}].[{objectQualifier}User]
									 WHERE  ( UserID = @FromUserID )
								   )
				IF ( @Mutual = 1 )
					AND ( NOT EXISTS ( SELECT   ID
									   FROM     [{databaseOwner}].[{objectQualifier}Buddy]
									   WHERE    FromUserID = @ToUserID
												AND ToUserID = @FromUserID )
						) 
					INSERT  INTO [{databaseOwner}].[{objectQualifier}Buddy]
							(
							  FromUserID,
							  ToUserID,
							  Approved,
							  Requested
							)
					VALUES  (
							  @ToUserID,
							  @FromUserID,
							  1,
							  GETUTCDATE() 
							)
			END
	END
GO

	CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_list] @FromUserID INT
AS 
	BEGIN
		SELECT  a.UserID,
				a.BoardID,
				a.[Name],
				a.Joined,
				a.NumPosts,
				RankName = b.NAME,
				c.Approved,
				c.FromUserID,
				c.Requested
		FROM   [{databaseOwner}].[{objectQualifier}User] a
				JOIN [{databaseOwner}].[{objectQualifier}Rank] b ON b.RankID = a.RankID
				JOIN [{databaseOwner}].[{objectQualifier}Buddy] c ON ( c.ToUserID = a.UserID
											  AND c.FromUserID = @FromUserID
											)
		UNION
		SELECT  @FromUserID AS UserID,
				a.BoardID,
				a.[Name],
				a.Joined,
				a.NumPosts,
				RankName = b.NAME,
				c.Approved,
				c.FromUserID,
				c.Requested
		FROM    [{databaseOwner}].[{objectQualifier}User] a
				JOIN [{databaseOwner}].[{objectQualifier}Rank] b ON b.RankID = a.RankID
				JOIN [{databaseOwner}].[{objectQualifier}Buddy] c ON ( ( c.Approved = 0 )
											  AND ( c.ToUserID = @FromUserID )
											  AND ( a.UserID = c.FromUserID )
											)
		ORDER BY a.NAME
	END
	GO

	CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_remove]
	@FromUserID INT,
	@ToUserID INT,
	@paramOutput NVARCHAR(255) = NULL OUT
AS 
	BEGIN
		DELETE  FROM [{databaseOwner}].[{objectQualifier}Buddy]
		WHERE   ( FromUserID = @FromUserID
				  AND ToUserID = @ToUserID
				)
		SET @paramOutput = ( SELECT [Name]
							 FROM   [{databaseOwner}].[{objectQualifier}User]
							 WHERE  ( UserID = @ToUserID )
						   )
	END
	GO
CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}buddy_denyrequest]
	@FromUserID INT,
	@ToUserID INT,
	@paramOutput NVARCHAR(255) = NULL OUT
AS 
	BEGIN
		DELETE  FROM [{databaseOwner}].[{objectQualifier}Buddy]
		WHERE   FromUserID = @FromUserID
				AND ToUserID = @ToUserID
		SET @paramOutput = ( SELECT [Name]
							 FROM   [{databaseOwner}].[{objectQualifier}User]
							 WHERE  ( UserID = @FromUserID )
						   )
	END
Go    
/* End of stored procedures for Buddy feature */

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_favorite_add] 
	@UserID int,
	@TopicID int
AS
BEGIN
	IF NOT EXISTS (SELECT ID FROM [{databaseOwner}].[{objectQualifier}FavoriteTopic] WHERE (UserID = @UserID AND TopicID=@TopicID))
	BEGIN
		INSERT INTO [{databaseOwner}].[{objectQualifier}FavoriteTopic] (UserID, TopicID) Values 
								(@UserID, @TopicID)
	END
END
Go

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_favorite_remove] 
	@UserID int,
	@TopicID int
AS
BEGIN
	DELETE FROM [{databaseOwner}].[{objectQualifier}FavoriteTopic] WHERE UserID=@UserID AND TopicID=@TopicID
END
GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}topic_favorite_list](@UserID int) as
BEGIN
SELECT TopicID FROM [{databaseOwner}].[{objectQualifier}FavoriteTopic] WHERE UserID=@UserID
END
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}topic_favorite_details](@BoardID int,@UserID int,@Since datetime,@CategoryID int=null, @StyledNicks bit = 0) as
begin
		select
		c.ForumID,
		c.TopicID,
		c.TopicMovedID,
		c.Posted,
		LinkTopicID = IsNull(c.TopicMovedID,c.TopicID),
		[Subject] = c.Topic,
		c.UserID,
		Starter = IsNull(c.UserName,b.Name),
		NumPostsDeleted = (SELECT COUNT(1) FROM [{databaseOwner}].[{objectQualifier}Message] mes WHERE mes.TopicID = c.TopicID AND mes.IsDeleted = 1 AND mes.IsApproved = 1 AND ((@UserID IS NOT NULL AND mes.UserID = @UserID) OR (@UserID IS NULL)) ),
		Replies = (select count(1) from [{databaseOwner}].[{objectQualifier}Message] x where x.TopicID=c.TopicID and (x.Flags & 8)=0) - 1,
		[Views] = c.[Views],
		LastPosted = c.LastPosted,
		LastUserID = c.LastUserID,
		LastUserName = IsNull(c.LastUserName,(select Name from [{databaseOwner}].[{objectQualifier}User] x where x.UserID=c.LastUserID)),
		LastMessageID = c.LastMessageID,
		LastMessageFlags = c.LastMessageFlags,
		LastTopicID = c.TopicID,
		TopicFlags = c.Flags,
		c.Priority,
		c.PollID,
		ForumName = d.Name,
		c.TopicMovedID,
		ForumFlags = d.Flags,
		FirstMessage = (SELECT TOP 1 CAST([Message] as nvarchar(1000)) FROM [{databaseOwner}].[{objectQualifier}Message] mes2 where mes2.TopicID = IsNull(c.TopicMovedID,c.TopicID) AND mes2.Position = 0),
		StarterStyle = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](c.UserID)  
			else ''	 end,
		LastUserStyle = case(@StyledNicks)
			when 1 then  [{databaseOwner}].[{objectQualifier}get_userstyle](c.LastUserID)  
			else ''	 end
	from
		[{databaseOwner}].[{objectQualifier}Topic] c
		join [{databaseOwner}].[{objectQualifier}User] b on b.UserID=c.UserID
		join [{databaseOwner}].[{objectQualifier}Forum] d on d.ForumID=c.ForumID
		join [{databaseOwner}].[{objectQualifier}vaccess] x on x.ForumID=d.ForumID
		join [{databaseOwner}].[{objectQualifier}Category] e on e.CategoryID=d.CategoryID
		JOIN [{databaseOwner}].[{objectQualifier}FavoriteTopic] z ON z.TopicID=c.TopicID AND z.UserID=@UserID
	where
		@Since < c.LastPosted and
		x.UserID = @UserID and
		x.ReadAccess <> 0 and
		e.BoardID = @BoardID and
		(@CategoryID is null or e.CategoryID=@CategoryID) and
		c.IsDeleted = 0
	order by
		d.Name asc,
		Priority desc,
		LastPosted desc
end
Go

CREATE procedure [{databaseOwner}].[{objectQualifier}album_save]
	(
	  @AlbumID INT = NULL,
	  @UserID INT = null,
	  @Title NVARCHAR(255) = NULL,
	  @CoverImageID INT = NULL
	)
as 
	BEGIN
		-- Update Cover?
		IF ( @CoverImageID IS NOT NULL
			 AND @CoverImageID <> 0
		   ) 
			UPDATE  [{databaseOwner}].[{objectQualifier}UserAlbum]
			SET     CoverImageID = @CoverImageID
			WHERE   AlbumID = @AlbumID
		ELSE 
			--Remove Cover?
			IF ( @CoverImageID = 0 ) 
				UPDATE  [{databaseOwner}].[{objectQualifier}UserAlbum]
				SET     CoverImageID = NULL
				WHERE   AlbumID = @AlbumID            
			ELSE 
			-- Update Title?
				IF @AlbumID is not null 
					UPDATE  [{databaseOwner}].[{objectQualifier}UserAlbum]
					SET     Title = @Title
					WHERE   AlbumID = @AlbumID
				ELSE 
					BEGIN
					-- New album. insert into table.
						INSERT  INTO [{databaseOwner}].[{objectQualifier}UserAlbum]
								(
								  UserID,
								  Title,
								  CoverImageID,
								  Updated
								)
						VALUES  (
								  @UserID,
								  @Title,
								  @CoverImageID,
								  GETUTCDATE() 
								)
						RETURN SCOPE_IDENTITY()
					END
	END
	GO
	
CREATE procedure [{databaseOwner}].[{objectQualifier}album_list]
	(
	  @UserID INT = NULL,
	  @AlbumID INT = NULL
	)
as 
	BEGIN
		IF @UserID IS NOT null 
			select  *
			FROM    [{databaseOwner}].[{objectQualifier}UserAlbum]
			WHERE   UserID = @UserID
			ORDER BY Updated DESC
		ELSE 
			SELECT  *
			FROM    [{databaseOwner}].[{objectQualifier}UserAlbum]
			WHERE   AlbumID = @AlbumID
	END
	GO
	
CREATE procedure [{databaseOwner}].[{objectQualifier}album_delete] ( @AlbumID int )
as 
	BEGIN
		DELETE  FROM [{databaseOwner}].[{objectQualifier}UserAlbumImage]
		WHERE   AlbumID = @AlbumID
		DELETE  FROM [{databaseOwner}].[{objectQualifier}UserAlbum]
		WHERE   AlbumID = @AlbumID       
	END
	GO
	
CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}album_gettitle]
	(
	  @AlbumID INT,
	  @paramOutput NVARCHAR(255) = NULL OUT
	)
as 
	BEGIN
		SET @paramOutput = ( SELECT [Title]
							 FROM   [{databaseOwner}].[{objectQualifier}UserAlbum]
							 WHERE  ( AlbumID = @AlbumID )
						   )
	END
	GO
	
CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}album_getstats]
	@UserID INT = NULL,
	@AlbumID INT = NULL,
	@AlbumNumber INT = NULL OUTPUT,
	@ImageNumber BIGINT = NULL OUTPUT
as 
	BEGIN
		IF @AlbumID IS NOT NULL 
			SET @ImageNumber = ( SELECT COUNT(ImageID)
								 FROM   [{databaseOwner}].[{objectQualifier}UserAlbumImage]
								 WHERE  AlbumID = @AlbumID
							   )
		ELSE 
			BEGIN
				SET @AlbumNumber = ( SELECT COUNT(AlbumID)
									 FROM   [{databaseOwner}].[{objectQualifier}UserAlbum]
									 WHERE  UserID = @UserID
								   )
				SET @ImageNumber = ( SELECT COUNT(ImageID)
									 FROM   [{databaseOwner}].[{objectQualifier}UserAlbumImage]
									 WHERE  AlbumID in (
											SELECT  AlbumID
											FROM    [{databaseOwner}].[{objectQualifier}UserAlbum]
											WHERE   UserID = @UserID )
								   )
			END
	END
	GO
	
CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}album_image_save]
	(
	  @ImageID INT = NULL,
	  @AlbumID INT = null,
	  @Caption NVARCHAR(255) = null,
	  @FileName NVARCHAR(255) = null,
	  @Bytes INT = null,
	  @ContentType NVARCHAR(50) = null
	)
as 
	BEGIN
		IF @ImageID is not null 
			UPDATE  [{databaseOwner}].[{objectQualifier}UserAlbumImage]
			SET     Caption = @Caption
			WHERE   ImageID = @ImageID
		ELSE
			INSERT  INTO [{databaseOwner}].[{objectQualifier}UserAlbumImage]
					(
					  AlbumID,
					  Caption,
					  [FileName],
					  Bytes,
					  ContentType,
					  Uploaded,
					  Downloads
					)
			VALUES  (
					  @AlbumID,
					  @Caption,
					  @FileName,
					  @Bytes,
					  @ContentType,
					  GETUTCDATE() ,
					  0
					)
	END        
	GO
	
CREATE procedure [{databaseOwner}].[{objectQualifier}album_image_list]
	(
	  @AlbumID INT = NULL,
	  @ImageID INT = null
	)
as 
	BEGIN
		IF @AlbumID IS NOT null 
			SELECT  *
			FROM    [{databaseOwner}].[{objectQualifier}UserAlbumImage]
			WHERE   AlbumID = @AlbumID
			ORDER BY Uploaded DESC
		ELSE 
			SELECT  a.*,
					b.UserID
			FROM    [{databaseOwner}].[{objectQualifier}UserAlbumImage] a
					INNER JOIN [{databaseOwner}].[{objectQualifier}UserAlbum] b ON b.AlbumID = a.AlbumID
			WHERE   ImageID = @ImageID
	END
	GO

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}album_image_delete] ( @ImageID INT )
as 
	BEGIN
		DELETE  FROM [{databaseOwner}].[{objectQualifier}UserAlbumImage]
		WHERE   ImageID = @ImageID
		UPDATE  [{databaseOwner}].[{objectQualifier}UserAlbum]
		SET     CoverImageID = NULL
		WHERE   CoverImageID = @ImageID
		UPDATE  [{databaseOwner}].[{objectQualifier}UserAlbum]
		SET     CoverImageID = NULL
		WHERE   CoverImageID = @ImageID
	END
	GO
	
CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}album_image_download] ( @ImageID INT )
as 
	BEGIN
		UPDATE  [{databaseOwner}].[{objectQualifier}UserAlbumImage]
		SET     Downloads = Downloads + 1
		WHERE   ImageID = @ImageID
	END
	GO
	
CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_getsignaturedata] (@BoardID INT, @UserID INT)
as 
	BEGIN

    

DECLARE   @GroupData TABLE
(
	G_UsrSigChars int,
	G_UsrSigBBCodes nvarchar(255),
	G_UsrSigHTMLTags nvarchar(255)
)
   
   declare @ust int, @usbbc nvarchar(255), 
	@ushtmlt nvarchar(255), @rust int, @rusbbc nvarchar(255),  
	@rushtmlt nvarchar(255) 
	      
      declare c cursor for
      SELECT ISNULL(c.UsrSigChars,0), ISNULL(c.UsrSigBBCodes,''), ISNULL(c.UsrSigHTMLTags,'')
	  FROM [{databaseOwner}].[{objectQualifier}User] a 
						JOIN [{databaseOwner}].[{objectQualifier}UserGroup] b
						  ON a.UserID = b.UserID
							JOIN [{databaseOwner}].[{objectQualifier}Group] c                         
							  ON b.GroupID = c.GroupID 
							  WHERE a.UserID = @UserID AND c.BoardID = @BoardID ORDER BY c.SortOrder ASC
		        
        open c
       
        fetch next from c into  @ust, @usbbc , @ushtmlt
        while @@FETCH_STATUS = 0
        begin
		if not exists (select 1 from @GroupData)
		begin
		-- first check ranks
		SELECT TOP 1 @rust = ISNULL(c.UsrSigChars,0), @rusbbc = c.UsrSigBBCodes, 
		@rushtmlt = c.UsrSigHTMLTags
		FROM [{databaseOwner}].[{objectQualifier}Rank] c 
								JOIN [{databaseOwner}].[{objectQualifier}User] d
								  ON c.RankID = d.RankID
								   WHERE d.UserID = @UserID AND c.BoardID = @BoardID 
								   ORDER BY c.RankID DESC

        -- insert first row and compare with ranks data
	INSERT INTO @GroupData(G_UsrSigChars,G_UsrSigBBCodes,G_UsrSigHTMLTags) 
		select (CASE WHEN @rust > ISNULL(@ust,0) THEN @rust ELSE ISNULL(@ust,0) END), 
		(COALESCE(@rusbbc + ',','') + COALESCE(@usbbc,'')) ,(COALESCE(@rushtmlt + ',','') + COALESCE(@ushtmlt, '') ) 	  
		end
		else
		begin
		update @GroupData set 
		G_UsrSigChars = (CASE WHEN G_UsrSigChars > COALESCE(@ust, 0) THEN G_UsrSigChars ELSE COALESCE(@ust, 0) END), 
		G_UsrSigBBCodes = COALESCE(@usbbc + ',','') + G_UsrSigBBCodes, 
		G_UsrSigHTMLTags = COALESCE(@ushtmlt + ',', '') + G_UsrSigHTMLTags
        end 

		fetch next from c into   @ust, @usbbc , @ushtmlt
        
		end

       close c
       deallocate c 	
	             
	   
		SELECT 
		UsrSigChars = G_UsrSigChars, 
		UsrSigBBCodes = G_UsrSigBBCodes, 
		UsrSigHTMLTags = G_UsrSigHTMLTags
		FROM @GroupData 

   END
GO      
	
CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}user_getalbumsdata] (@BoardID INT, @UserID INT )
as 
	BEGIN
	DECLARE 
	@OR_UsrAlbums int,     
	@OG_UsrAlbums int,
	@OR_UsrAlbumImages int,     
	@OG_UsrAlbumImages int
	 -- Ugly but bullet proof - it used very rarely   
	DECLARE  @GroupData TABLE
(
	G_UsrAlbums int,
	G_UsrAlbumImages int
)
	DECLARE
   @RankData TABLE
(
	R_UsrAlbums int,
	R_UsrAlbumImages int
)

	  -- REMOVED ORDER BY c.SortOrder ASC, SELECTING ALL
	 
	INSERT INTO @GroupData(G_UsrAlbums,
	G_UsrAlbumImages)
	SELECT  ISNULL(c.UsrAlbums,0), ISNULL(c.UsrAlbumImages,0)   
	FROM [{databaseOwner}].[{objectQualifier}User] a
						JOIN [{databaseOwner}].[{objectQualifier}UserGroup] b
						  ON a.UserID = b.UserID
							JOIN [{databaseOwner}].[{objectQualifier}Group] c                         
							  ON b.GroupID = c.GroupID
							  WHERE a.UserID = @UserID AND a.BoardID = @BoardID
	 
							 
	 INSERT INTO @RankData(R_UsrAlbums, R_UsrAlbumImages)
	 SELECT  ISNULL(c.UsrAlbums,0), ISNULL(c.UsrAlbumImages,0)   
	 FROM [{databaseOwner}].[{objectQualifier}Rank] c
								JOIN [{databaseOwner}].[{objectQualifier}User] d
								  ON c.RankID = d.RankID WHERE d.UserID = @UserID 
								  AND d.BoardID = @BoardID
	   
	   -- SELECTING MAX()
	   
	   SET @OR_UsrAlbums = (SELECT Max(R_UsrAlbums) FROM @RankData)
	   SET @OG_UsrAlbums = (SELECT Max(G_UsrAlbums) FROM @GroupData)
	   SET @OR_UsrAlbumImages = (SELECT Max(R_UsrAlbumImages) FROM @RankData)
	   SET @OG_UsrAlbumImages = (SELECT Max(G_UsrAlbumImages) FROM @GroupData)
	   
	   SELECT
		NumAlbums  = (SELECT COUNT(ua.AlbumID) FROM [{databaseOwner}].[{objectQualifier}UserAlbum] ua
					  WHERE ua.UserID = @UserID),
		NumImages = (SELECT COUNT(uai.ImageID) FROM  [{databaseOwner}].[{objectQualifier}UserAlbumImage] uai
					 INNER JOIN [{databaseOwner}].[{objectQualifier}UserAlbum] ua
					 ON ua.AlbumID = uai.AlbumID
					 WHERE ua.UserID = @UserID),
		UsrAlbums = CASE WHEN @OG_UsrAlbums > @OR_UsrAlbums THEN @OG_UsrAlbums ELSE @OR_UsrAlbums END,
		UsrAlbumImages = CASE WHEN @OG_UsrAlbumImages > @OR_UsrAlbumImages THEN @OG_UsrAlbumImages ELSE @OR_UsrAlbumImages END
			 
	 
END
GO  

CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}messagehistory_list] (@MessageID INT, @DaysToClean INT, @ShowAll BIT = null )
as 
	BEGIN    
	-- delete all message variants older then DaysToClean days Flags reserved for possible pms
   
	delete from [{databaseOwner}].[{objectQualifier}MessageHistory]
	 where DATEDIFF(day,Edited,GETUTCDATE() ) > @DaysToClean
	
	-- we don't return Message text and ip if it's simply a user
	   
	 IF @ShowAll > 0               
	 SELECT mh.*, m.UserID, m.UserName, t.ForumID, t.TopicID, t.Topic, IsNull(t.UserName, u.Name) as Name, m.Posted
	 FROM [{databaseOwner}].[{objectQualifier}MessageHistory] mh
	 LEFT JOIN [{databaseOwner}].[{objectQualifier}Message] m ON m.MessageID = mh.MessageID
	 LEFT JOIN [{databaseOwner}].[{objectQualifier}Topic] t ON t.TopicID = m.TopicID
	 LEFT JOIN [{databaseOwner}].[{objectQualifier}User] u ON u.UserID = t.UserID
	 WHERE mh.MessageID = @MessageID     
	 ELSE 
	 SELECT   
	 MessageID,	
	 Edited,			
	 EditReason,
	 EditedBy,
	 IsModeratorChanged,
	 Flags
	 FROM [{databaseOwner}].[{objectQualifier}MessageHistory]
	 WHERE MessageID = @MessageID    
	END
GO

CREATE procedure [{databaseOwner}].[{objectQualifier}user_lazydata](
	@UserID	int,
	@BoardID int,
	@ShowPendingMails bit = 0,
	@ShowPendingBuddies bit = 0,
	@ShowUnreadPMs bit = 0,
	@ShowUserAlbums bit = 0,
	@ShowUserStyle bit = 0
	
) as
begin 
	declare 
	@G_UsrAlbums int,
	@R_UsrAlbums int,
	@R_Style varchar(255),
	@G_Style varchar(255) 	
	
	IF (@ShowUserStyle > 0) 
	BEGIN
	SELECT TOP 1 @G_Style = c.Style 
	FROM [{databaseOwner}].[{objectQualifier}User] a 
						JOIN [{databaseOwner}].[{objectQualifier}UserGroup] b
						  ON a.UserID = b.UserID
							JOIN [{databaseOwner}].[{objectQualifier}Group] c                         
							  ON b.GroupID = c.GroupID 
							  WHERE a.UserID = @UserID 
								AND a.BoardID = @BoardID 
								  ORDER BY c.SortOrder ASC
							   
	SELECT TOP 1 @R_Style = c.Style 
	FROM [{databaseOwner}].[{objectQualifier}Rank] c 
								JOIN [{databaseOwner}].[{objectQualifier}User] d
								  ON c.RankID = d.RankID WHERE d.UserID = @UserID  
								   AND d.BoardID = @BoardID 
									ORDER BY c.RankID DESC 
	END  									 
		
	IF (@ShowUserAlbums > 0)
	BEGIN	
	SELECT @G_UsrAlbums = ISNULL(MAX(c.UsrAlbums),0)
	FROM [{databaseOwner}].[{objectQualifier}User] a 
						JOIN [{databaseOwner}].[{objectQualifier}UserGroup] b
						  ON a.UserID = b.UserID
							JOIN [{databaseOwner}].[{objectQualifier}Group] c                         
							  ON b.GroupID = c.GroupID 
							   WHERE a.UserID = @UserID 
								 AND a.BoardID = @BoardID
								 
	SELECT  @R_UsrAlbums = ISNULL(MAX(c.UsrAlbums),0)
	FROM [{databaseOwner}].[{objectQualifier}Rank] c 
								JOIN [{databaseOwner}].[{objectQualifier}User] d
								  ON c.RankID = d.RankID WHERE d.UserID = @UserID 
									AND d.BoardID = @BoardID 
	END 	
	ELSE	
	BEGIN
	SET @G_UsrAlbums = 0
	SET @R_UsrAlbums = 0
	END
	
	                                                             

	-- return information
	select TOP 1		
		a.ProviderUserKey,
		UserFlags			= a.Flags,
		UserName			= a.Name,
		Suspended			= a.Suspended,
		ThemeFile			= a.ThemeFile,
		LanguageFile		= a.LanguageFile,
		TimeZoneUser		= a.TimeZone,
		CultureUser		    = a.Culture,		
		IsGuest				= a.Flags & 4,
		MailsPending		= CASE WHEN @ShowPendingMails > 0 THEN (select count(1) from [{databaseOwner}].[{objectQualifier}Mail] WHERE [ToUserName] = a.Name) ELSE 0 END,
		UnreadPrivate		= CASE WHEN @ShowUnreadPMs > 0 THEN (select count(1) from [{databaseOwner}].[{objectQualifier}UserPMessage] where UserID=@UserID and IsRead=0 and IsDeleted = 0 and IsArchived = 0) ELSE 0 END,
		LastUnreadPm		= CASE WHEN @ShowUnreadPMs > 0 THEN (SELECT TOP 1 Created FROM [{databaseOwner}].[{objectQualifier}PMessage] pm INNER JOIN [{databaseOwner}].[{objectQualifier}UserPMessage] upm ON pm.PMessageID = upm.PMessageID WHERE upm.UserID=@UserID and upm.IsRead=0  and upm.IsDeleted = 0 and upm.IsArchived = 0 ORDER BY pm.Created DESC) ELSE NULL END,		
		PendingBuddies      = CASE WHEN @ShowPendingBuddies > 0 THEN (SELECT COUNT(ID) FROM [{databaseOwner}].[{objectQualifier}Buddy] WHERE ToUserID = @UserID AND Approved = 0) ELSE 0 END,
		LastPendingBuddies	= CASE WHEN @ShowPendingBuddies > 0 THEN (SELECT TOP 1 Requested FROM [{databaseOwner}].[{objectQualifier}Buddy] WHERE ToUserID=@UserID and Approved = 0 ORDER BY Requested DESC) ELSE NULL END,
		UserStyle 		    = CASE WHEN @ShowUserStyle > 0 THEN (ISNULL(@G_Style, @R_Style))  
			else ''	 end,
		NumAlbums  = (SELECT COUNT(1) FROM [{databaseOwner}].[{objectQualifier}UserAlbum] ua
		WHERE ua.UserID = @UserID),
		UsrAlbums  = (CASE WHEN @G_UsrAlbums > @R_UsrAlbums THEN @G_UsrAlbums ELSE @R_UsrAlbums END),
		UserHasBuddies  = SIGN(ISNULL((SELECT TOP 1 1 FROM [{databaseOwner}].[{objectQualifier}Buddy] WHERE [FromUserID] = @UserID OR [ToUserID] = @UserID),0)),
		-- Guest can't vote in polls attached to boards, we need some temporary access check by a criteria 
		BoardVoteAccess	= (CASE WHEN a.Flags & 4 > 0 THEN 0 ELSE 1 END)
		from
		   [{databaseOwner}].[{objectQualifier}User] a		
		where
		a.UserID = @UserID
	 end
GO

#IFSRVVER>8#CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_gettextbyids] (@MessageIDs varchar(max))
AS 
	BEGIN
	-- vzrus says: the server version > 2000 ntext works too slowly with substring in the 2005 
	DECLARE @ParsedMessageIDs TABLE
		  (
				MessageID int
		  )
	  
	DECLARE @MessageID varchar(11), @Pos INT      

	SET @Pos = CHARINDEX(',', @MessageIDs, 1)

	-- check here if the value is not empty
	IF REPLACE(@MessageIDs, ',', '') <> ''
	BEGIN
		WHILE @Pos > 0
		BEGIN
			SET @MessageID = LTRIM(RTRIM(LEFT(@MessageIDs, @Pos - 1)))
			IF @MessageID <> ''
			BEGIN
				  INSERT INTO @ParsedMessageIDs (MessageID) VALUES (CAST(@MessageID AS int)) --Use Appropriate conversion
			END
			SET @MessageIDs = RIGHT(@MessageIDs, LEN(@MessageIDs) - @Pos)
			SET @Pos = CHARINDEX(',', @MessageIDs, 1)
		END
		-- to be sure that last value is inserted
		IF (LEN(@MessageIDs) > 0)
			   INSERT INTO @ParsedMessageIDs (MessageID) VALUES (CAST(@MessageIDs AS int)) 
		END 

		SELECT a.MessageID, d.Message
			FROM @ParsedMessageIDs a
			INNER JOIN [{databaseOwner}].[{objectQualifier}Message] d ON (d.MessageID = a.MessageID)
	END
GO

#IFSRVVER=8#CREATE PROCEDURE [{databaseOwner}].[{objectQualifier}message_gettextbyids] 
	@MessageIDs ntext
AS
BEGIN
DECLARE @ParsedMessageIDs TABLE
	  (
			MessageID int
	  )
	DECLARE @MessageIDsChunk NVARCHAR(4000), @MessageID varchar(11), @Pos INT, @Itr INT, @trimindex int
	SET @Itr = 0
	SET @MessageIDSChunk  = SUBSTRING( @MessageIDs, @Itr, @Itr + 4000 )
	WHILE LEN(@MessageIDsChunk) > 0
	BEGIN
			SET @trimindex = CHARINDEX(',',REVERSE( @MessageIDsChunk ), 1 );
			SET @MessageIDsChunk = SUBSTRING(@MessageIDsChunk,0, 4000-@trimindex)
			SET @Itr = @Itr - @trimindex
			SET @MessageIDsChunk = LTRIM(RTRIM(@MessageIDsChunk))+ ','
			SET @Pos = CHARINDEX(',', @MessageIDsChunk, 1)
			IF REPLACE(@MessageIDsChunk, ',', '') <> ''
			BEGIN
				  WHILE @Pos > 0
				  BEGIN
						SET @MessageID = LTRIM(RTRIM(LEFT(@MessageIDsChunk, @Pos - 1)))
						IF @MessageID <> ''
						BEGIN
							  INSERT INTO @ParsedMessageIDs (MessageID) VALUES (CAST(@MessageID AS int)) --Use Appropriate conversion
						END
						SET @MessageIDsChunk = RIGHT(@MessageIDsChunk, LEN(@MessageIDsChunk) - @Pos)
						SET @Pos = CHARINDEX(',', @MessageIDsChunk, 1)
				  END
			END      
			SET @Itr = @Itr + 4000;
			SET @MessageIDSChunk  = SUBSTRING( @MessageIDs, @Itr, @Itr + 4000 )
	  END
	  
		SELECT a.MessageID, d.Message
			FROM @ParsedMessageIDs a
			INNER JOIN [{databaseOwner}].[{objectQualifier}Message] d ON (d.MessageID = a.MessageID)
END
GO

